using System.ComponentModel;

namespace RamahSnackSender;

public class Contact : INotifyPropertyChanged
{
    [Browsable(false)] public int Row { get; set; }
    [Browsable(false)] public string DateText { get; set; } = "";
    [Browsable(false)] public string PromoDate { get; set; } = "";

    public string No { get; set; } = "";
    public string Name { get; set; } = "";
    public string Phone { get; set; } = "";

    private string _status = "Not contacted";
    public string Status
    {
        get => _status;
        set { _status = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Status))); }
    }

    private string _note = "";
    public string Note
    {
        get => _note;
        set { _note = value ?? ""; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Note))); }
    }

    public event PropertyChangedEventHandler? PropertyChanged;
}

public class HistoryEntry
{
    public string Phone { get; set; } = "";
    public string Nama { get; set; } = "";
    public string Tanggal { get; set; } = "";
    public string Sumber { get; set; } = "";
}

public class MessageTemplate
{
    public string Name { get; set; } = "";
    public string Body { get; set; } = "";
}

public class AppSettings
{
    // Message content is for your customers, so it stays in your own language.
    // Spintax: {pilihan1|pilihan2|pilihan3} → program pilih acak salah satu.
    public string Template { get; set; } =
        "{Assalamu'alaikum|Halo|Selamat pagi}, izin menghubungi Bapak/Ibu dari {name}.\r\n\r\n" +
        "Saya dari RamahSnack, ingin menawarkan {cemilan usus|usus kriuk|cemilan usus renyah} untuk dititipkan di {name}.\r\n\r\n" +
        "{Kalau Bapak/Ibu berkenan|Jika berkenan|Bolehkah}, saya boleh datang membawa beberapa sampel untuk dicoba terlebih dahulu.\r\n\r\n" +
        "{Terima kasih|Makasih banyak}, Bapak/Ibu.";

    public string PromoTemplate { get; set; } =
        "{Assalamu'alaikum|Halo|Selamat siang}, Bapak/Ibu dari {name}.\r\n\r\n" +
        "Kami dari RamahSnack ada {promo spesial|penawaran menarik} bulan ini: [tulis promo di sini].\r\n\r\n" +
        "{Terima kasih|Makasih banyak}, Bapak/Ibu.";

    /// <summary>Template tambahan yang bisa dipilih user (selain Intro & Promo).</summary>
    public List<MessageTemplate> SavedTemplates { get; set; } = new()
    {
        new MessageTemplate
        {
            Name = "Pembukaan (default)",
            Body =
                "{Assalamu'alaikum|Halo|Selamat pagi}, izin menghubungi Bapak/Ibu dari {name}.\r\n\r\n" +
                "Saya dari RamahSnack, ingin menawarkan {cemilan usus|usus kriuk|cemilan usus renyah} untuk dititipkan di {name}.\r\n\r\n" +
                "{Kalau Bapak/Ibu berkenan|Jika berkenan|Bolehkah}, saya boleh datang membawa beberapa sampel untuk dicoba terlebih dahulu.\r\n\r\n" +
                "{Terima kasih|Makasih banyak}, Bapak/Ibu."
        },
        new MessageTemplate
        {
            Name = "Follow-up 1 (sudah chat)",
            Body =
                "{Assalamu'alaikum|Halo} Bapak/Ibu dari {name}.\r\n\r\n" +
                "Maaf mengganggu, saya follow up terkait {cemilan usus|produk} RamahSnack yang sempat saya tawarkan.\r\n\r\n" +
                "{Apakah sudah sempat dipertimbangkan|Ada kabar baik|Masih berminat}?\r\n\r\n" +
                "{Terima kasih|Makasih}, Bapak/Ibu."
        },
        new MessageTemplate
        {
            Name = "Follow-up 2 (sampel)",
            Body =
                "{Assalamu'alaikum|Halo} Bapak/Ibu dari {name}.\r\n\r\n" +
                "Saya dari RamahSnack, {bolehkah|izin} mengantar sampel {cemilan usus|produk} ke toko Bapak/Ibu?\r\n\r\n" +
                "{Kapan waktu yang nyaman|Bisa hari ini atau besok}?\r\n\r\n" +
                "{Terima kasih|Makasih banyak}."
        },
        new MessageTemplate
        {
            Name = "Promo bulan ini",
            Body =
                "{Assalamu'alaikum|Halo|Selamat siang}, Bapak/Ibu dari {name}.\r\n\r\n" +
                "Kami dari RamahSnack ada {promo spesial|penawaran menarik} bulan ini: [tulis promo di sini].\r\n\r\n" +
                "{Terima kasih|Makasih banyak}, Bapak/Ibu."
        }
    };

    public List<string> ImagePaths { get; set; } = new();
    public string ExcelPath { get; set; } = "";
    public int MinDelay { get; set; } = 45;
    public int MaxDelay { get; set; } = 120;
    public bool UseDesktop { get; set; } = true;
    public int AutoMin { get; set; } = 45;
    public int AutoMax { get; set; } = 90;
    public int AutoLimit { get; set; } = 15;
    public int AutoWait { get; set; } = 8;
    /// <summary>Jam mulai boleh kirim (0-23). Default 8 = 08:00.</summary>
    public int SafeHourStart { get; set; } = 8;
    /// <summary>Jam selesai boleh kirim (0-23). Default 20 = 20:00.</summary>
    public int SafeHourEnd { get; set; } = 20;
}
