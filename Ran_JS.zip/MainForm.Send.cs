using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace RamahSnackSender;

public partial class MainForm
{
    private Contact? current;
    private int countdown = 0;
    private CancellationTokenSource? cts;
    private bool autoRunning = false;
    private readonly Random rnd = new();
    private int batchNoWa = 0;

    private static bool Open(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            return true;
        }
        catch
        {
            return false;
        }
    }

    // ------------------------------------------------------------------ manual mode
    private void PrepareNext()
    {
        if (autoRunning) return;
        if (!ConfirmSafeToSend("manual")) return;
        Contact? next;
        while ((next = contacts.FirstOrDefault(c => IsPending(c))) != null)
        {
            if (Normalize(next.Phone) == null)
            {
                next.Status = string.IsNullOrWhiteSpace(next.Phone) ? "No number" : "Invalid number";
                SaveStatus(next);
                continue;
            }
            if (CheckAlreadyContacted(next, true)) continue;      // contacted before -> skip
            break;
        }
        ApplyFilter();
        UpdateProgress();
        if (next == null)
        {
            MessageBox.Show("All contacts have been processed.");
            return;
        }
        Prepare(next);
    }

    private void Prepare(Contact c)
    {
        if (autoRunning) return;
        if (countdown > 0)
        {
            MessageBox.Show("Wait for the countdown to finish so messages do not go out too fast.");
            return;
        }
        if (current != null && current != c)
        {
            MessageBox.Show("Finish the contact you prepared first (click 'I sent it' or 'Skip this contact').");
            return;
        }
        if (IsFinished(c))
        {
            MessageBox.Show("This contact was already processed.");
            return;
        }
        if (CheckAlreadyContacted(c, true))
        {
            MessageBox.Show("This number was contacted before, so it will not be messaged again.\r\nStatus: " + c.Status +
                            "\r\n\r\nTo message it again on purpose, select the row and click 'Restore (selected)'.");
            UpdateProgress();
            return;
        }

        var phone = Normalize(c.Phone);
        if (phone == null)
        {
            c.Status = string.IsNullOrWhiteSpace(c.Phone) ? "No number" : "Invalid number";
            SaveStatus(c);
            UpdateProgress();
            return;
        }

        var msg = Fill(txtTemplate.Text, c.Name);

        try
        {
            var files = settings.ImagePaths.Where(File.Exists).ToArray();
            if (files.Length > 0)
            {
                var list = new System.Collections.Specialized.StringCollection();
                list.AddRange(files);
                Clipboard.SetFileDropList(list);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not copy the photos to the clipboard: " + ex.Message);
        }

        var text = Uri.EscapeDataString(msg);
        bool opened = false;
        if (chkDesktop.Checked)
            opened = Open($"whatsapp://send?phone={phone}&text={text}");
        if (!opened)
            opened = Open($"https://wa.me/{phone}?text={text}");
        if (!opened) return;

        current = c;
        c.Status = "Prepared";
        btnSent.Enabled = btnSkip.Enabled = true;
        btnPrepare.Enabled = false;
        lblInfo.Text = $"Prepared: {c.Name} ({phone})\r\n" +
                       "1) Press Enter in WhatsApp (sends the text)\r\n" +
                       "2) Press Ctrl+V (pastes all photos), then Enter\r\n" +
                       "3) Come back here and click 'I sent it'.";
        UpdateProgress();
    }

    private void MarkCurrent(string status, bool applyDelay)
    {
        if (current == null) return;
        var done = current;
        done.Status = status;
        SaveStatus(done);
        if (status == "Contacted") AddHistory(done, "Sent from Ran JS");
        current = null;
        btnSent.Enabled = btnSkip.Enabled = false;

        if (applyDelay && contacts.Any(c => IsPending(c)))
        {
            int lo = (int)Math.Min(numMin.Value, numMax.Value);
            int hi = (int)Math.Max(numMin.Value, numMax.Value);
            countdown = rnd.Next(lo, hi + 1);
            btnPrepare.Enabled = false;
            timer.Start();
            Tick(false);
        }
        else
        {
            btnPrepare.Enabled = true;
            btnPrepare.Text = "PREPARE + OPEN NEXT CHAT";
        }

        if (!contacts.Any(c => IsPending(c)))
            lblInfo.Text = "Finished! All contacts have been processed.";
        else
            lblInfo.Text = $"{done.Name}: {status}.\r\n" +
                           (applyDelay ? "Wait for the countdown, " : "") +
                           "then click the green button for the next contact.";
        ApplyFilter();
        UpdateProgress();
    }

    private void Tick(bool decrement = true)
    {
        if (decrement) countdown--;
        if (countdown <= 0)
        {
            timer.Stop();
            countdown = 0;
            btnPrepare.Enabled = true;
            btnPrepare.Text = "PREPARE + OPEN NEXT CHAT";
            return;
        }
        btnPrepare.Text = $"Wait {countdown} sec...";
    }

    // ------------------------------------------------------------------ automatic mode
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    private static bool WhatsAppIsActive()
    {
        var sb = new StringBuilder(256);
        GetWindowText(GetForegroundWindow(), sb, sb.Capacity);
        return sb.ToString().Contains("WhatsApp", StringComparison.OrdinalIgnoreCase);
    }

    private enum SendResult { Sent, Skipped, Failed }

    private void SetAutoUi(bool running)
    {
        btnAuto.Enabled = !running;
        btnFollow.Enabled = !running;
        btnBlast.Enabled = !running;
        btnStop.Enabled = running;
        btnPrepare.Enabled = !running;
        btnSent.Enabled = btnSkip.Enabled = false;
    }

    private async void StartAuto()
    {
        if (autoRunning) return;
        if (current != null)
        {
            MessageBox.Show("Finish the contact you prepared manually first.");
            return;
        }
        if (!ConfirmSafeToSend("auto")) return;

        FlagKnownContacts();
        ApplyFilter();

        var pending = contacts.Where(c => IsPending(c)).ToList();
        if (pending.Count == 0)
        {
            MessageBox.Show("All contacts have been processed.");
            return;
        }

        int total = Math.Min((int)numLimit.Value, pending.Count);
        int lo = (int)Math.Min(numAutoMin.Value, numAutoMax.Value);
        int hi = (int)Math.Max(numAutoMin.Value, numAutoMax.Value);
        var confirm = MessageBox.Show(
            $"Ran JS will send automatically to {total} contact(s).\r\n\r\n" +
            $"- Delay between contacts: {lo}–{hi} sec (random)\r\n" +
            $"- Safe hours: {numHourStart.Value:00}:00 – {numHourEnd.Value:00}:00\r\n" +
            "- Open and log in to WhatsApp Desktop first.\r\n" +
            "- Do not type anything while it runs.\r\n" +
            "- Click STOP at any time to stop.\r\n\r\nContinue?",
            "Automatic mode", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (confirm != DialogResult.Yes) return;

        await RunBatch(pending, txtTemplate.Text, false, true);
    }

    private static bool Eligible(Contact c, bool[] groups, bool skipToday, string today)
    {
        int g = GroupOf(c);
        if (g < 0 || !groups[g]) return false;
        if (skipToday && c.PromoDate == today) return false;
        return true;
    }

    private async void StartPromo(bool repliedOnly)
    {
        if (autoRunning) return;
        if (current != null)
        {
            MessageBox.Show("Finish the contact you prepared manually first.");
            return;
        }
        if (!ConfirmSafeToSend("auto")) return;
        if (contacts.Count == 0)
        {
            MessageBox.Show("Import an Excel file first.");
            return;
        }
        if (string.IsNullOrWhiteSpace(txtPromo.Text))
        {
            tabs.SelectedIndex = 1;
            MessageBox.Show("Write your promo / follow-up message in the 'Promo / follow-up' tab first.");
            return;
        }

        string today = DateTime.Now.ToString("dd/MM/yyyy");
        var counts = new int[5];
        foreach (var c in contacts)
        {
            int g = GroupOf(c);
            if (g >= 0) counts[g]++;
        }
        bool[] preset = repliedOnly
            ? new[] { false, false, true, false, false }
            : new[] { true, true, true, false, false };

        int photoCount = settings.ImagePaths.Count(File.Exists);
        string intro = repliedOnly
            ? "Send your promo / follow-up message to contacts who replied, so you can follow up with them again. Choose who is included:"
            : "Send your promo / follow-up message to many numbers, even if you chatted with them before. Choose who is included:";

        using var dlg = new PromoDialog(
            repliedOnly ? "Follow up replied contacts" : "Blast to all numbers",
            intro, counts, photoCount, preset, (int)numLimit.Value,
            (groups, skipToday) => contacts.Count(c => Eligible(c, groups, skipToday, today)));
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        var groupsPicked = dlg.Groups;
        bool skip = dlg.SkipToday;
        bool attach = dlg.AttachPhotos;
        var targets = contacts.Where(c => Eligible(c, groupsPicked, skip, today)).ToList();
        if (targets.Count == 0) return;

        await RunBatch(targets, txtPromo.Text, true, attach);
    }

    private async Task RunBatch(List<Contact> targets, string template, bool promo, bool attach)
    {
        int limit = (int)numLimit.Value;
        autoRunning = true;
        cts = new CancellationTokenSource();
        var ct = cts.Token;
        SetAutoUi(true);
        batchNoWa = 0;

        int sentCount = 0;
        string endMsg = "Finished.";
        try
        {
            for (int i = 0; i < targets.Count; i++)
            {
                var c = targets[i];
                if (sentCount >= limit)
                {
                    endMsg = $"Session limit of {limit} reached. Continue later.";
                    break;
                }
                ct.ThrowIfCancellationRequested();

                var res = await SendOne(c, template, promo, attach, ct);
                UpdateProgress();

                if (res == SendResult.Failed)
                {
                    endMsg = $"Stopped: failed at \"{c.Name}\" (WhatsApp Desktop is not open or not active). You can try this contact again.";
                    break;
                }
                if (res == SendResult.Sent) sentCount++;

                if (res == SendResult.Sent && i + 1 < targets.Count && sentCount < limit)
                {
                    // Cek ulang jam aman di tengah batch
                    if (!IsWithinSafeHours())
                    {
                        endMsg = $"Stopped: outside safe hours ({numHourStart.Value:00}:00–{numHourEnd.Value:00}:00). Continue later.";
                        break;
                    }

                    int lo = (int)Math.Min(numAutoMin.Value, numAutoMax.Value);
                    int hi = (int)Math.Max(numAutoMin.Value, numAutoMax.Value);
                    int d = rnd.Next(lo, hi + 1);
                    // Kadang jeda ekstra agar pola tidak terlalu teratur (lebih natural)
                    if (rnd.Next(100) < 20) d += rnd.Next(15, 45);

                    for (int s = d; s > 0; s--)
                    {
                        lblInfo.Text = $"Sent this session: {sentCount}. Waiting {s} sec before the next contact...";
                        await Task.Delay(1000, ct);
                    }
                }
            }
        }
        catch (OperationCanceledException)
        {
            endMsg = "Stopped by you.";
        }
        finally
        {
            autoRunning = false;
            cts?.Dispose();
            cts = null;
            SetAutoUi(false);
        }

        if (batchNoWa > 0) endMsg += $" {batchNoWa} number(s) were not on WhatsApp and were skipped.";
        lblInfo.Text = $"{endMsg}\r\nSent this session: {sentCount}.";
        ApplyFilter();
        UpdateProgress();
        Activate();
    }

    /// <summary>Copies the chat input text and checks it matches our message, i.e. the chat really opened.</summary>
    private async Task<bool> VerifyChatOpen(string msg, CancellationToken ct)
    {
        static string Norm(string t) => new string(t.Where(ch => !char.IsWhiteSpace(ch)).ToArray());
        var expected = Norm(msg);
        if (expected.Length == 0) return true;
        if (expected.Length > 25) expected = expected[..25];

        for (int attempt = 0; attempt < 3; attempt++)
        {
            try { Clipboard.SetText("__rs_check__"); } catch { }
            SendKeys.SendWait("^a");
            await Task.Delay(200, ct);
            SendKeys.SendWait("^c");
            await Task.Delay(400, ct);

            string got = "";
            try { got = Clipboard.GetText(); } catch { }
            if (Norm(got).Contains(expected, StringComparison.OrdinalIgnoreCase)) return true;

            await Task.Delay(1200, ct);
        }
        return false;
    }

    private async Task<SendResult> SendOne(Contact c, string template, bool promo, bool attach, CancellationToken ct)
    {
        var phone = Normalize(c.Phone);
        if (phone == null)
        {
            if (!promo)
            {
                c.Status = string.IsNullOrWhiteSpace(c.Phone) ? "No number" : "Invalid number";
                SaveStatus(c);
            }
            return SendResult.Skipped;
        }
        if (!promo && CheckAlreadyContacted(c, true))
            return SendResult.Skipped;

        try
        {
            if (!promo) c.Status = "Sending";
            lblInfo.Text = $"Sending to {c.Name} ({phone})...";

            var files = attach ? settings.ImagePaths.Where(File.Exists).ToArray() : Array.Empty<string>();
            var msg = Fill(template, c.Name);

            if (!Open($"whatsapp://send?phone={phone}&text={Uri.EscapeDataString(msg)}"))
            {
                if (!promo) c.Status = "Not contacted";
                return SendResult.Failed;
            }

            await Task.Delay((int)numWait.Value * 1000, ct);

            for (int i = 0; i < 10 && !WhatsAppIsActive(); i++)
                await Task.Delay(500, ct);
            if (!WhatsAppIsActive())
            {
                if (!promo) c.Status = "Not contacted";
                return SendResult.Failed;
            }

            // Make sure the chat really opened with our text. If not (for example the number
            // is not on WhatsApp), close the dialog, mark it and move on to the next contact.
            if (!await VerifyChatOpen(msg, ct))
            {
                SendKeys.SendWait("{ESC}");
                await Task.Delay(500, ct);
                SendKeys.SendWait("{ENTER}");
                await Task.Delay(1200, ct);
                if (promo)
                {
                    batchNoWa++;
                }
                else
                {
                    c.Status = "Not on WhatsApp";
                    SaveStatus(c);
                }
                return SendResult.Skipped;
            }

            if (files.Length > 0)
            {
                var list = new System.Collections.Specialized.StringCollection();
                list.AddRange(files);
                Clipboard.SetFileDropList(list);
            }

            SendKeys.SendWait("{ENTER}");          // send the text
            await Task.Delay(1500, ct);

            if (files.Length > 0)
            {
                if (!WhatsAppIsActive())
                {
                    if (!promo) { c.Status = "Check manually"; SaveStatus(c); }
                    return SendResult.Failed;
                }
                SendKeys.SendWait("^v");           // paste all photos
                await Task.Delay(2500 + 700 * files.Length, ct);

                if (!WhatsAppIsActive())
                {
                    if (!promo) { c.Status = "Check manually"; SaveStatus(c); }
                    return SendResult.Failed;
                }
                SendKeys.SendWait("{ENTER}");      // send the photos
                await Task.Delay(2000, ct);
            }

            if (promo)
            {
                c.PromoDate = DateTime.Now.ToString("dd/MM/yyyy");
                if (c.Status == "Not contacted") c.Status = "Contacted";
            }
            else
            {
                c.Status = "Contacted";
            }
            SaveStatus(c);
            AddHistory(c, promo ? "Promo sent from Ran JS" : "Sent from Ran JS");
            return SendResult.Sent;
        }
        catch (OperationCanceledException)
        {
            if (!promo && c.Status == "Sending") c.Status = "Not contacted";
            throw;
        }
    }

    // ------------------------------------------------------------------ progress
    private void UpdateProgress()
    {
        int total = contacts.Count;
        int done = contacts.Count(c => IsContactedStatus(c.Status));
        int before = contacts.Count(c => c.Status.StartsWith("Contacted before"));
        lblProgress.Text = $"Progress: {done}/{total} contacted" + (before > 0 ? $" \u00b7 {before} before" : "");
    }
}
