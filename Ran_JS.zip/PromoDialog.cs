namespace RamahSnackSender;

/// <summary>Lets the user choose who receives a promo / follow-up message.</summary>
public class PromoDialog : Form
{
    private readonly CheckBox[] boxes = new CheckBox[5];
    private readonly CheckBox chkToday = new();
    private readonly CheckBox chkPhotos = new();
    private readonly Label lblCount = new();
    private readonly Button btnStart = new();
    private readonly int sessionLimit;
    private readonly Func<bool[], bool, int> countFunc;
    private readonly ToolTip tip = new() { InitialDelay = 250, AutoPopDelay = 9000, ShowAlways = true };

    public bool[] Groups => boxes.Select(b => b.Checked).ToArray();
    public bool SkipToday => chkToday.Checked;
    public bool AttachPhotos => chkPhotos.Checked;

    public PromoDialog(string title, string intro, int[] groupCounts, int photoCount,
                       bool[] preset, int sessionLimit, Func<bool[], bool, int> countFunc)
    {
        this.sessionLimit = sessionLimit;
        this.countFunc = countFunc;

        Text = title;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = false;
        ClientSize = new Size(460, 520);
        Font = new Font("Segoe UI", 9.5f);

        Controls.Add(new Label { Text = intro, Left = 16, Top = 14, Width = 428, Height = 58 });

        string[] names =
        {
            "Not contacted yet",
            "Contacted / contacted before",
            "Replied / Deal",
            "Not interested",
            "Skipped / needs manual check"
        };
        string[] tips =
        {
            "Contacts you have not messaged yet.",
            "Contacts you already messaged, including numbers found in your history.",
            "Contacts who replied or became a deal. Best group for a follow-up.",
            "Contacts who said they are not interested. Unchecked by default - think twice before messaging them.",
            "Contacts you chose to skip, or that need a manual check."
        };

        int y = 84;
        for (int i = 0; i < boxes.Length; i++)
        {
            boxes[i] = new CheckBox
            {
                Text = $"{names[i]}   ({groupCounts[i]})",
                Left = 24, Top = y, Width = 420, Checked = preset[i]
            };
            boxes[i].CheckedChanged += (_, _) => UpdateCount();
            tip.SetToolTip(boxes[i], tips[i]);
            Controls.Add(boxes[i]);
            y += 30;
        }

        Controls.Add(new Label
        {
            Text = "Never included: no number, invalid number, or numbers not on WhatsApp.",
            Left = 24, Top = y, Width = 420, Height = 22, ForeColor = Color.DimGray
        });
        y += 34;

        chkToday.Text = "Skip contacts that already got a promo today";
        chkToday.Left = 24; chkToday.Top = y; chkToday.Width = 420; chkToday.Checked = true;
        chkToday.CheckedChanged += (_, _) => UpdateCount();
        tip.SetToolTip(chkToday, "Useful when you stop and continue later: nobody receives the same promo twice in one day.");
        Controls.Add(chkToday);
        y += 30;

        chkPhotos.Text = $"Attach photos ({photoCount} selected)";
        chkPhotos.Left = 24; chkPhotos.Top = y; chkPhotos.Width = 420;
        chkPhotos.Checked = photoCount > 0;
        chkPhotos.Enabled = photoCount > 0;
        tip.SetToolTip(chkPhotos, "Attach the photos you selected in the main window to each message.");
        Controls.Add(chkPhotos);
        y += 40;

        lblCount.Left = 24; lblCount.Top = y; lblCount.Width = 420; lblCount.Height = 44;
        lblCount.Font = new Font(Font, FontStyle.Bold);
        Controls.Add(lblCount);
        y += 52;

        Controls.Add(new Label
        {
            Text = "Messages are sent automatically through WhatsApp Desktop - do not type while it runs. " +
                   "Promos sent to people who did not ask for them can get your number restricted, so keep the session limit low.",
            Left = 24, Top = y, Width = 412, Height = 66, ForeColor = Color.FromArgb(150, 90, 0)
        });

        btnStart.Text = "Start sending";
        btnStart.Left = 24; btnStart.Top = 462; btnStart.Width = 240; btnStart.Height = 40;
        btnStart.DialogResult = DialogResult.OK;
        btnStart.UseMnemonic = false;
        btnStart.BackColor = Color.FromArgb(37, 211, 102);
        btnStart.FlatStyle = FlatStyle.Flat;
        btnStart.Font = new Font(Font, FontStyle.Bold);
        tip.SetToolTip(btnStart, "Start sending to everyone matching your selection (up to the session limit).");

        var btnCancel = new Button
        {
            Text = "Cancel", Left = 276, Top = 462, Width = 160, Height = 40,
            DialogResult = DialogResult.Cancel, UseMnemonic = false
        };
        tip.SetToolTip(btnCancel, "Close this window without sending anything.");

        Controls.Add(btnStart);
        Controls.Add(btnCancel);
        CancelButton = btnCancel;

        UpdateCount();
    }

    private void UpdateCount()
    {
        int matching = countFunc(Groups, SkipToday);
        int willSend = Math.Min(matching, sessionLimit);
        lblCount.Text = $"Will send to {willSend} contact(s) this session\r\n({matching} match, session limit {sessionLimit})";
        btnStart.Enabled = willSend > 0;
    }
}
