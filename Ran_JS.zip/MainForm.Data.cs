using System.Text.Json;
using ClosedXML.Excel;

namespace RamahSnackSender;

public partial class MainForm
{
    // Semua file penting disimpan di C:\RanJs (tetap, tidak ikut lokasi .exe)
    private static readonly string DataDir = @"C:\RanJs";

    private readonly string settingsPath = Path.Combine(DataDir, "settings.json");
    private AppSettings settings = new();

    private readonly string historyPath = Path.Combine(DataDir, "history.json");
    private readonly string notesPath = Path.Combine(DataDir, "notes.json");
    // path lama (untuk migrasi otomatis dari versi sebelumnya)
    private static readonly string OldAppData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
    private readonly string oldHistoryPath = Path.Combine(OldAppData, "RanJS", "history.json");
    private readonly string oldHistoryPath2 = Path.Combine(OldAppData, "RamahSnackSender", "riwayat_kontak.json");
    private Dictionary<string, HistoryEntry> history = new();
    private Dictionary<string, string> notes = new(); // phone normalized -> note

    private string excelPath = "";
    private int headerRow = 0, colName = 2, colPhone = 3, colStatus = 4, colDate = 0, colPromo = 0, colPromoNew = 0;

    private static readonly string[] NameKeys = { "nama", "name" };
    private static readonly string[] PhoneKeys =
        { "kontak", "nomor", "telepon", "telp", "whatsapp", "hp", "phone", "contact", "number", "mobile" };

    // ------------------------------------------------------------------ settings
    private void LoadSettings()
    {
        try
        {
            Directory.CreateDirectory(DataDir); // pastikan folder C:\RanJs ada
            if (File.Exists(settingsPath))
                settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(settingsPath)) ?? new AppSettings();
            if (settings.SavedTemplates == null || settings.SavedTemplates.Count == 0)
                settings.SavedTemplates = new AppSettings().SavedTemplates;
        }
        catch { settings = new AppSettings(); }
        LoadNotes();
    }

    private void LoadNotes()
    {
        try
        {
            Directory.CreateDirectory(DataDir);
            if (File.Exists(notesPath))
            {
                var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(notesPath));
                notes = dict ?? new();
            }
        }
        catch { notes = new(); }
    }

    private void SaveNotes()
    {
        try
        {
            Directory.CreateDirectory(DataDir);
            File.WriteAllText(notesPath,
                JsonSerializer.Serialize(notes, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { /* ignore */ }
    }

    private void ApplyNoteToContact(Contact c)
    {
        var ph = Normalize(c.Phone);
        if (ph != null && notes.TryGetValue(ph, out var n))
            c.Note = n;
        else
            c.Note = "";
    }

    private void SetNoteForContact(Contact c, string note)
    {
        c.Note = note ?? "";
        var ph = Normalize(c.Phone);
        if (ph == null) return;
        if (string.IsNullOrWhiteSpace(note))
            notes.Remove(ph);
        else
            notes[ph] = note.Trim();
        SaveNotes();
    }

    private void SaveSettings()
    {
        try
        {
            settings.Template = txtTemplate.Text;
            settings.PromoTemplate = txtPromo.Text;
            // SavedTemplates sudah di-update lewat SaveCurrentAsTemplate / DeleteSelectedTemplate
            settings.MinDelay = (int)numMin.Value;
            settings.MaxDelay = (int)numMax.Value;
            settings.UseDesktop = chkDesktop.Checked;
            settings.AutoMin = (int)numAutoMin.Value;
            settings.AutoMax = (int)numAutoMax.Value;
            settings.AutoLimit = (int)numLimit.Value;
            settings.AutoWait = (int)numWait.Value;
            settings.ExcelPath = excelPath;
            settings.SafeHourStart = (int)numHourStart.Value;
            settings.SafeHourEnd = (int)numHourEnd.Value;

            Directory.CreateDirectory(DataDir); // pastikan folder C:\RanJs ada
            File.WriteAllText(settingsPath,
                JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { /* ignore */ }
    }

    /// <summary>True jika jam sekarang di dalam rentang aman pengiriman.</summary>
    private bool IsWithinSafeHours()
    {
        int h = DateTime.Now.Hour;
        int start = (int)numHourStart.Value;
        int end = (int)numHourEnd.Value;
        if (start == end) return true; // 24 jam
        if (start < end) return h >= start && h < end;
        // rentang melewati tengah malam, misal 22–6
        return h >= start || h < end;
    }

    private bool ConfirmSafeToSend(string mode)
    {
        // Warn if delay is too short
        int autoLo = (int)Math.Min(numAutoMin.Value, numAutoMax.Value);
        if (mode == "auto" && autoLo < 30)
        {
            var r = MessageBox.Show(
                "Delay between contacts is under 30 seconds.\r\n\r\n" +
                "This is high risk of WhatsApp limiting or banning the number.\r\n" +
                "Recommended minimum: 45–90 seconds.\r\n\r\n" +
                "Continue anyway?",
                "Ban risk warning",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (r != DialogResult.Yes) return false;
        }

        int manLo = (int)Math.Min(numMin.Value, numMax.Value);
        if (mode == "manual" && manLo < 20)
        {
            var r = MessageBox.Show(
                "Manual delay is under 20 seconds. Safer to use a longer delay.\r\n\r\nContinue anyway?",
                "Warning",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (r != DialogResult.Yes) return false;
        }

        if (!IsWithinSafeHours())
        {
            var r = MessageBox.Show(
                $"Current time: {DateTime.Now:HH:mm}.\r\n" +
                $"Your safe send hours: {numHourStart.Value:00}:00 – {numHourEnd.Value:00}:00.\r\n\r\n" +
                "Sending outside these hours looks unnatural and increases ban risk.\r\n\r\n" +
                "Send now anyway?",
                "Outside safe hours",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);
            if (r != DialogResult.Yes) return false;
        }

        return true;
    }

    // ------------------------------------------------------------------ status helpers
    private static string NormalizeStatus(string raw)
    {
        var t = raw.Trim();
        var l = t.ToLowerInvariant();
        if (l.StartsWith("pernah dihubungi")) return "Contacted before" + t.Substring("pernah dihubungi".Length);
        if (l.StartsWith("contacted before")) return "Contacted before" + t.Substring("contacted before".Length);
        return l switch
        {
            "" or "belum" or "belum dihubungi" or "not contacted" or "mengirim" or "disiapkan" or "sending" or "prepared" => "Not contacted",
            "sudah chat" or "terkirim" or "contacted" or "sent" => "Contacted",
            "sudah dibalas" or "replied" => "Replied",
            "deal" => "Deal",
            "tidak berminat" or "not interested" => "Not interested",
            "dilewati" or "skipped" => "Skipped",
            "nomor tidak valid" or "invalid number" => "Invalid number",
            "tanpa nomor" or "no number" => "No number",
            "tidak ada whatsapp" or "not on whatsapp" => "Not on WhatsApp",
            "cek manual" or "check manually" => "Check manually",
            _ => t
        };
    }

    private static bool IsPending(Contact c) => c.Status is "Not contacted" or "Sending" or "Prepared";
    private static bool IsFinished(Contact c) => !IsPending(c);
    private static bool IsContactedStatus(string s) => s is "Contacted" or "Replied" or "Deal" or "Not interested";

    /// <summary>0 = not contacted, 1 = contacted, 2 = replied/deal, 3 = not interested, 4 = skipped/check, -1 = never.</summary>
    private static int GroupOf(Contact c)
    {
        if (Normalize(c.Phone) == null) return -1;
        return c.Status switch
        {
            "Not contacted" or "Sending" or "Prepared" => 0,
            "Contacted" => 1,
            var s when s.StartsWith("Contacted before") => 1,
            "Replied" or "Deal" => 2,
            "Not interested" => 3,
            "Skipped" or "Check manually" => 4,
            _ => -1
        };
    }

    private static string? Normalize(string raw)
    {
        var first = raw.Split(new[] { '/', ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
        var d = new string(first.Where(char.IsDigit).ToArray());
        if (d.Length == 0) return null;
        if (d.StartsWith("62")) { }
        else if (d.StartsWith("0")) d = "62" + d[1..];
        else if (d.StartsWith("8")) d = "62" + d;
        else return null;
        return d.Length is >= 10 and <= 15 ? d : null;
    }

    /// <summary>
    /// Ganti {name}/{nama}, lalu proses spintax {a|b|c}.
    /// Contoh: {Halo|Hai|Assalamu'alaikum} → salah satu dipilih acak.
    /// </summary>
    private static string Fill(string template, string name)
    {
        if (string.IsNullOrEmpty(template)) return template;
        var text = template.Replace("{nama}", name).Replace("{name}", name);
        return ExpandSpintax(text);
    }

    private static readonly Random SpinRnd = new();

    private static string ExpandSpintax(string text)
    {
        // Proses dari dalam ke luar untuk spintax bersarang sederhana.
        // Pola: {pilihan1|pilihan2|pilihan3}
        const int maxPasses = 20;
        for (int pass = 0; pass < maxPasses; pass++)
        {
            int open = -1;
            bool changed = false;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '{') open = i;
                else if (text[i] == '}' && open >= 0)
                {
                    var inner = text.Substring(open + 1, i - open - 1);
                    // Hanya spintax jika ada | (bukan placeholder lain)
                    if (inner.Contains('|'))
                    {
                        var options = inner.Split('|');
                        // Trim spasi di tiap opsi
                        for (int k = 0; k < options.Length; k++)
                            options[k] = options[k].Trim();
                        var pick = options[SpinRnd.Next(options.Length)];
                        text = text.Substring(0, open) + pick + text.Substring(i + 1);
                        changed = true;
                        break; // mulai ulang setelah penggantian
                    }
                    open = -1;
                }
            }
            if (!changed) break;
        }
        return text;
    }

    // ------------------------------------------------------------------ filter
    private static bool MatchesFilter(Contact c, string f) => f switch
    {
        "Not contacted" => c.Status is "Not contacted" or "Sending" or "Prepared",
        "Contacted" => c.Status == "Contacted",
        "Replied" => c.Status == "Replied",
        "Deal" => c.Status == "Deal",
        "Not interested" => c.Status == "Not interested",
        "Contacted before" => c.Status.StartsWith("Contacted before"),
        "Not on WhatsApp" => c.Status == "Not on WhatsApp",
        "No / invalid number" => c.Status is "No number" or "Invalid number",
        "Skipped / check manually" => c.Status is "Skipped" or "Check manually",
        _ => true
    };

    private void ApplyFilter()
    {
        var f = cmbFilter.SelectedItem?.ToString() ?? "All";
        view.RaiseListChangedEvents = false;
        view.Clear();
        foreach (var c in contacts)
            if (MatchesFilter(c, f)) view.Add(c);
        view.RaiseListChangedEvents = true;
        view.ResetBindings();
        lblShown.Text = $"{view.Count} of {contacts.Count} shown";
    }

    // ------------------------------------------------------------------ Excel
    private void PickExcel()
    {
        using var dlg = new OpenFileDialog { Filter = "Excel (*.xlsx)|*.xlsx", Title = "Choose your contact list" };
        if (dlg.ShowDialog() == DialogResult.OK) LoadExcel(dlg.FileName);
    }

    private static int FindCol(IXLWorksheet ws, int row, int maxCol, int exclude, params string[] keys)
    {
        for (int c = 1; c <= maxCol; c++)
        {
            if (c == exclude) continue;
            var t = ws.Cell(row, c).GetString().Trim().ToLowerInvariant();
            if (t.Length > 0 && keys.Any(k => t.Contains(k))) return c;
        }
        return 0;
    }

    private void LoadExcel(string path)
    {
        try
        {
            using var wb = new XLWorkbook(path);
            var ws = wb.Worksheets.First();
            var lastRowObj = ws.LastRowUsed();
            var lastColObj = ws.LastColumnUsed();
            if (lastRowObj == null || lastColObj == null)
            {
                MessageBox.Show("The Excel file is empty.");
                return;
            }
            int lastRow = lastRowObj.RowNumber();
            int lastCol = lastColObj.ColumnNumber();
            int maxCol = Math.Max(lastCol, 4);

            int cName = 2, cPhone = 3, cStatus = 0;
            headerRow = 0;
            for (int r = 1; r <= Math.Min(10, lastRow); r++)
            {
                int n = FindCol(ws, r, maxCol, 0, NameKeys);
                int k = n == 0 ? 0 : FindCol(ws, r, maxCol, n, PhoneKeys);
                if (n > 0 && k > 0)
                {
                    headerRow = r; cName = n; cPhone = k;
                    cStatus = FindCol(ws, r, maxCol, 0, "status");
                    break;
                }
            }
            if (headerRow == 0) cStatus = 4;
            else if (cStatus == 0) cStatus = lastCol + 1;
            colName = cName; colPhone = cPhone; colStatus = cStatus;
            colDate = headerRow > 0 ? FindCol(ws, headerRow, maxCol, 0, "tanggal", "date") : 0;
            colPromo = headerRow > 0 ? FindCol(ws, headerRow, maxCol, 0, "promo") : 0;
            colPromoNew = Math.Max(Math.Max(lastCol, colStatus), colDate) + 1;

            contacts.Clear();
            for (int r = headerRow + 1; r <= lastRow; r++)
            {
                var name = ws.Cell(r, cName).GetFormattedString().Trim();
                var phone = ws.Cell(r, cPhone).GetFormattedString().Trim();
                if (name.Length == 0 && phone.Length == 0) continue;
                var contact = new Contact
                {
                    Row = r,
                    No = (contacts.Count + 1).ToString(),
                    Name = name,
                    Phone = phone,
                    DateText = colDate > 0 ? ws.Cell(r, colDate).GetString().Trim() : "",
                    PromoDate = colPromo > 0 ? ws.Cell(r, colPromo).GetString().Trim() : "",
                    Status = NormalizeStatus(ws.Cell(r, colStatus).GetString())
                };
                ApplyNoteToContact(contact);
                contacts.Add(contact);
            }

            excelPath = path;
            lblFile.Text = Path.GetFileName(path);
            current = null;
            btnSent.Enabled = btnSkip.Enabled = false;

            // numbers already marked as contacted in this file go into the history
            foreach (var c in contacts.Where(c => IsContactedStatus(c.Status)))
                AddHistory(c, Path.GetFileName(path), false);
            SaveHistory();
            UpdateHistoryLabel();

            // flag numbers contacted in earlier tasks / files
            int dup = FlagKnownContacts();
            ApplyFilter();
            UpdateProgress();
            if (dup > 0)
                lblInfo.Text = $"{dup} contact(s) will not be messaged because the number was contacted before (status: Contacted before).";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not read the Excel file. Close it in Excel first if it is open.\r\n\r\n" + ex.Message);
        }
    }

    private bool SaveRows(IEnumerable<Contact> list)
    {
        if (string.IsNullOrEmpty(excelPath)) return false;
        try
        {
            using var wb = new XLWorkbook(excelPath);
            var ws = wb.Worksheets.First();
            if (headerRow > 0 && ws.Cell(headerRow, colStatus).IsEmpty()) ws.Cell(headerRow, colStatus).Value = "Status";
            foreach (var c in list)
            {
                ws.Cell(c.Row, colStatus).Value = c.Status;
                if (colDate > 0 && c.Status == "Contacted" && ws.Cell(c.Row, colDate).IsEmpty())
                    ws.Cell(c.Row, colDate).Value = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
                if (c.PromoDate.Length > 0 && headerRow > 0)
                {
                    if (colPromo == 0)
                    {
                        colPromo = colPromoNew;
                        ws.Cell(headerRow, colPromo).Value = "Last promo";
                    }
                    ws.Cell(c.Row, colPromo).Value = c.PromoDate;
                }
            }
            wb.Save();
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not save the status to Excel. Close the file in Excel if it is open, then try again.\r\n\r\n" + ex.Message);
            return false;
        }
    }

    private bool SaveStatus(Contact c) => SaveRows(new[] { c });

    private void SetStatusForSelected(string newStatus)
    {
        if (autoRunning)
        {
            MessageBox.Show("Wait for the automatic run to finish, or click STOP first.");
            return;
        }
        var rows = grid.SelectedRows.Cast<DataGridViewRow>()
            .Select(r => r.DataBoundItem).OfType<Contact>()
            .Where(c => c != current).ToList();
        if (rows.Count == 0)
        {
            MessageBox.Show("Select one or more rows in the table first.");
            return;
        }

        foreach (var c in rows) c.Status = newStatus;
        if (newStatus == "Not contacted")
        {
            // the user wants to message them again on purpose -> remove from history
            foreach (var c in rows)
            {
                var ph = Normalize(c.Phone);
                if (ph != null) history.Remove(ph);
            }
            SaveHistory();
            UpdateHistoryLabel();
        }
        else if (IsContactedStatus(newStatus))
        {
            foreach (var c in rows) AddHistory(c, "Marked manually", false);
            SaveHistory();
            UpdateHistoryLabel();
        }
        SaveRows(rows);
        ApplyFilter();
        UpdateProgress();
        lblInfo.Text = $"{rows.Count} contact(s) changed to \"{newStatus}\".";
    }

    // ------------------------------------------------------------------ history
    private void LoadHistory()
    {
        try
        {
            Directory.CreateDirectory(DataDir); // pastikan folder C:\RanJs ada

            // Migrasi otomatis dari lokasi lama (jika belum ada history di C:\RanJs)
            if (!File.Exists(historyPath))
            {
                if (File.Exists(oldHistoryPath))
                    File.Copy(oldHistoryPath, historyPath);
                else if (File.Exists(oldHistoryPath2))
                    File.Copy(oldHistoryPath2, historyPath);
            }

            if (File.Exists(historyPath))
            {
                var list = JsonSerializer.Deserialize<List<HistoryEntry>>(File.ReadAllText(historyPath)) ?? new();
                history = list.Where(h => h.Phone.Length > 0).GroupBy(h => h.Phone).ToDictionary(g => g.Key, g => g.First());
            }
        }
        catch { history = new(); }
    }

    private void SaveHistory()
    {
        try
        {
            Directory.CreateDirectory(DataDir); // pastikan folder C:\RanJs ada
            File.WriteAllText(historyPath,
                JsonSerializer.Serialize(history.Values.ToList(), new JsonSerializerOptions { WriteIndented = true }));
        }
        catch { /* ignore */ }
    }

    private void UpdateHistoryLabel() =>
        lblHistory.Text = $"History: {history.Count} number(s) contacted before";

    private void AddHistory(Contact c, string source, bool save = true)
    {
        var phone = Normalize(c.Phone);
        if (phone == null || history.ContainsKey(phone)) return;
        history[phone] = new HistoryEntry
        {
            Phone = phone,
            Nama = c.Name,
            Tanggal = c.DateText.Length > 0 ? c.DateText : DateTime.Now.ToString("dd/MM/yyyy HH:mm"),
            Sumber = source
        };
        if (save)
        {
            SaveHistory();
            UpdateHistoryLabel();
        }
    }

    private static string DateOnlyText(string t) => t.Length >= 10 ? t[..10] : t;

    private bool CheckAlreadyContacted(Contact c, bool save)
    {
        if (!IsPending(c)) return false;
        var phone = Normalize(c.Phone);
        if (phone == null || !history.TryGetValue(phone, out var h)) return false;
        c.Status = $"Contacted before ({DateOnlyText(h.Tanggal)})";
        if (save) SaveStatus(c);
        return true;
    }

    private int FlagKnownContacts()
    {
        var changed = new List<Contact>();
        foreach (var c in contacts)
            if (CheckAlreadyContacted(c, false)) changed.Add(c);
        if (changed.Count > 0) SaveRows(changed);
        return changed.Count;
    }

    private void ImportHistory()
    {
        using var dlg = new OpenFileDialog
        {
            Filter = "Excel (*.xlsx)|*.xlsx",
            Title = "Choose old Excel files (you can pick several)",
            Multiselect = true
        };
        if (dlg.ShowDialog() != DialogResult.OK) return;

        int added = 0, already = 0;
        var problems = new List<string>();
        foreach (var f in dlg.FileNames)
        {
            try
            {
                using var wb = new XLWorkbook(f);
                var ws = wb.Worksheets.First();
                var lr = ws.LastRowUsed();
                var lc = ws.LastColumnUsed();
                if (lr == null || lc == null) continue;
                int lastRow = lr.RowNumber();
                int maxCol = Math.Max(lc.ColumnNumber(), 4);

                int hdr = 0, cName = 2, cPhone = 3, cStatus = 0, cDate = 0;
                for (int r = 1; r <= Math.Min(10, lastRow); r++)
                {
                    int n = FindCol(ws, r, maxCol, 0, NameKeys);
                    int k = n == 0 ? 0 : FindCol(ws, r, maxCol, n, PhoneKeys);
                    if (n > 0 && k > 0)
                    {
                        hdr = r; cName = n; cPhone = k;
                        cStatus = FindCol(ws, r, maxCol, 0, "status");
                        cDate = FindCol(ws, r, maxCol, 0, "tanggal", "date");
                        break;
                    }
                }

                bool allContacted = false;
                if (hdr == 0 || cStatus == 0)
                {
                    var ask = MessageBox.Show(
                        $"\"{Path.GetFileName(f)}\" has no status column.\r\n\r\nTreat ALL numbers in this file as already contacted?",
                        "Import history", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (ask != DialogResult.Yes) continue;
                    allContacted = true;
                }

                for (int r = hdr + 1; r <= lastRow; r++)
                {
                    var status = cStatus > 0 ? NormalizeStatus(ws.Cell(r, cStatus).GetString()) : "";
                    if (!allContacted && !IsContactedStatus(status) && !status.StartsWith("Contacted before")) continue;
                    var phone = Normalize(ws.Cell(r, cPhone).GetFormattedString());
                    if (phone == null) continue;
                    if (history.ContainsKey(phone)) { already++; continue; }
                    var date = cDate > 0 ? ws.Cell(r, cDate).GetString().Trim() : "";
                    history[phone] = new HistoryEntry
                    {
                        Phone = phone,
                        Nama = ws.Cell(r, cName).GetFormattedString().Trim(),
                        Tanggal = date.Length > 0 ? date : DateTime.Now.ToString("dd/MM/yyyy HH:mm"),
                        Sumber = Path.GetFileName(f)
                    };
                    added++;
                }
            }
            catch (Exception ex)
            {
                problems.Add($"{Path.GetFileName(f)}: {ex.Message}");
            }
        }

        SaveHistory();
        UpdateHistoryLabel();
        int flagged = FlagKnownContacts();
        ApplyFilter();
        UpdateProgress();

        var msg = $"{added} new number(s) added to the history ({already} were already there).";
        if (flagged > 0) msg += $"\r\n{flagged} contact(s) in the current list were marked 'Contacted before'.";
        if (problems.Count > 0) msg += "\r\n\r\nCould not read (close them in Excel first):\r\n" + string.Join("\r\n", problems);
        MessageBox.Show(msg, "Import history");
    }

    // ------------------------------------------------------------------ notes
    private void EditNoteForSelected()
    {
        var rows = grid.SelectedRows.Cast<DataGridViewRow>()
            .Select(r => r.DataBoundItem).OfType<Contact>().ToList();
        if (rows.Count == 0)
        {
            MessageBox.Show("Select one row first.");
            return;
        }
        if (rows.Count > 1)
        {
            MessageBox.Show("Select only one contact to edit the note.");
            return;
        }
        var c = rows[0];
        using var f = new Form
        {
            Text = $"Note — {c.Name}",
            Width = 480,
            Height = 280,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false,
            MinimizeBox = false,
            Font = Font
        };
        var lbl = new Label
        {
            Text = $"Note for: {c.Name} ({c.Phone})\r\nExample: promised visit Monday, asked for samples, etc.",
            Left = 12, Top = 10, Width = 440, Height = 40
        };
        var box = new TextBox
        {
            Multiline = true, ScrollBars = ScrollBars.Vertical,
            Left = 12, Top = 55, Width = 440, Height = 130,
            Text = c.Note
        };
        var btnOk = new Button { Text = "Save", Left = 250, Top = 200, Width = 90, DialogResult = DialogResult.OK };
        var btnCancel = new Button { Text = "Cancel", Left = 350, Top = 200, Width = 90, DialogResult = DialogResult.Cancel };
        f.Controls.AddRange(new Control[] { lbl, box, btnOk, btnCancel });
        f.AcceptButton = btnOk;
        f.CancelButton = btnCancel;
        if (f.ShowDialog(this) != DialogResult.OK) return;
        SetNoteForContact(c, box.Text);
        ApplyFilter();
        lblInfo.Text = $"Note saved for {c.Name}.";
    }

    // ------------------------------------------------------------------ export report
    private void ExportReport()
    {
        if (contacts.Count == 0)
        {
            MessageBox.Show("Import an Excel file first.");
            return;
        }
        using var dlg = new SaveFileDialog
        {
            Filter = "Excel (*.xlsx)|*.xlsx",
            Title = "Save report",
            FileName = $"RanJS_Report_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
        };
        if (dlg.ShowDialog() != DialogResult.OK) return;

        try
        {
            using var wb = new XLWorkbook();
            var sum = wb.Worksheets.Add("Summary");
            sum.Cell(1, 1).Value = "Ran JS Report";
            sum.Cell(1, 1).Style.Font.Bold = true;
            sum.Cell(1, 1).Style.Font.FontSize = 14;
            sum.Cell(2, 1).Value = "Created";
            sum.Cell(2, 2).Value = DateTime.Now.ToString("dd/MM/yyyy HH:mm");
            sum.Cell(3, 1).Value = "Source file";
            sum.Cell(3, 2).Value = string.IsNullOrEmpty(excelPath) ? "-" : Path.GetFileName(excelPath);
            sum.Cell(4, 1).Value = "Total contacts";
            sum.Cell(4, 2).Value = contacts.Count;

            var groups = contacts.GroupBy(c => c.Status.StartsWith("Contacted before") ? "Contacted before" : c.Status)
                .OrderByDescending(g => g.Count()).ToList();
            sum.Cell(6, 1).Value = "Status";
            sum.Cell(6, 2).Value = "Count";
            sum.Cell(6, 1).Style.Font.Bold = true;
            sum.Cell(6, 2).Style.Font.Bold = true;
            int row = 7;
            foreach (var g in groups)
            {
                sum.Cell(row, 1).Value = g.Key;
                sum.Cell(row, 2).Value = g.Count();
                row++;
            }
            row += 1;
            sum.Cell(row, 1).Value = "Contacted (Contacted+Replied+Deal+Not interested)";
            sum.Cell(row, 2).Value = contacts.Count(c => IsContactedStatus(c.Status));
            row++;
            sum.Cell(row, 1).Value = "Not contacted yet";
            sum.Cell(row, 2).Value = contacts.Count(c => IsPending(c));
            sum.Columns().AdjustToContents();

            var det = wb.Worksheets.Add("Contacts");
            string[] headers = { "No", "Name", "Phone", "Status", "Date", "Last promo", "Note" };
            for (int i = 0; i < headers.Length; i++)
            {
                det.Cell(1, i + 1).Value = headers[i];
                det.Cell(1, i + 1).Style.Font.Bold = true;
            }
            int r = 2;
            foreach (var c in contacts)
            {
                det.Cell(r, 1).Value = c.No;
                det.Cell(r, 2).Value = c.Name;
                det.Cell(r, 3).Value = c.Phone;
                det.Cell(r, 4).Value = c.Status;
                det.Cell(r, 5).Value = c.DateText;
                det.Cell(r, 6).Value = c.PromoDate;
                det.Cell(r, 7).Value = c.Note;
                r++;
            }
            det.Columns().AdjustToContents();
            det.Column(7).Width = 40;

            wb.SaveAs(dlg.FileName);
            MessageBox.Show($"Report saved:\r\n{dlg.FileName}", "Export report");
            lblInfo.Text = "Excel report exported successfully.";
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not save the report:\r\n" + ex.Message);
        }
    }
}
