using System.ComponentModel;

namespace RamahSnackSender;

public partial class MainForm : Form
{
    private const string WebsiteUrl = "https://ranhunt-bot.web.app/";

    private readonly List<Contact> contacts = new();
    private readonly BindingList<Contact> view = new();

    private readonly DataGridView grid = new();
    private readonly ComboBox cmbFilter = new();
    private readonly Label lblShown = new();

    private readonly TabControl tabs = new();
    private readonly TextBox txtTemplate = new();
    private readonly TextBox txtPromo = new();
    private readonly ComboBox cmbTemplate = new();
    private readonly Button btnSaveTpl = new();
    private readonly Button btnDelTpl = new();
    private readonly Button btnExport = new();

    private readonly Label lblFile = new();
    private readonly Label lblHistory = new();
    private readonly Label lblPhotos = new();
    private readonly FlowLayoutPanel thumbs = new();
    private readonly List<Image> thumbImages = new();

    private readonly NumericUpDown numMin = new();
    private readonly NumericUpDown numMax = new();
    private readonly NumericUpDown numAutoMin = new();
    private readonly NumericUpDown numAutoMax = new();
    private readonly NumericUpDown numLimit = new();
    private readonly NumericUpDown numWait = new();
    private readonly NumericUpDown numHourStart = new();
    private readonly NumericUpDown numHourEnd = new();
    private readonly CheckBox chkDesktop = new();

    private readonly Button btnPrepare = new();
    private readonly Button btnSent = new();
    private readonly Button btnSkip = new();
    private readonly Button btnAuto = new();
    private readonly Button btnStop = new();
    private readonly Button btnFollow = new();
    private readonly Button btnBlast = new();

    private readonly Label lblProgress = new();
    private readonly Label lblInfo = new();

    private readonly ToolTip tip = new() { InitialDelay = 250, ReshowDelay = 100, AutoPopDelay = 9000, ShowAlways = true };
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 1000 };

    public MainForm()
    {
        Text = "Ran JS - Semi-automatic WhatsApp Sender";
        Width = 1300;
        Height = 900;
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9.5f);
        try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }

        LoadSettings();
        LoadHistory();
        BuildUi();
        ApplySettingsToUi();
        UpdateHistoryLabel();

        timer.Tick += (_, _) => Tick();
        FormClosing += (_, _) => { cts?.Cancel(); SaveSettings(); };

        if (File.Exists(settings.ExcelPath)) LoadExcel(settings.ExcelPath);
        else ApplyFilter();
        UpdateProgress();
    }

    // ------------------------------------------------------------------ tooltips
    private void Tip(Control c, string text)
    {
        tip.SetToolTip(c, text);
        foreach (Control child in c.Controls) Tip(child, text);
    }

    // ------------------------------------------------------------------ UI
    private void BuildUi()
    {
        // ---------- right-hand control panel (wider so buttons/text are not cut off) ----------
        const int panelW = 460;
        const int contentW = 430;
        var panel = new Panel { Dock = DockStyle.Right, Width = panelW, Padding = new Padding(10), AutoScroll = true };
        int y = 8;

        Label AddLabel(string text, int height = 22, bool bold = false)
        {
            var l = new Label { Text = text, Left = 10, Top = y, Width = contentW, Height = height };
            if (bold) l.Font = new Font(Font, FontStyle.Bold);
            panel.Controls.Add(l);
            y += height + 2;
            return l;
        }

        Button AddButton(string text, int left, int width, int height, string help, EventHandler click)
        {
            var b = new Button { Text = text, Left = left, Top = y, Width = width, Height = height, UseMnemonic = false };
            b.Click += click;
            panel.Controls.Add(b);
            Tip(b, help);
            return b;
        }

        // 1. import
        AddButton("1. Import Excel (.xlsx)", 10, contentW, 36,
            "Load your contact list. It needs a name column and a phone column. Statuses are saved back into this same file, so close it in Excel first.",
            (_, _) => PickExcel());
        y += 40;

        lblFile.Left = 10; lblFile.Top = y; lblFile.Width = contentW; lblFile.Height = 20;
        lblFile.ForeColor = Color.DimGray; lblFile.Text = "(no file loaded)";
        panel.Controls.Add(lblFile);
        Tip(lblFile, "The Excel file that is currently loaded.");
        y += 26;

        AddButton("Import history...", 10, 200, 30,
            "Add numbers from older Excel files to your history, so they are never messaged twice by accident.",
            (_, _) => ImportHistory());
        btnExport.Text = "Export report...";
        btnExport.Left = 220; btnExport.Top = y; btnExport.Width = 220; btnExport.Height = 30;
        btnExport.UseMnemonic = false;
        btnExport.Click += (_, _) => ExportReport();
        panel.Controls.Add(btnExport);
        Tip(btnExport, "Export a summary and full contact list (status, notes) to a new Excel file.");
        y += 34;

        lblHistory.Left = 10; lblHistory.Top = y; lblHistory.Width = contentW; lblHistory.Height = 20;
        lblHistory.ForeColor = Color.DimGray;
        panel.Controls.Add(lblHistory);
        Tip(lblHistory, "Numbers saved in your history. They are skipped automatically when you load a new file.");
        y += 28;

        // 2. messages + multi template
        AddLabel("2. Messages  ({name} + spintax {a|b|c})");
        var lblTpl = new Label { Text = "Template:", Left = 10, Top = y + 3, Width = 70 };
        cmbTemplate.Left = 80; cmbTemplate.Top = y; cmbTemplate.Width = 200;
        cmbTemplate.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbTemplate.SelectedIndexChanged += (_, _) => OnTemplatePicked();
        btnSaveTpl.Text = "Save";
        btnSaveTpl.Left = 290; btnSaveTpl.Top = y; btnSaveTpl.Width = 65; btnSaveTpl.Height = 26;
        btnSaveTpl.UseMnemonic = false;
        btnSaveTpl.Click += (_, _) => SaveCurrentAsTemplate();
        btnDelTpl.Text = "Delete";
        btnDelTpl.Left = 360; btnDelTpl.Top = y; btnDelTpl.Width = 70; btnDelTpl.Height = 26;
        btnDelTpl.UseMnemonic = false;
        btnDelTpl.Click += (_, _) => DeleteSelectedTemplate();
        panel.Controls.AddRange(new Control[] { lblTpl, cmbTemplate, btnSaveTpl, btnDelTpl });
        Tip(cmbTemplate, "Pick a saved template. The message box below will be filled.");
        Tip(btnSaveTpl, "Save the current message text as a new template (or overwrite).");
        Tip(btnDelTpl, "Delete the selected template from the list.");
        y += 32;

        tabs.Left = 10; tabs.Top = y; tabs.Width = contentW; tabs.Height = 155;
        tabs.ShowToolTips = true;
        var pageIntro = new TabPage("Intro message") { ToolTipText = "First message to a new contact. Supports spintax {a|b|c}." };
        var pagePromo = new TabPage("Promo / follow-up") { ToolTipText = "Used by Follow up replied & Blast. Supports spintax." };
        foreach (var t in new[] { txtTemplate, txtPromo })
        {
            t.Multiline = true; t.ScrollBars = ScrollBars.Vertical; t.Dock = DockStyle.Fill;
        }
        pageIntro.Controls.Add(txtTemplate);
        pagePromo.Controls.Add(txtPromo);
        tabs.TabPages.Add(pageIntro);
        tabs.TabPages.Add(pagePromo);
        panel.Controls.Add(tabs);
        Tip(txtTemplate, "Intro message. Use {name} for the business name.\r\nSpintax: {Hello|Hi|Assalamu'alaikum} picks one at random so messages are not identical (safer from bans).");
        Tip(txtPromo, "Promo / follow-up message. Use {name} and spintax {a|b|c} so each contact gets a slightly different text.");
        y += 164;

        // 3. photos
        AddButton("3. Add photos...", 10, 300, 34,
            "Choose one or more photos (hold Ctrl or Shift to pick several). They are attached to every message.",
            (_, _) => PickImage());
        AddButton("Clear all", 320, 120, 34, "Remove all selected photos.", (_, _) => SetImages(new List<string>()));
        y += 40;

        thumbs.Left = 10; thumbs.Top = y; thumbs.Width = contentW; thumbs.Height = 82;
        thumbs.AutoScroll = true; thumbs.WrapContents = false; thumbs.FlowDirection = FlowDirection.LeftToRight;
        thumbs.BorderStyle = BorderStyle.FixedSingle;
        panel.Controls.Add(thumbs);
        Tip(thumbs, "Selected photos. Click the x on a photo to remove it.");
        y += 88;

        lblPhotos.Left = 10; lblPhotos.Top = y; lblPhotos.Width = contentW; lblPhotos.Height = 20;
        lblPhotos.ForeColor = Color.DimGray;
        panel.Controls.Add(lblPhotos);
        Tip(lblPhotos, "How many photos will be attached to each message.");
        y += 28;

        // 4. manual delay
        AddLabel("4. Random delay, MANUAL mode (seconds):");
        numMin.Left = 10; numMin.Top = y; numMin.Width = 70; numMin.Minimum = 5; numMin.Maximum = 600;
        var lblTo1 = new Label { Text = "to", Left = 90, Top = y + 3, Width = 30 };
        numMax.Left = 125; numMax.Top = y; numMax.Width = 70; numMax.Minimum = 5; numMax.Maximum = 600;
        panel.Controls.AddRange(new Control[] { numMin, lblTo1, numMax });
        Tip(numMin, "Shortest wait before the next prepare (manual mode). Recommended ≥ 45 sec.");
        Tip(numMax, "Longest wait (random between min–max). Recommended 90–180 sec.");
        y += 34;

        chkDesktop.Left = 10; chkDesktop.Top = y; chkDesktop.Width = contentW;
        chkDesktop.Text = "Use WhatsApp Desktop (otherwise Web)";
        panel.Controls.Add(chkDesktop);
        Tip(chkDesktop, "Opens chats in the WhatsApp Desktop app. If unchecked, WhatsApp Web in your browser is used (manual mode only).");
        y += 34;

        // manual buttons
        btnPrepare.Text = "PREPARE + OPEN NEXT CHAT";
        btnPrepare.Left = 10; btnPrepare.Top = y; btnPrepare.Width = contentW; btnPrepare.Height = 44;
        btnPrepare.BackColor = Color.FromArgb(37, 211, 102); btnPrepare.FlatStyle = FlatStyle.Flat;
        btnPrepare.Font = new Font(Font, FontStyle.Bold); btnPrepare.UseMnemonic = false;
        btnPrepare.Click += (_, _) => PrepareNext();
        panel.Controls.Add(btnPrepare);
        Tip(btnPrepare, "Opens the next chat with the message filled in and the photos copied. In WhatsApp press Enter, then Ctrl+V, then Enter.");
        y += 50;

        btnSent.Text = "I sent it";
        btnSent.Left = 10; btnSent.Top = y; btnSent.Width = 210; btnSent.Height = 36; btnSent.Enabled = false;
        btnSent.UseMnemonic = false;
        btnSent.Click += (_, _) => MarkCurrent("Contacted", true);
        btnSkip.Text = "Skip this contact";
        btnSkip.Left = 230; btnSkip.Top = y; btnSkip.Width = 210; btnSkip.Height = 36; btnSkip.Enabled = false;
        btnSkip.UseMnemonic = false;
        btnSkip.Click += (_, _) => MarkCurrent("Skipped", false);
        panel.Controls.AddRange(new Control[] { btnSent, btnSkip });
        Tip(btnSent, "Confirm you sent the message to this contact. Saves the status and starts the delay timer.");
        Tip(btnSkip, "Do not message this contact. The status is saved as Skipped.");
        y += 46;

        // automatic mode
        var lblAutoTitle = AddLabel("AUTOMATIC MODE (no manual Ctrl+V / Enter):", 22, true);
        Tip(lblAutoTitle, "Ran JS controls the keyboard and sends everything for you through WhatsApp Desktop.");

        var lblA1 = new Label { Text = "Delay between contacts (sec):", Left = 10, Top = y + 3, Width = 200 };
        numAutoMin.Left = 220; numAutoMin.Top = y; numAutoMin.Width = 55; numAutoMin.Minimum = 5; numAutoMin.Maximum = 600;
        var lblTo2 = new Label { Text = "-", Left = 280, Top = y + 3, Width = 12 };
        numAutoMax.Left = 295; numAutoMax.Top = y; numAutoMax.Width = 55; numAutoMax.Minimum = 5; numAutoMax.Maximum = 600;
        panel.Controls.AddRange(new Control[] { lblA1, numAutoMin, lblTo2, numAutoMax });
        Tip(lblA1, "Random wait between contacts. LONGER = SAFER. Recommended 45–90 sec or more.");
        Tip(numAutoMin, "Shortest wait. Below 30 sec is high ban risk.");
        Tip(numAutoMax, "Longest wait. Recommended 90–180 sec.");
        y += 30;

        var lblA2 = new Label { Text = "Max contacts per session:", Left = 10, Top = y + 3, Width = 200 };
        numLimit.Left = 220; numLimit.Top = y; numLimit.Width = 55; numLimit.Minimum = 1; numLimit.Maximum = 500;
        panel.Controls.AddRange(new Control[] { lblA2, numLimit });
        Tip(lblA2, "Session limit. Recommended 10–20 to keep the number safe.");
        Tip(numLimit, "Session limit. Recommended 10–20 to keep the number safe.");
        y += 30;

        var lblA3 = new Label { Text = "Wait for chat to open (sec):", Left = 10, Top = y + 3, Width = 200 };
        numWait.Left = 220; numWait.Top = y; numWait.Width = 55; numWait.Minimum = 3; numWait.Maximum = 30;
        panel.Controls.AddRange(new Control[] { lblA3, numWait });
        Tip(lblA3, "Wait after opening a chat. Increase if your PC or WhatsApp is slow.");
        Tip(numWait, "Wait after opening a chat. Increase if your PC or WhatsApp is slow.");
        y += 30;

        // Safe hours
        var lblHours = new Label { Text = "Safe send hours (0–23):", Left = 10, Top = y + 3, Width = 170 };
        numHourStart.Left = 185; numHourStart.Top = y; numHourStart.Width = 50;
        numHourStart.Minimum = 0; numHourStart.Maximum = 23;
        var lblHoursTo = new Label { Text = "to", Left = 240, Top = y + 3, Width = 25 };
        numHourEnd.Left = 270; numHourEnd.Top = y; numHourEnd.Width = 50;
        numHourEnd.Minimum = 0; numHourEnd.Maximum = 23;
        panel.Controls.AddRange(new Control[] { lblHours, numHourStart, lblHoursTo, numHourEnd });
        Tip(lblHours, "Only send in this hour range. Outside it you get a warning. Example: 8 to 20 = 08:00–20:00.");
        Tip(numHourStart, "Start hour (e.g. 8 = 08:00).");
        Tip(numHourEnd, "End hour (e.g. 20 = 20:00).");
        y += 34;

        btnAuto.Text = "SEND AUTOMATICALLY";
        btnAuto.Left = 10; btnAuto.Top = y; btnAuto.Width = 290; btnAuto.Height = 40;
        btnAuto.BackColor = Color.FromArgb(255, 193, 7); btnAuto.FlatStyle = FlatStyle.Flat;
        btnAuto.Font = new Font(Font, FontStyle.Bold); btnAuto.UseMnemonic = false;
        btnAuto.Click += (_, _) => StartAuto();
        btnStop.Text = "STOP";
        btnStop.Left = 310; btnStop.Top = y; btnStop.Width = 130; btnStop.Height = 40; btnStop.Enabled = false;
        btnStop.UseMnemonic = false;
        btnStop.Click += (_, _) => cts?.Cancel();
        panel.Controls.AddRange(new Control[] { btnAuto, btnStop });
        Tip(btnAuto, "Send the intro message to every contact that is still 'Not contacted', fully automatically.");
        Tip(btnStop, "Stop the automatic run right away.");
        y += 50;

        // promo / follow-up
        var lblPromoTitle = AddLabel("PROMO & FOLLOW-UP (even to people already chatted):", 22, true);
        Tip(lblPromoTitle, "Uses the 'Promo / follow-up' message tab. These buttons also reach contacts you already messaged.");

        btnFollow.Text = "FOLLOW UP REPLIED...";
        btnFollow.Left = 10; btnFollow.Top = y; btnFollow.Width = 210; btnFollow.Height = 40;
        btnFollow.BackColor = Color.FromArgb(168, 218, 255); btnFollow.FlatStyle = FlatStyle.Flat;
        btnFollow.Font = new Font(Font, FontStyle.Bold); btnFollow.UseMnemonic = false;
        btnFollow.Click += (_, _) => StartPromo(true);
        btnBlast.Text = "BLAST TO ALL NUMBERS...";
        btnBlast.Left = 230; btnBlast.Top = y; btnBlast.Width = 210; btnBlast.Height = 40;
        btnBlast.BackColor = Color.FromArgb(255, 170, 120); btnBlast.FlatStyle = FlatStyle.Flat;
        btnBlast.Font = new Font(Font, FontStyle.Bold); btnBlast.UseMnemonic = false;
        btnBlast.Click += (_, _) => StartPromo(false);
        panel.Controls.AddRange(new Control[] { btnFollow, btnBlast });
        Tip(btnFollow, "Send your promo / follow-up message to contacts marked Replied, so you can follow up with them again.");
        Tip(btnBlast, "Send your promo / follow-up message to many numbers, even if you chatted with them before. You choose who is included in the next window.");
        y += 50;

        lblProgress.Left = 10; lblProgress.Top = y; lblProgress.Width = contentW; lblProgress.Height = 24;
        lblProgress.Font = new Font(Font, FontStyle.Bold);
        panel.Controls.Add(lblProgress);
        Tip(lblProgress, "Contacts already messaged / total contacts in the loaded file.");
        y += 28;

        lblInfo.Left = 10; lblInfo.Top = y; lblInfo.Width = contentW; lblInfo.Height = 120;
        lblInfo.ForeColor = Color.FromArgb(0, 90, 160);
        lblInfo.Text = "How it works: click PREPARE, WhatsApp opens with your message filled in and your photos copied.\r\n" +
                       "Press Enter (sends the text), then Ctrl+V (pastes the photos), then Enter. Finally click 'I sent it'.\r\n" +
                       "Tip: double-click a row to prepare just that contact.";
        panel.Controls.Add(lblInfo);
        Tip(lblInfo, "Hints and live status messages.");

        // ---------- grid + filter bar + action bar ----------
        var leftPanel = new Panel { Dock = DockStyle.Fill };

        var top = new Panel { Dock = DockStyle.Top, Height = 42 };
        var lblShow = new Label { Text = "Show:", Left = 8, Top = 11, Width = 64, AutoSize = false };
        cmbFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbFilter.Left = 76; cmbFilter.Top = 8; cmbFilter.Width = 230;
        cmbFilter.Items.AddRange(new object[]
        {
            "All", "Not contacted", "Contacted", "Replied", "Deal", "Not interested",
            "Contacted before", "Not on WhatsApp", "No / invalid number", "Skipped / check manually"
        });
        cmbFilter.SelectedIndex = 0;
        cmbFilter.SelectedIndexChanged += (_, _) => ApplyFilter();
        lblShown.Left = 318; lblShown.Top = 11; lblShown.Width = 260; lblShown.ForeColor = Color.DimGray;
        top.Controls.AddRange(new Control[] { lblShow, cmbFilter, lblShown });
        Tip(lblShow, "Filter the table by status.");
        Tip(cmbFilter, "Filter the table by status. Choose 'Replied' to see everyone you can follow up with.");
        Tip(lblShown, "Rows shown / total rows.");

        grid.Dock = DockStyle.Fill;
        grid.AutoGenerateColumns = true;
        grid.DataSource = view;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = true;
        grid.RowHeadersVisible = false;
        grid.BackgroundColor = Color.White;
        grid.ShowCellToolTips = true;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
        ConfigureColumns();
        grid.DataBindingComplete += (_, _) => { if (!columnsConfigured) ConfigureColumns(); };
        grid.CellFormatting += Grid_CellFormatting;
        grid.CellToolTipTextNeeded += Grid_ToolTipNeeded;
        grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0 && grid.Rows[e.RowIndex].DataBoundItem is Contact c) Prepare(c);
        };
        grid.CellMouseDown += (_, e) =>
        {
            if (e.Button == MouseButtons.Right && e.RowIndex >= 0 && !grid.Rows[e.RowIndex].Selected)
            {
                grid.ClearSelection();
                grid.Rows[e.RowIndex].Selected = true;
            }
        };

        var menu = new ContextMenuStrip { ShowItemToolTips = true };
        void AddMenu(string text, string status, string help)
        {
            var item = new ToolStripMenuItem(text) { ToolTipText = help };
            item.Click += (_, _) => SetStatusForSelected(status);
            menu.Items.Add(item);
        }
        var miNote = new ToolStripMenuItem("Edit note...") { ToolTipText = "Add or edit a note for this contact." };
        miNote.Click += (_, _) => EditNoteForSelected();
        menu.Items.Add(miNote);
        menu.Items.Add(new ToolStripSeparator());
        AddMenu("Don't send (Skipped)", "Skipped", "Exclude the selected rows from sending.");
        AddMenu("Mark as Contacted", "Contacted", "Message was sent.");
        AddMenu("Mark as Replied", "Replied", "They answered you. You can follow up with them later.");
        AddMenu("Mark as Deal", "Deal", "This contact became a customer.");
        AddMenu("Mark as Not interested", "Not interested", "They declined.");
        AddMenu("Mark as Not on WhatsApp", "Not on WhatsApp", "This number has no WhatsApp account.");
        menu.Items.Add(new ToolStripSeparator());
        AddMenu("Restore to Not contacted (remove from history)", "Not contacted",
            "Reset the selected rows and delete them from history, so they can be messaged again.");
        grid.ContextMenuStrip = menu;

        var bottom = new Panel { Dock = DockStyle.Bottom, Height = 52 };
        Button BarButton(string text, int left, int width, string help, string status)
        {
            var b = new Button { Text = text, Left = left, Top = 8, Width = width, Height = 36, UseMnemonic = false };
            b.Click += (_, _) => SetStatusForSelected(status);
            bottom.Controls.Add(b);
            Tip(b, help);
            return b;
        }
        BarButton("Don't send", 6, 100, "Exclude the selected rows from sending (status: Skipped).", "Skipped");
        BarButton("Replied", 112, 85, "Mark the selected rows as Replied so you can follow up with them later.", "Replied");
        BarButton("Deal", 203, 70, "Mark as Deal (became a customer).", "Deal");
        BarButton("Not interested", 279, 115, "They declined.", "Not interested");
        BarButton("Restore", 400, 85, "Reset to Not contacted and remove from history.", "Not contacted");
        var btnNote = new Button { Text = "Note...", Left = 491, Top = 8, Width = 80, Height = 36, UseMnemonic = false };
        btnNote.Click += (_, _) => EditNoteForSelected();
        bottom.Controls.Add(btnNote);
        Tip(btnNote, "Edit the note for the selected contact (one row).");
        var hint = new Label
        {
            Text = "Ctrl/Shift = multi-select. Right-click = full menu.",
            Left = 580, Top = 17, Width = 420, ForeColor = Color.DimGray
        };
        bottom.Controls.Add(hint);
        Tip(hint, "Change status for many rows at once, or right-click for notes and more statuses.");

        leftPanel.Controls.Add(bottom);
        leftPanel.Controls.Add(top);
        leftPanel.Controls.Add(grid);
        grid.BringToFront();

        // ---------- footer ----------
        var footer = new Panel { Dock = DockStyle.Bottom, Height = 30, BackColor = Color.FromArgb(243, 247, 253) };
        var lblBrandFooter = new Label
        {
            Text = "Ran JS  \u2022  Simple \u2022 Fast \u2022 Reliable", Left = 12, Top = 6, Width = 320, Height = 20,
            ForeColor = Color.FromArgb(90, 110, 150)
        };
        var lblWeb = new Label { Text = "Website:", Top = 6, Height = 20, AutoSize = true, ForeColor = Color.FromArgb(90, 110, 150) };
        var link = new LinkLabel { Text = WebsiteUrl, Top = 6, Height = 20, AutoSize = true };
        link.Links.Add(0, WebsiteUrl.Length, WebsiteUrl);
        link.LinkClicked += (_, e) => Open(e.Link?.LinkData?.ToString() ?? WebsiteUrl);
        footer.Controls.AddRange(new Control[] { lblBrandFooter, lblWeb, link });
        void PlaceFooter()
        {
            link.Left = footer.ClientSize.Width - link.PreferredWidth - 16;
            lblWeb.Left = link.Left - lblWeb.PreferredWidth - 4;
        }
        footer.Resize += (_, _) => PlaceFooter();
        Tip(lblBrandFooter, "Ran JS - Simple, fast and reliable.");
        Tip(lblWeb, "Official Ran JS website.");
        Tip(link, "Open the Ran JS website in your browser.");

        Controls.Add(panel);
        Controls.Add(leftPanel);
        Controls.Add(footer);
        leftPanel.BringToFront();
        footer.SendToBack();
        PlaceFooter();
    }

    private bool columnsConfigured = false;

    private void ConfigureColumns()
    {
        if (grid.Columns["Phone"] == null) return;
        // Fixed widths so "Name" does not stretch endlessly; Note fills remaining space.
        ConfigureColumn("No", "No.", 42);
        ConfigureColumn("Name", "Business name", 220);
        ConfigureColumn("Phone", "Phone", 120);
        ConfigureColumn("Status", "Status", 150);
        ConfigureColumn("Note", "Note", 0); // fill remaining
        columnsConfigured = true;
    }

    private void ConfigureColumn(string name, string header, int width)
    {
        var col = grid.Columns[name];
        if (col == null) return;
        col.HeaderText = header;
        col.SortMode = DataGridViewColumnSortMode.NotSortable;
        if (width <= 0)
        {
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            col.MinimumWidth = 100;
        }
        else
        {
            col.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            col.Width = width;
        }
    }

    private void Grid_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
    {
        if (e.RowIndex < 0 || grid.Rows[e.RowIndex].DataBoundItem is not Contact c) return;
        grid.Rows[e.RowIndex].DefaultCellStyle.BackColor = c.Status switch
        {
            var s when s.StartsWith("Contacted before") => Color.FromArgb(215, 230, 250),
            "Contacted" => Color.FromArgb(220, 245, 225),
            "Replied" => Color.FromArgb(200, 240, 235),
            "Deal" => Color.FromArgb(190, 235, 190),
            "Sending" or "Prepared" => Color.FromArgb(255, 245, 200),
            "Skipped" or "Not interested" => Color.FromArgb(235, 235, 235),
            "Invalid number" or "No number" or "Not on WhatsApp" => Color.FromArgb(255, 220, 220),
            "Check manually" => Color.FromArgb(255, 210, 170),
            _ => Color.White
        };
    }

    private void Grid_ToolTipNeeded(object? sender, DataGridViewCellToolTipTextNeededEventArgs e)
    {
        if (e.ColumnIndex < 0) return;
        var colName = grid.Columns[e.ColumnIndex].Name;

        if (e.RowIndex < 0)
        {
            e.ToolTipText = colName switch
            {
                "No" => "Row number in your Excel file.",
                "Name" => "Business name. Replaces {name} in message templates.",
                "Phone" => "WhatsApp number (0812..., +62 812..., 62812...). If several numbers, only the first is used.",
                "Status" => "Contact progress. Saved back into your Excel file automatically.",
                "Note" => "Manual note (appointment, chat result, etc.). Right-click → Edit note.",
                _ => ""
            };
            return;
        }

        if (grid.Rows[e.RowIndex].DataBoundItem is not Contact c) return;
        e.ToolTipText = colName switch
        {
            "No" => $"Excel row {c.Row}",
            "Name" => c.Name,
            "Phone" => c.Phone,
            "Status" => StatusHelp(c),
            "Note" => string.IsNullOrWhiteSpace(c.Note) ? "No note yet. Right-click → Edit note." : c.Note,
            _ => ""
        };
    }

    private static string StatusHelp(Contact c)
    {
        string text = c.Status switch
        {
            var s when s.StartsWith("Contacted before") => "This number was messaged before (see your history), so it is skipped to avoid duplicates.",
            "Not contacted" => "Not messaged yet. It will be included in the next normal send.",
            "Sending" or "Prepared" => "Being processed right now.",
            "Contacted" => "The intro message was sent.",
            "Replied" => "They replied. You can follow up with them using 'Follow up replied'.",
            "Deal" => "This contact became a customer.",
            "Not interested" => "They declined. Not included in normal sends.",
            "Skipped" => "Excluded by you. Not included in normal sends.",
            "Invalid number" => "The phone number could not be understood.",
            "No number" => "This row has no phone number.",
            "Not on WhatsApp" => "This number has no WhatsApp account.",
            "Check manually" => "The text may have been sent but the photos failed. Check this chat in WhatsApp.",
            _ => c.Status
        };
        if (c.PromoDate.Length > 0) text += $"\r\nLast promo sent: {c.PromoDate}";
        return text;
    }

    // ------------------------------------------------------------------ photos
    private void PickImage()
    {
        using var dlg = new OpenFileDialog
        {
            Title = "Choose product photos (hold Ctrl / Shift to select several)",
            Multiselect = true,
            Filter = "All images (*.jpg;*.jpeg;*.png;*.webp;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.webp;*.bmp;*.gif|" +
                     "JPEG (*.jpg;*.jpeg)|*.jpg;*.jpeg|PNG (*.png)|*.png|WebP (*.webp)|*.webp|All files (*.*)|*.*"
        };
        if (dlg.ShowDialog() != DialogResult.OK) return;

        var list = settings.ImagePaths.Where(File.Exists).ToList();
        foreach (var f in dlg.FileNames)
            if (!list.Contains(f)) list.Add(f);
        SetImages(list);
    }

    private static Bitmap LoadThumb(string path, int size)
    {
        using var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        using var img = Image.FromStream(fs);
        float scale = Math.Min((float)size / img.Width, (float)size / img.Height);
        int w = Math.Max(1, (int)(img.Width * scale));
        int h = Math.Max(1, (int)(img.Height * scale));
        var bmp = new Bitmap(w, h);
        using var g = Graphics.FromImage(bmp);
        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
        g.DrawImage(img, 0, 0, w, h);
        return bmp;
    }

    private void SetImages(List<string> paths)
    {
        settings.ImagePaths = paths;

        thumbs.SuspendLayout();
        while (thumbs.Controls.Count > 0)
        {
            var old = thumbs.Controls[0];
            thumbs.Controls.RemoveAt(0);
            old.Dispose();
        }
        foreach (var im in thumbImages) im.Dispose();
        thumbImages.Clear();

        foreach (var path in paths)
        {
            Bitmap bmp;
            try { bmp = LoadThumb(path, 62); }
            catch { continue; }
            thumbImages.Add(bmp);

            var pb = new PictureBox
            {
                Width = 64, Height = 64, Margin = new Padding(3),
                SizeMode = PictureBoxSizeMode.Zoom, Image = bmp,
                BorderStyle = BorderStyle.FixedSingle, BackColor = Color.White
            };
            var remove = new Button
            {
                Text = "x", Width = 18, Height = 18, Left = pb.Width - 22, Top = 1,
                FlatStyle = FlatStyle.Flat, UseMnemonic = false,
                BackColor = Color.FromArgb(235, 70, 70), ForeColor = Color.White,
                Font = new Font("Segoe UI", 7.5f, FontStyle.Bold), Padding = new Padding(0)
            };
            remove.FlatAppearance.BorderSize = 0;
            var captured = path;
            remove.Click += (_, _) =>
            {
                var rest = settings.ImagePaths.Where(p => p != captured).ToList();
                BeginInvoke(new Action(() => SetImages(rest)));
            };
            pb.Controls.Add(remove);
            tip.SetToolTip(pb, Path.GetFileName(path));
            tip.SetToolTip(remove, "Remove this photo");
            thumbs.Controls.Add(pb);
        }
        thumbs.ResumeLayout();

        lblPhotos.Text = paths.Count == 0
            ? "No photos selected (messages go out as text only)"
            : $"{paths.Count} photo(s) will be attached to each message";
    }

    // ------------------------------------------------------------------ settings -> UI
    private void ApplySettingsToUi()
    {
        txtTemplate.Text = settings.Template;
        txtPromo.Text = settings.PromoTemplate;
        numMin.Value = Math.Clamp(settings.MinDelay, 5, 600);
        numMax.Value = Math.Clamp(settings.MaxDelay, 5, 600);
        chkDesktop.Checked = settings.UseDesktop;
        numAutoMin.Value = Math.Clamp(settings.AutoMin, 5, 600);
        numAutoMax.Value = Math.Clamp(settings.AutoMax, 5, 600);
        numLimit.Value = Math.Clamp(settings.AutoLimit, 1, 500);
        numWait.Value = Math.Clamp(settings.AutoWait, 3, 30);
        numHourStart.Value = Math.Clamp(settings.SafeHourStart, 0, 23);
        numHourEnd.Value = Math.Clamp(settings.SafeHourEnd, 0, 23);
        SetImages(settings.ImagePaths.Where(File.Exists).ToList());
        RefreshTemplateCombo();
    }

    // ------------------------------------------------------------------ multi template
    private void RefreshTemplateCombo()
    {
        cmbTemplate.Items.Clear();
        if (settings.SavedTemplates == null) settings.SavedTemplates = new();
        foreach (var t in settings.SavedTemplates)
            cmbTemplate.Items.Add(t.Name);
        if (cmbTemplate.Items.Count > 0) cmbTemplate.SelectedIndex = 0;
    }

    private void OnTemplatePicked()
    {
        if (cmbTemplate.SelectedIndex < 0) return;
        var name = cmbTemplate.SelectedItem?.ToString() ?? "";
        var t = settings.SavedTemplates.FirstOrDefault(x => x.Name == name);
        if (t == null) return;
        // Template "Promo" → isi tab promo, lainnya → intro
        if (name.Contains("Promo", StringComparison.OrdinalIgnoreCase) ||
            name.Contains("promo", StringComparison.OrdinalIgnoreCase))
        {
            txtPromo.Text = t.Body;
            tabs.SelectedIndex = 1;
        }
        else
        {
            txtTemplate.Text = t.Body;
            tabs.SelectedIndex = 0;
        }
    }

    private void SaveCurrentAsTemplate()
    {
        bool promoTab = tabs.SelectedIndex == 1;
        string body = promoTab ? txtPromo.Text : txtTemplate.Text;
        if (string.IsNullOrWhiteSpace(body))
        {
            MessageBox.Show("Write a message first before saving a template.");
            return;
        }

        string suggested = cmbTemplate.SelectedItem?.ToString() ?? (promoTab ? "New promo" : "New template");
        using var f = new Form
        {
            Text = "Save template",
            Width = 420, Height = 150,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MaximizeBox = false, MinimizeBox = false, Font = Font
        };
        var lbl = new Label { Text = "Template name:", Left = 12, Top = 16, Width = 120 };
        var box = new TextBox { Left = 130, Top = 12, Width = 250, Text = suggested };
        var btnOk = new Button { Text = "Save", Left = 200, Top = 60, Width = 90, DialogResult = DialogResult.OK };
        var btnCancel = new Button { Text = "Cancel", Left = 300, Top = 60, Width = 90, DialogResult = DialogResult.Cancel };
        f.Controls.AddRange(new Control[] { lbl, box, btnOk, btnCancel });
        f.AcceptButton = btnOk;
        f.CancelButton = btnCancel;
        if (f.ShowDialog(this) != DialogResult.OK) return;
        var name = box.Text.Trim();
        if (name.Length == 0)
        {
            MessageBox.Show("Template name cannot be empty.");
            return;
        }
        var existing = settings.SavedTemplates.FirstOrDefault(x => x.Name == name);
        if (existing != null)
            existing.Body = body;
        else
            settings.SavedTemplates.Add(new MessageTemplate { Name = name, Body = body });
        SaveSettings();
        RefreshTemplateCombo();
        cmbTemplate.SelectedItem = name;
        lblInfo.Text = $"Template \"{name}\" saved.";
    }

    private void DeleteSelectedTemplate()
    {
        if (cmbTemplate.SelectedIndex < 0)
        {
            MessageBox.Show("Select a template to delete.");
            return;
        }
        var name = cmbTemplate.SelectedItem?.ToString() ?? "";
        if (settings.SavedTemplates.Count <= 1)
        {
            MessageBox.Show("At least one template must remain.");
            return;
        }
        var ask = MessageBox.Show($"Delete template \"{name}\"?", "Delete template",
            MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        if (ask != DialogResult.Yes) return;
        settings.SavedTemplates.RemoveAll(x => x.Name == name);
        SaveSettings();
        RefreshTemplateCombo();
        lblInfo.Text = $"Template \"{name}\" deleted.";
    }
}
