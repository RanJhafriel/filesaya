namespace RamahSnackSender;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        // Animated splash screen (closes itself when loading finishes)
        using (var splash = new SplashForm())
            splash.ShowDialog();

        Application.Run(new MainForm());
    }
}
