using System.Drawing.Drawing2D;
using System.Reflection;

namespace RamahSnackSender;

/// <summary>Borderless animated splash screen with a moving loading bar.</summary>
public class SplashForm : Form
{
    private const double TotalMs = 3400;
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 16 };
    private readonly DateTime start = DateTime.Now;
    private readonly Bitmap? bg;
    private double elapsed;
    private double progress;

    public SplashForm()
    {
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(420, 630);
        ShowInTaskbar = false;
        TopMost = true;
        DoubleBuffered = true;
        BackColor = Color.FromArgb(247, 250, 254);
        Opacity = 0;

        using (var gp = RoundedRect(new RectangleF(0, 0, Width, Height), 28))
            Region = new Region(gp);

        try
        {
            using var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("splash_bg.png");
            if (s != null)
            {
                using var img = Image.FromStream(s);
                bg = new Bitmap(img);
            }
        }
        catch { /* draw plain background instead */ }

        timer.Tick += (_, _) => Step();
        timer.Start();
    }

    private void Step()
    {
        elapsed = (DateTime.Now - start).TotalMilliseconds;
        double t = Math.Min(1, elapsed / TotalMs);
        progress = t * t * (3 - 2 * t);                    // smooth ease-in-out

        double op = 1;
        if (elapsed < 450) op = elapsed / 450;             // fade in
        else if (elapsed > TotalMs - 350) op = Math.Max(0, (TotalMs - elapsed) / 350);   // fade out
        Opacity = op;

        Invalidate();
        if (elapsed >= TotalMs)
        {
            timer.Stop();
            Close();
        }
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

        if (bg != null) g.DrawImage(bg, 0, 0, ClientSize.Width, ClientSize.Height);
        else g.Clear(BackColor);

        float sx = ClientSize.Width / 1024f;
        float sy = ClientSize.Height / 1536f;

        // loading bar (same place as in the design)
        var track = new RectangleF(334 * sx, 1094 * sy, (690 - 334) * sx, 16 * sy);
        using (var gp = RoundedRect(track, track.Height / 2))
        using (var br = new SolidBrush(Color.FromArgb(214, 229, 250)))
            g.FillPath(br, gp);

        float fillW = Math.Max(track.Height, track.Width * (float)progress);
        var fill = new RectangleF(track.X, track.Y, fillW, track.Height);
        using (var gp = RoundedRect(fill, fill.Height / 2))
        using (var br = new LinearGradientBrush(fill, Color.FromArgb(47, 128, 255), Color.FromArgb(96, 182, 255), LinearGradientMode.Horizontal))
            g.FillPath(br, gp);

        // moving shine on the bar
        float shineX = track.X + (float)((elapsed % 900) / 900.0) * track.Width;
        using (var clip = RoundedRect(fill, fill.Height / 2))
        {
            var old = g.Clip;
            g.SetClip(clip, CombineMode.Replace);
            using var shine = new LinearGradientBrush(
                new RectangleF(shineX - 20, track.Y, 40, track.Height),
                Color.FromArgb(0, 255, 255, 255), Color.FromArgb(120, 255, 255, 255), LinearGradientMode.Horizontal);
            g.FillRectangle(shine, shineX - 20, track.Y, 40, track.Height);
            g.Clip = old;
        }

        // "Loading..." with animated dots
        int dots = (int)(elapsed / 350) % 4;
        using var font = new Font("Segoe UI", 9.5f, FontStyle.Regular);
        var full = "Loading...";
        var size = g.MeasureString(full, font);
        float tx = (ClientSize.Width - size.Width) / 2f;
        float ty = 1136 * sy;
        using var textBrush = new SolidBrush(Color.FromArgb(118, 136, 172));
        g.DrawString("Loading" + new string('.', dots), font, textBrush, tx, ty);
    }

    private static GraphicsPath RoundedRect(RectangleF r, float radius)
    {
        float d = radius * 2;
        var p = new GraphicsPath();
        p.AddArc(r.X, r.Y, d, d, 180, 90);
        p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure();
        return p;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            timer.Dispose();
            bg?.Dispose();
        }
        base.Dispose(disposing);
    }
}
