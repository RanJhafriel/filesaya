using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace BatchPPTInserter
{
    public class SplashForm : Form
    {
        private readonly Timer timer;
        private readonly Image splashImage;
        private float opacity = 0f;
        private float progress = 0f;
        private float pulse = 0f;
        private int phase = 0; // 0=fadein, 1=loading, 2=fadeout
        private int tickCount = 0;

        public SplashForm()
        {
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.CenterScreen;
            ShowInTaskbar = false;
            TopMost = true;
            DoubleBuffered = true;
            BackColor = Color.FromArgb(248, 251, 254);

            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "splash.png");
            if (File.Exists(path))
            {
                splashImage = Image.FromFile(path);
                ClientSize = new Size(400, 600);
            }
            else
            {
                splashImage = null;
                ClientSize = new Size(400, 600);
            }

            Opacity = 0;
            timer = new Timer { Interval = 16 };
            timer.Tick += Timer_Tick;
            timer.Start();

            Click += (s, e) => CloseSplash();
            KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space)
                    CloseSplash();
            };
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            tickCount++;
            pulse += 0.07f;
            if (pulse > Math.PI * 2) pulse -= (float)(Math.PI * 2);

            if (phase == 0)
            {
                opacity += 0.045f;
                if (opacity >= 1f)
                {
                    opacity = 1f;
                    phase = 1;
                }
            }
            else if (phase == 1)
            {
                progress = Math.Min(1f, progress + 0.011f + (1f - progress) * 0.016f);
                if (progress >= 0.97f && tickCount > 100)
                    phase = 2;
            }
            else
            {
                opacity -= 0.065f;
                if (opacity <= 0f)
                {
                    opacity = 0f;
                    CloseSplash();
                    return;
                }
            }

            Opacity = Math.Max(0f, Math.Min(1f, opacity));
            Invalidate();
        }

        private void CloseSplash()
        {
            if (timer != null) timer.Stop();
            DialogResult = DialogResult.OK;
            Close();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;

            int w = ClientSize.Width;
            int h = ClientSize.Height;

            using (var bg = new SolidBrush(Color.FromArgb(248, 251, 254)))
                g.FillRectangle(bg, ClientRectangle);

            if (splashImage != null)
            {
                float scale = 1f + (float)Math.Sin(pulse) * 0.008f;
                int imgW = (int)(w * scale);
                int imgH = (int)(h * scale);
                int ox = (w - imgW) / 2;
                int oy = (h - imgH) / 2;
                g.DrawImage(splashImage, new Rectangle(ox, oy, imgW, imgH));
            }

            // ===== ONLY ONE animated loading bar =====
            // Position matches where the old (baked-in) bar used to sit in splash.png
            int barW = 140;
            int barH = 5;
            int barX = (w - barW) / 2;
            int barY = (int)(h * 0.716f);

            using (var path = RoundedRect(barX, barY, barW, barH, 3))
            using (var track = new SolidBrush(Color.FromArgb(220, 230, 242)))
                g.FillPath(track, path);

            int fillW = (int)(barW * progress);
            if (fillW >= 2)
            {
                using (var path = RoundedRect(barX, barY, fillW, barH, 3))
                using (var fill = new LinearGradientBrush(
                    new Rectangle(barX, barY, fillW, barH),
                    Color.FromArgb(50, 145, 255),
                    Color.FromArgb(25, 110, 235),
                    LinearGradientMode.Horizontal))
                {
                    g.FillPath(fill, path);
                }

                float shimmer = (tickCount * 3.5f) % (barW + 50) - 25;
                int sx = barX + (int)Math.Max(0, shimmer);
                int sw = Math.Min(28, fillW - (int)Math.Max(0, shimmer));
                if (sw > 2)
                {
                    using (var sh = new LinearGradientBrush(
                        new Rectangle(sx, barY, sw, barH),
                        Color.FromArgb(0, 255, 255, 255),
                        Color.FromArgb(160, 255, 255, 255),
                        LinearGradientMode.Horizontal))
                    {
                        g.FillRectangle(sh, sx, barY + 1, sw, barH - 2);
                    }
                }
            }

            string txt = progress < 0.96f ? "Loading..." : "Ready";
            using (var font = new Font("Segoe UI", 8.5f))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center })
            using (var brush = new SolidBrush(Color.FromArgb(150, 160, 175)))
            {
                g.DrawString(txt, font, brush, new RectangleF(0, barY + 12, w, 18), sf);
            }
        }

        private static GraphicsPath RoundedRect(int x, int y, int width, int height, int radius)
        {
            var path = new GraphicsPath();
            if (width < 2 || height < 2) return path;
            int d = Math.Min(radius * 2, Math.Min(width, height));
            path.AddArc(x, y, d, d, 180, 90);
            path.AddArc(x + width - d, y, d, d, 270, 90);
            path.AddArc(x + width - d, y + height - d, d, d, 0, 90);
            path.AddArc(x, y + height - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                timer?.Dispose();
                splashImage?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
