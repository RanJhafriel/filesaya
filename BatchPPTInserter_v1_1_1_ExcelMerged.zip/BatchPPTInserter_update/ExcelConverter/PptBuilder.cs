using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using A = DocumentFormat.OpenXml.Drawing;
using P = DocumentFormat.OpenXml.Presentation;

namespace ExcelToPpt
{
    public class BuildOptions
    {
        public bool[] Sources = { true, true, false, false };   // Info Toko, Promoter Lain, Estimasi Sendiri, Catatan
        public bool HeaderText = true;                         // "LGE Internal Use Only"
        public string SellInToday = "";
        public string SellOutToday = "";
    }

    // ------------------------------------------------------------------
    //  Model tabel sederhana -> A.Table
    // ------------------------------------------------------------------
    internal class TCell
    {
        public string Text = "";
        public double Size = 4;
        public bool Bold, Italic, HMerge, VMerge;
        public string Color = "000000";
        public string Fill;
        public int Align = 1;               // 0 kiri, 1 tengah, 2 kanan
        public int RowSpan = 1, ColSpan = 1;
    }

    internal class TableModel
    {
        public readonly TCell[,] C;
        public readonly double[] ColW, RowH;      // inci
        public readonly int Rows, Cols;
        public readonly double X, Y;

        public TableModel(int rows, int cols, double x, double y, double[] colW, double[] rowH)
        {
            Rows = rows; Cols = cols; X = x; Y = y; ColW = colW; RowH = rowH;
            C = new TCell[rows, cols];
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    C[r, c] = new TCell();
        }

        public void Set(int r, int c, string text, double size, bool bold = false, string color = "000000",
                        string fill = null, int align = 1, bool italic = false)
        {
            var t = C[r, c];
            t.Text = text ?? ""; t.Size = size; t.Bold = bold; t.Color = color;
            t.Fill = fill; t.Align = align; t.Italic = italic;
        }

        public void Merge(int r1, int c1, int r2, int c2)
        {
            C[r1, c1].RowSpan = r2 - r1 + 1;
            C[r1, c1].ColSpan = c2 - c1 + 1;
            for (int r = r1; r <= r2; r++)
                for (int c = c1; c <= c2; c++)
                {
                    if (r == r1 && c == c1) continue;
                    if (c > c1) C[r, c].HMerge = true;
                    if (r > r1) C[r, c].VMerge = true;
                }
        }
    }

    internal class TextPara
    {
        public string Text; public double Size = 7; public bool Bold, Italic; public string Color = "000000"; public int Align = 0;
        public TextPara(string text, double size = 7, bool bold = false, bool italic = false, string color = "000000", int align = 0)
        { Text = text; Size = size; Bold = bold; Italic = italic; Color = color; Align = align; }
    }

    // ------------------------------------------------------------------
    //  Builder
    // ------------------------------------------------------------------
    public static class PptBuilder
    {
        private const string Grey = "D9D9D9";
        private const string Red = "FF0000";

        public static int CountSlides(string path)
        {
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var doc = PresentationDocument.Open(fs, false))
            {
                var l = doc.PresentationPart.Presentation.SlideIdList;
                return l == null ? 0 : l.Elements<P.SlideId>().Count();
            }
        }

        /// startSlide (mulai 1): slide tujuan untuk hasil pertama. Slide yang sudah ada ISINYA DIGANTI,
        /// bila nomor melewati jumlah slide maka slide baru ditambahkan. Hanya berlaku bila PPT dipilih.
        public static void Build(string templatePath, string outPath, List<StoreData> stores,
                                 BuildOptions opt, IProgress<int> progress, int startSlide = 1)
        {
            if (string.IsNullOrWhiteSpace(templatePath))
            {
                using (var rs = OpenBlank())
                using (var fs = File.Create(outPath))
                    rs.CopyTo(fs);
            }
            else
            {
                if (!string.Equals(Path.GetFullPath(templatePath), Path.GetFullPath(outPath), StringComparison.OrdinalIgnoreCase))
                    File.Copy(templatePath, outPath, true);          // sama = edit file itu langsung
            }

            using (var doc = PresentationDocument.Open(outPath, true))
            {
                var pp = doc.PresentationPart;
                var size = pp.Presentation.SlideSize;
                double sx = size.Cx.Value / 12192000.0;
                double sy = size.Cy.Value / 6858000.0;

                for (int i = 0; i < stores.Count; i++)
                {
                    AddSlide(pp, stores[i], opt, sx, sy, string.IsNullOrWhiteSpace(templatePath) ? 0 : startSlide + i);
                    if (progress != null) progress.Report((int)((i + 1) * 100.0 / stores.Count));
                }
                pp.Presentation.Save();
            }
        }

        private static Stream OpenBlank()
        {
            var asm = Assembly.GetExecutingAssembly();
            string name = asm.GetManifestResourceNames().First(n => n.EndsWith("blank.pptx", StringComparison.OrdinalIgnoreCase));
            return asm.GetManifestResourceStream(name);
        }

        // ---------------- slide ----------------
        private static string Attr(OpenXmlElement e, string local)
        {
            foreach (var a in e.GetAttributes())
                if (a.LocalName == local) return a.Value;
            return null;
        }

        private static SlideLayoutPart PickLayout(PresentationPart pp)
        {
            SlideLayoutPart best = null;
            int bestN = int.MaxValue;
            foreach (var m in pp.SlideMasterParts)
                foreach (var l in m.SlideLayoutParts)
                {
                    var cs = l.SlideLayout.CommonSlideData;
                    string nm = cs == null ? "" : (Attr(cs, "name") ?? "");
                    if (nm.Equals("Blank", StringComparison.OrdinalIgnoreCase)) return l;
                    int n = 0;
                    foreach (var ph in l.SlideLayout.Descendants<P.PlaceholderShape>())
                    {
                        string t = Attr(ph, "type");
                        bool footerLike = t == "dt" || t == "ftr" || t == "sldNum";
                        if (!footerLike) n++;
                    }
                    if (n < bestN) { bestN = n; best = l; }
                }
            return best;
        }

        private static void AddSlide(PresentationPart pp, StoreData d, BuildOptions opt, double sx, double sy, int targetIndex)
        {
            SlidePart slidePart;
            P.ShapeTree tree;
            var existing = pp.Presentation.SlideIdList;
            int count = existing == null ? 0 : existing.Elements<P.SlideId>().Count();

            if (targetIndex >= 1 && targetIndex <= count)
            {
                // slide sudah ada -> kosongkan isinya (layout & background tetap), lalu isi hasil konversi
                var sid = existing.Elements<P.SlideId>().ElementAt(targetIndex - 1);
                slidePart = (SlidePart)pp.GetPartById(sid.RelationshipId.Value);
                tree = slidePart.Slide.CommonSlideData.ShapeTree;
                foreach (var el in tree.ChildElements
                         .Where(x => !(x is P.NonVisualGroupShapeProperties) && !(x is P.GroupShapeProperties)).ToList())
                    el.Remove();
            }
            else
            {
                slidePart = pp.AddNewPart<SlidePart>();
                tree = new P.ShapeTree(
                    new P.NonVisualGroupShapeProperties(
                        new P.NonVisualDrawingProperties { Id = 1U, Name = "" },
                        new P.NonVisualGroupShapeDrawingProperties(),
                        new P.ApplicationNonVisualDrawingProperties()),
                    new P.GroupShapeProperties(new A.TransformGroup()));
                slidePart.Slide = new P.Slide(new P.CommonSlideData(tree), new P.ColorMapOverride(new A.MasterColorMapping()));

                var layout = PickLayout(pp);
                if (layout != null) slidePart.AddPart(layout);

                var idList = pp.Presentation.SlideIdList;
                if (idList == null)
                {
                    idList = new P.SlideIdList();
                    OpenXmlElement anchor = (OpenXmlElement)pp.Presentation.HandoutMasterIdList
                                            ?? (OpenXmlElement)pp.Presentation.NotesMasterIdList
                                            ?? (OpenXmlElement)pp.Presentation.SlideMasterIdList;
                    if (anchor != null) pp.Presentation.InsertAfter(idList, anchor);
                    else pp.Presentation.PrependChild(idList);
                }
                uint maxId = 255;
                foreach (var sl in idList.Elements<P.SlideId>()) if (sl.Id.Value > maxId) maxId = sl.Id.Value;
                idList.Append(new P.SlideId { Id = maxId + 1, RelationshipId = pp.GetIdOfPart(slidePart) });
            }

            uint nextId = 2;
            Func<double, long> X = inch => (long)(inch * 914400 * sx);
            Func<double, long> Y = inch => (long)(inch * 914400 * sy);

            // --- header -----------------------------------------------------------
            tree.Append(MakeTextBox(nextId++, X(0.2), Y(0.08), X(4), Y(0.4),
                new[] { new TextPara("1. SALES & SKU", 17, true) }));
            if (opt.HeaderText)
                tree.Append(MakeTextBox(nextId++, X(4.9), Y(0.02), X(3.5), Y(0.3),
                    new[] { new TextPara("LGE Internal Use Only", 8, false, false, "808080", 1) }));
            tree.Append(MakeTextBox(nextId++, X(10.0), Y(0.14), X(3.13), Y(0.3),
                new[] { new TextPara("Store Profile", 11, true, true, "000000", 2) }));
            tree.Append(MakeRule(nextId++, X(0.2), Y(0.5), X(12.93), Y(0.012)));

            double topY = 0.6, topH = 1.4;

            // --- A. Brand / PC ------------------------------------------------------
            var pc = d.Pc.Count > 0 ? d.Pc : new List<PcRow> { new PcRow() };
            int n = pc.Count + 1;
            var tA = new TableModel(n, 2, 0.2, topY, new[] { 0.8, 0.55 }, Enumerable.Repeat(topH / n, n).ToArray());
            tA.Set(0, 0, "Brand", 7, true);
            tA.Set(0, 1, "PC", 7, true);
            for (int i = 0; i < pc.Count; i++)
            {
                tA.Set(i + 1, 0, pc[i].Brand, 7, true);
                tA.Set(i + 1, 1, pc[i].Pc, 9, true);
            }
            tree.Append(MakeTable(tA, nextId++, "Brand PC", sx, sy));

            // --- B. Sell-in / Sell-out 3 bulan --------------------------------------
            var tB = new TableModel(6, 3, 1.75, topY, new[] { 0.69, 0.69, 0.69 }, Enumerable.Repeat(topH / 6, 6).ToArray());
            var blocks = new[] { d.SellIn, d.SellOut3 };
            for (int k = 0; k < 2; k++)
            {
                int b = k * 3;
                tB.Merge(b, 0, b, 2);
                tB.Set(b, 0, blocks[k].Title, 6, true, fill: Grey);
                for (int i = 0; i < 3; i++)
                {
                    tB.Set(b + 1, i, blocks[k].Heads[i], 6, true);
                    tB.Set(b + 2, i, blocks[k].Vals[i], 6.5);
                }
            }
            tree.Append(MakeTable(tB, nextId++, "Sell 3 months", sx, sy));

            // --- C. Sell-in / Sell-out bulan ini -------------------------------------
            var tC = new TableModel(6, 1, 3.85, topY, new[] { 1.2 }, Enumerable.Repeat(topH / 6, 6).ToArray());
            tC.Set(0, 0, "Sell-in (this month)", 6, true, fill: Grey);
            tC.Set(1, 0, "Till Today", 6, true);
            tC.Set(2, 0, TodayText(opt.SellInToday), 7);
            tC.Set(3, 0, "Sell-out (this month)", 6, true, fill: Grey);
            tC.Set(4, 0, "Till Today", 6, true);
            tC.Set(5, 0, TodayText(opt.SellOutToday), 7);
            tree.Append(MakeTable(tC, nextId++, "This month", sx, sy));

            // --- D. Sell-out by brand -------------------------------------------------
            var bb = d.Brand;
            if (bb != null && bb.Names.Count > 0)
            {
                int nb = bb.Names.Count;
                double labW = 0.8, totW = 5.56;
                var cw = new double[nb + 1];
                cw[0] = labW;
                for (int i = 1; i <= nb; i++) cw[i] = (totW - labW) / nb;
                var tD = new TableModel(6, nb + 1, 5.1, topY, cw, Enumerable.Repeat(topH / 6, 6).ToArray());
                tD.Merge(0, 0, 0, nb);
                tD.Set(0, 0, bb.Title, 7, true, fill: Grey);
                tD.Set(1, 0, "Brand", 6.5, true, fill: Grey);
                tD.Set(2, 0, "Rank", 6.5, true);
                tD.Set(3, 0, "Amount", 6.5, true);
                tD.Set(4, 0, "M/S", 6.5, true);
                tD.Set(5, 0, "Store Total", 6.5, true);
                for (int i = 0; i < nb; i++)
                {
                    tD.Set(1, i + 1, bb.Names[i], 6.5, true, fill: Grey);
                    tD.Set(2, i + 1, bb.Ranks[i], 7);
                    tD.Set(3, i + 1, bb.Amounts[i], 7);
                    tD.Set(4, i + 1, bb.Ms[i], 7);
                    if (i == 0) tD.Set(5, 1, bb.Total, 7, true);
                    else if (i < bb.Extra.Count) tD.Set(5, i + 1, bb.Extra[i], 6.5);
                }
                foreach (var m in bb.Merges) tD.Merge(5, m[0] + 1, 5, m[1] + 1);
                tree.Append(MakeTable(tD, nextId++, "Sell-out by brand", sx, sy));
            }

            // --- E. Tabel produk --------------------------------------------------------
            var pr = d.Prod;
            if (pr != null && pr.Rows.Count > 0)
            {
                int nbr = pr.Brands.Count;
                var rows = pr.Rows;
                int cnt = rows.Count;
                double x0 = 0.2, y0 = 2.08, W = 10.46, bottom = 7.35;
                double prodW = 0.45, catW = 1.3, remW = 1.0;
                double bw = (W - prodW - catW - remW) / (2 * nbr);
                var cw = new List<double> { prodW, catW };
                for (int i = 0; i < 2 * nbr; i++) cw.Add(bw);
                cw.Add(remW);
                double h1 = 0.14, h2 = 0.26;
                double rh = Math.Max(0.085, (bottom - y0 - h1 - h2) / Math.Max(cnt, 1));
                double fs = Math.Max(4.0, Math.Min(6.5, Math.Round(rh * 72 * 0.55 * 2, MidpointRounding.AwayFromZero) / 2.0));
                var rhs = new List<double> { h1, h2 };
                for (int i = 0; i < cnt; i++) rhs.Add(rh);
                int last = cw.Count - 1;

                var tE = new TableModel(cnt + 2, cw.Count, x0, y0, cw.ToArray(), rhs.ToArray());
                tE.Merge(0, 0, 1, 0); tE.Set(0, 0, "Prod", 6.5, true, fill: Grey);
                tE.Merge(0, 1, 1, 1); tE.Set(0, 1, "Category", 6.5, true, fill: Grey);
                tE.Merge(0, last, 1, last); tE.Set(0, last, "Remark", 6.5, true, fill: Grey);
                for (int i = 0; i < nbr; i++)
                {
                    int c = 2 + i * 2;
                    tE.Merge(0, c, 0, c + 1);
                    tE.Set(0, c, pr.Brands[i], 5.5, true, fill: Grey);
                    tE.Set(1, c, pr.Subs[i * 2], 5, true, fill: Grey);
                    tE.Set(1, c + 1, pr.Subs[i * 2 + 1], 5, true, fill: Grey);
                }

                int r = 0;
                while (r < cnt)
                {
                    int e = r;
                    while (e + 1 < cnt && rows[e + 1].Gid == rows[r].Gid) e++;
                    if (e > r) tE.Merge(r + 2, 0, e + 2, 0);
                    tE.Set(r + 2, 0, rows[r].Group, fs, true);
                    r = e + 1;
                }
                for (int i = 0; i < cnt; i++)
                {
                    tE.Set(i + 2, 1, rows[i].Cat, fs, false, align: 0);
                    for (int j = 0; j < rows[i].Cells.Count; j++)
                        tE.Set(i + 2, 2 + j, rows[i].Cells[j], fs, false, j % 2 == 1 ? Red : "000000");
                    tE.Set(i + 2, last, rows[i].Remark, fs, false, align: 0);
                }
                tree.Append(MakeTable(tE, nextId++, "Product table", sx, sy));
            }

            // --- Notes & Source Data -----------------------------------------------------
            tree.Append(MakeTextBox(nextId++, X(11.2), Y(1.0), X(2.0), Y(1.2), new[]
            {
                new TextPara("Notes :"),
                new TextPara("- Sell Out (S/O) adalah data bulan lalu (M-1)"),
                new TextPara("- SKU adalah Data Bulan ini")
            }));
            Func<int, string> mark = i => (opt.Sources != null && i < opt.Sources.Length && opt.Sources[i]) ? "( V )" : "(    )";
            tree.Append(MakeTextBox(nextId++, X(11.2), Y(3.15), X(2.0), Y(1.5), new[]
            {
                new TextPara("Source Data", 7, true),
                new TextPara("(boleh pilih lebih dari satu) :"),
                new TextPara(mark(0) + "  Info Toko"),
                new TextPara(mark(1) + "  Promoter Lain"),
                new TextPara(mark(2) + "  Estimasi Sendiri"),
                new TextPara(mark(3) + "  Catatan penjualan/system")
            }));

            slidePart.Slide.Save();
        }

        private static string TodayText(string raw)
        {
            string t = Amount.ToText(raw);
            return t == "" ? "M" : t;
        }

        // ---------------- shapes ----------------
        private static A.Paragraph MakeParagraph(string text, double size, bool bold, bool italic, string color, int align)
        {
            var p = new A.Paragraph(new A.ParagraphProperties
            {
                Alignment = align == 0 ? A.TextAlignmentTypeValues.Left
                          : align == 2 ? A.TextAlignmentTypeValues.Right
                          : A.TextAlignmentTypeValues.Center
            });
            int sz = (int)Math.Round(size * 100);
            if (!string.IsNullOrEmpty(text))
            {
                var rp = new A.RunProperties(
                    new A.SolidFill(new A.RgbColorModelHex { Val = color }),
                    new A.LatinFont { Typeface = "Arial" })
                { Language = "en-US", FontSize = sz, Bold = bold, Italic = italic, Dirty = false };
                p.Append(new A.Run(rp, new A.Text(text)));
            }
            // paragraf/sel kosong tetap diberi ukuran font supaya tinggi baris tidak membengkak
            p.Append(new A.EndParagraphRunProperties { Language = "en-US", FontSize = sz });
            return p;
        }

        private static P.Shape MakeTextBox(uint id, long x, long y, long w, long h, IEnumerable<TextPara> paras)
        {
            var body = new P.TextBody(
                new A.BodyProperties
                {
                    Wrap = A.TextWrappingValues.Square,
                    LeftInset = 0, RightInset = 0, TopInset = 0, BottomInset = 0
                },
                new A.ListStyle());
            foreach (var p in paras) body.Append(MakeParagraph(p.Text, p.Size, p.Bold, p.Italic, p.Color, p.Align));

            return new P.Shape(
                new P.NonVisualShapeProperties(
                    new P.NonVisualDrawingProperties { Id = id, Name = "TextBox " + id },
                    new P.NonVisualShapeDrawingProperties { TextBox = true },
                    new P.ApplicationNonVisualDrawingProperties()),
                new P.ShapeProperties(
                    new A.Transform2D(new A.Offset { X = x, Y = y }, new A.Extents { Cx = w, Cy = h }),
                    new A.PresetGeometry(new A.AdjustValueList()) { Preset = A.ShapeTypeValues.Rectangle },
                    new A.NoFill()),
                body);
        }

        private static P.Shape MakeRule(uint id, long x, long y, long w, long h)
        {
            return new P.Shape(
                new P.NonVisualShapeProperties(
                    new P.NonVisualDrawingProperties { Id = id, Name = "Rule " + id },
                    new P.NonVisualShapeDrawingProperties(),
                    new P.ApplicationNonVisualDrawingProperties()),
                new P.ShapeProperties(
                    new A.Transform2D(new A.Offset { X = x, Y = y }, new A.Extents { Cx = w, Cy = h }),
                    new A.PresetGeometry(new A.AdjustValueList()) { Preset = A.ShapeTypeValues.Rectangle },
                    new A.SolidFill(new A.RgbColorModelHex { Val = "000000" }),
                    new A.Outline(new A.NoFill())));
        }

        private static T Line<T>(T e) where T : OpenXmlCompositeElement
        {
            e.Append(new A.SolidFill(new A.RgbColorModelHex { Val = "000000" }));
            e.Append(new A.PresetDash { Val = A.PresetLineDashValues.Solid });
            return e;
        }

        private static P.GraphicFrame MakeTable(TableModel m, uint id, string name, double sx, double sy)
        {
            Func<double, long> X = inch => (long)(inch * 914400 * sx);
            Func<double, long> Y = inch => (long)(inch * 914400 * sy);

            var tbl = new A.Table();
            tbl.Append(new A.TableProperties(new A.TableStyleId("{2D5ABB26-0587-4C30-8999-92F81FD0307C}"))
            { FirstRow = false, BandRow = false });

            var grid = new A.TableGrid();
            foreach (double w in m.ColW) grid.Append(new A.GridColumn { Width = X(w) });
            tbl.Append(grid);

            for (int r = 0; r < m.Rows; r++)
            {
                var tr = new A.TableRow { Height = Y(m.RowH[r]) };
                for (int c = 0; c < m.Cols; c++)
                {
                    var cell = m.C[r, c];
                    bool hidden = cell.HMerge || cell.VMerge;
                    string[] lines = hidden ? new[] { "" } : (cell.Text ?? "").Split('\n');

                    var body = new A.TextBody(new A.BodyProperties(), new A.ListStyle());
                    foreach (string line in lines)
                        body.Append(MakeParagraph(line, cell.Size, cell.Bold, cell.Italic, cell.Color, cell.Align));

                    var props = new A.TableCellProperties(
                        Line(new A.LeftBorderLineProperties { Width = 6350, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center }),
                        Line(new A.RightBorderLineProperties { Width = 6350, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center }),
                        Line(new A.TopBorderLineProperties { Width = 6350, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center }),
                        Line(new A.BottomBorderLineProperties { Width = 6350, CapType = A.LineCapValues.Flat, CompoundLineType = A.CompoundLineValues.Single, Alignment = A.PenAlignmentValues.Center }))
                    {
                        LeftMargin = 18288, RightMargin = 18288, TopMargin = 0, BottomMargin = 0,
                        Anchor = A.TextAnchoringTypeValues.Center
                    };
                    if (!string.IsNullOrEmpty(cell.Fill))
                        props.Append(new A.SolidFill(new A.RgbColorModelHex { Val = cell.Fill }));
                    else
                        props.Append(new A.NoFill());

                    var tc = new A.TableCell(body, props);
                    if (cell.RowSpan > 1) tc.RowSpan = cell.RowSpan;
                    if (cell.ColSpan > 1) tc.GridSpan = cell.ColSpan;
                    if (cell.HMerge) tc.HorizontalMerge = true;
                    if (cell.VMerge) tc.VerticalMerge = true;
                    tr.Append(tc);
                }
                tbl.Append(tr);
            }

            return new P.GraphicFrame(
                new P.NonVisualGraphicFrameProperties(
                    new P.NonVisualDrawingProperties { Id = id, Name = name },
                    new P.NonVisualGraphicFrameDrawingProperties(new A.GraphicFrameLocks { NoGrouping = true }),
                    new P.ApplicationNonVisualDrawingProperties()),
                new P.Transform(
                    new A.Offset { X = X(m.X), Y = Y(m.Y) },
                    new A.Extents { Cx = X(m.ColW.Sum()), Cy = Y(m.RowH.Sum()) }),
                new A.Graphic(new A.GraphicData(tbl) { Uri = "http://schemas.openxmlformats.org/drawingml/2006/table" }));
        }
    }
}
