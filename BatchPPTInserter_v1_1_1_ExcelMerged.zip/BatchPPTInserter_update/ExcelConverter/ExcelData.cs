using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using ClosedXML.Excel;

namespace ExcelToPpt
{
    // ------------------------------------------------------------------
    //  KONVERSI NOMINAL  (131485000 / "Rp 131.485.000" / "275M" -> "131M")
    // ------------------------------------------------------------------
    public static class Amount
    {
        /// true  : digit dipotong (131.485.000 -> 131M, 1.314.850.000 -> 1.314M)
        /// false : dibulatkan
        public static bool Truncate = true;

        public static double? ToMillion(object v)
        {
            if (v == null) return null;

            if (v is double || v is float || v is int || v is long || v is decimal)
            {
                double d = Convert.ToDouble(v, CultureInfo.InvariantCulture);
                return Math.Abs(d) >= 1e6 ? d / 1e6 : d;      // >= 1 juta = rupiah penuh, selain itu sudah juta
            }

            string s = Convert.ToString(v, CultureInfo.InvariantCulture);
            if (s == null) return null;
            s = s.Trim().ToLowerInvariant();
            if (s.Length == 0 || s == "-") return null;

            s = s.Replace("rupiah", "");
            s = Regex.Replace(s, @"[,.]-+\s*$", "");                 // "Rp 105.454.510,-"
            bool hasM = Regex.IsMatch(s, @"(juta|jt|m)\s*$");
            s = Regex.Replace(s, @"(juta|jt|m)\s*$", "");
            s = Regex.Replace(s, @"(rp|idr)\.?", "");
            s = Regex.Replace(s, @"[\s\u00a0]", "");
            if (s.Length == 0 || !Regex.IsMatch(s, @"^[\d.,]+$")) return null;

            double num;
            Match groupedDec = Regex.Match(s, @"^(\d{1,3}(?:[.,]\d{3})+)[.,]\d{1,2}$");
            if (Regex.IsMatch(s, @"^\d{1,3}(?:[.,]\d{3})+$"))              // 274.717.000  /  2.018
                num = double.Parse(Regex.Replace(s, @"[.,]", ""), CultureInfo.InvariantCulture);
            else if (groupedDec.Success)                                    // 274,717,000.00
                num = double.Parse(Regex.Replace(groupedDec.Groups[1].Value, @"[.,]", ""), CultureInfo.InvariantCulture);
            else if (Regex.IsMatch(s, @"^\d+[.,]\d{1,2}$"))                 // 131,5
                num = double.Parse(s.Replace(',', '.'), CultureInfo.InvariantCulture);
            else if (Regex.IsMatch(s, @"^\d+$"))
                num = double.Parse(s, CultureInfo.InvariantCulture);
            else
                return null;

            if (hasM) return num;
            return num >= 1e6 ? num / 1e6 : num;
        }

        /// Angka juta -> bilangan bulat M (dipotong / dibulatkan sesuai pengaturan).
        public static long? Whole(double? v)
        {
            if (!v.HasValue) return null;
            return Truncate
                ? (long)Math.Floor(v.Value + 1e-9)
                : (long)Math.Round(v.Value, MidpointRounding.AwayFromZero);
        }

        /// Angka juta -> "131M" / "1.314M". Kosong -> "".
        public static string FormatM(double? v)
        {
            long? n = Whole(v);
            if (!n.HasValue) return "";
            return n.Value.ToString("#,##0", CultureInfo.InvariantCulture).Replace(',', '.') + "M";
        }

        public static string ToText(object raw) { return FormatM(ToMillion(raw)); }
    }

    // ------------------------------------------------------------------
    //  MODEL DATA
    // ------------------------------------------------------------------
    public class PcRow { public string Brand = ""; public string Pc = ""; }

    public class PeriodBlock
    {
        public string Title = "";
        public string[] Heads = { "", "", "" };
        public string[] Raw = { "", "", "" };
        public string[] Vals = { "", "", "" };
    }

    public class BrandBlock
    {
        public string Title = "";
        public List<string> Names = new List<string>();
        public List<string> Ranks = new List<string>();
        public List<string> RawAmounts = new List<string>();
        public List<string> Amounts = new List<string>();
        public List<string> Ms = new List<string>();
        public string Total = "";
        public List<string> Extra = new List<string>();
        public List<int[]> Merges = new List<int[]>();     // pasangan {dariIndexBrand, keIndexBrand}
    }

    public class ProdRow
    {
        public int Gid;
        public string Group = "";
        public string Cat = "";
        public List<string> Cells = new List<string>();
        public string Remark = "";
    }

    public class ProdBlock
    {
        public List<string> Brands = new List<string>();
        public List<string> Subs = new List<string>();
        public List<ProdRow> Rows = new List<ProdRow>();
    }

    public class StoreData
    {
        public string SourceFile = "";
        public List<PcRow> Pc = new List<PcRow>();
        public PeriodBlock SellIn = new PeriodBlock();
        public PeriodBlock SellOut3 = new PeriodBlock();
        public BrandBlock Brand;
        public ProdBlock Prod;
        public List<string> Warnings = new List<string>();
    }

    // ------------------------------------------------------------------
    //  PEMBACA EXCEL  (mencari posisi lewat label, bukan alamat sel tetap)
    // ------------------------------------------------------------------
    internal class Grid
    {
        private readonly object[,] data;
        private readonly List<int[]> merged = new List<int[]>();    // r1,c1,r2,c2
        public readonly int MaxR, MaxC;

        public Grid(IXLWorksheet ws)
        {
            var used = ws.RangeUsed();
            MaxR = used == null ? 0 : Math.Min(used.LastRow().RowNumber(), 400);
            MaxC = used == null ? 0 : Math.Min(used.LastColumn().ColumnNumber(), 60);
            data = new object[MaxR + 2, MaxC + 2];
            for (int r = 1; r <= MaxR; r++)
                for (int c = 1; c <= MaxC; c++)
                    data[r, c] = ReadCell(ws.Cell(r, c));
            foreach (var m in ws.MergedRanges)
                merged.Add(new[]
                {
                    m.RangeAddress.FirstAddress.RowNumber, m.RangeAddress.FirstAddress.ColumnNumber,
                    m.RangeAddress.LastAddress.RowNumber,  m.RangeAddress.LastAddress.ColumnNumber
                });
        }

        private static object ReadCell(IXLCell cell)
        {
            switch (cell.DataType)
            {
                case XLDataType.Blank: return null;
                case XLDataType.Number:
                    double d = cell.GetDouble();
                    return LooksLikeDate(cell) ? (object)DateTime.FromOADate(d) : d;
                case XLDataType.DateTime: return cell.GetDateTime();
                case XLDataType.Boolean: return cell.GetBoolean().ToString();
                default: return cell.GetString();
            }
        }

        private static bool LooksLikeDate(IXLCell c)
        {
            var nf = c.Style.NumberFormat;
            int id = nf.NumberFormatId;
            if ((id >= 14 && id <= 22) || (id >= 45 && id <= 47)) return true;
            string f = (nf.Format ?? "").ToLowerInvariant();
            f = Regex.Replace(f, "\"[^\"]*\"|\\[[^\\]]*\\]", "");
            return Regex.IsMatch(f, "[dmy]") && !Regex.IsMatch(f, "[0#]");
        }

        public object V(int r, int c)
        {
            if (r < 1 || c < 1 || r > MaxR || c > MaxC) return null;
            return data[r, c];
        }

        public static string Norm(object v)
        {
            if (v == null) return "";
            string s = Convert.ToString(v, CultureInfo.InvariantCulture) ?? "";
            return Regex.Replace(s, @"\s+", " ").Trim().ToLowerInvariant();
        }

        private static readonly string[] IdMonth = { "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des" };

        public string T(int r, int c) { return Text(V(r, c)); }

        public static string Text(object v)
        {
            if (v == null) return "";
            if (v is DateTime)
            {
                var d = (DateTime)v;
                return IdMonth[d.Month - 1] + "-" + (d.Year % 100).ToString("00");
            }
            if (v is double)
            {
                double d = (double)v;
                if (Math.Abs(d - Math.Round(d)) < 1e-9) return ((long)Math.Round(d)).ToString(CultureInfo.InvariantCulture);
                return d.ToString(CultureInfo.InvariantCulture);
            }
            return Regex.Replace(Convert.ToString(v, CultureInfo.InvariantCulture) ?? "", @"[ \t]+", " ").Trim();
        }

        public IEnumerable<int[]> Find(Func<string, bool> pred, int startRow = 1)
        {
            for (int r = startRow; r <= MaxR; r++)
                for (int c = 1; c <= MaxC; c++)
                    if (pred(Norm(data[r, c]))) yield return new[] { r, c };
        }

        public int[] First(Func<string, bool> pred, int startRow = 1)
        {
            return Find(pred, startRow).FirstOrDefault();
        }

        /// kolom awal & akhir dari merge yang memuat (r,c)
        public int[] Span(int r, int c)
        {
            foreach (var m in merged)
                if (m[0] <= r && r <= m[2] && m[1] <= c && c <= m[3]) return new[] { m[1], m[3] };
            return new[] { c, c };
        }

        public IEnumerable<int[]> MergedOnRow(int r)
        {
            return merged.Where(m => m[0] <= r && r <= m[2]);
        }
    }

    public static class ExcelReader
    {
        public static StoreData Read(string path)
        {
            // FileShare.ReadWrite supaya file yang sedang terbuka di Excel tetap bisa dibaca
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var wb = new XLWorkbook(fs))
            {
                var sd = Parse(wb.Worksheets.First());
                sd.SourceFile = path;
                return sd;
            }
        }

        private static StoreData Parse(IXLWorksheet ws)
        {
            var g = new Grid(ws);
            var d = new StoreData();

            // --- PC per brand -----------------------------------------------------
            foreach (var rc in g.Find(s => s == "pc"))
            {
                int r = rc[0], c = rc[1];
                if (Grid.Norm(g.V(r, c - 1)) != "brand") continue;
                int rr = r + 1;
                while (g.V(rr, c - 1) != null && g.T(rr, c - 1) != "")
                {
                    d.Pc.Add(new PcRow { Brand = g.T(rr, c - 1), Pc = g.T(rr, c) });
                    rr++;
                }
                break;
            }
            if (d.Pc.Count == 0) d.Warnings.Add("Tabel Brand / PC tidak ditemukan.");

            // --- Sell-in / Sell-out 3 bulan ------------------------------------------
            d.SellIn = ReadPeriod(g, "sell-in");
            d.SellOut3 = ReadPeriod(g, "sell-out");

            // --- Sell-out by brand -----------------------------------------------------
            var rk = g.First(s => s == "rank");
            if (rk != null) d.Brand = ReadBrand(g, rk[0], rk[1]);
            else d.Warnings.Add("Blok 'Sell-out by Brand' tidak ditemukan (label 'Rank' tidak ada).");

            // --- Tabel produk -------------------------------------------------------------
            var cat = g.First(s => s == "category");
            if (cat != null) d.Prod = ReadProd(g, cat[0], cat[1]);
            else d.Warnings.Add("Tabel produk tidak ditemukan (label 'Category' tidak ada).");

            return d;
        }

        private static PeriodBlock ReadPeriod(Grid g, string keyword)
        {
            var blk = new PeriodBlock();
            var rc = g.First(s => s.Contains(keyword) && s.Contains("last 3"));
            if (rc == null) return blk;
            int r = rc[0], c = rc[1];
            var span = g.Span(r, c);
            var cols = new List<int>();
            if (span[1] - span[0] < 2) { for (int i = 0; i < 3; i++) cols.Add(span[0] + i); }
            else { for (int cc = span[0]; cc <= span[1] && cols.Count < 3; cc++) cols.Add(cc); }

            blk.Title = g.T(r, c);
            for (int i = 0; i < 3; i++)
            {
                blk.Heads[i] = g.T(r + 1, cols[i]);
                blk.Raw[i] = g.T(r + 2, cols[i]);
                blk.Vals[i] = Amount.ToText(g.V(r + 2, cols[i]));
            }
            return blk;
        }

        private static BrandBlock ReadBrand(Grid g, int r, int c)
        {
            var b = new BrandBlock();
            var cols = new List<int>();
            for (int cc = c + 1; cc <= g.MaxC; cc++)
            {
                string name = g.T(r - 1, cc);
                if (name != "") { b.Names.Add(name); cols.Add(cc); }
            }

            var rows = new Dictionary<string, int>();
            for (int rr = r; rr < r + 8; rr++)
            {
                string lab = Grid.Norm(g.V(rr, c));
                if (lab == "rank" || lab == "amount" || lab == "m/s" || lab == "store total") rows[lab] = rr;
            }

            var t = g.First(s => s.Contains("sell-out by brand"));
            b.Title = t != null ? g.T(t[0], t[1]) : "Sell-out by Brand (Last month, Amount. M(juta) rupiah)";

            var amounts = new List<double?>();
            foreach (int cc in cols)
            {
                object raw = rows.ContainsKey("amount") ? g.V(rows["amount"], cc) : null;
                amounts.Add(Amount.ToMillion(raw));
                b.RawAmounts.Add(Grid.Text(raw));
                b.Ranks.Add(rows.ContainsKey("rank") ? g.T(rows["rank"], cc) : "");
            }

            // Semua hitungan memakai nilai M yang SAMA dengan yang tampil di slide
            // (131.485.000 -> 131), supaya Store Total & M/S cocok dengan hitungan manual.
            var whole = amounts.Select(x => Amount.Whole(x)).ToList();

            if (b.Ranks.All(x => x == ""))                       // rank kosong -> hitung dari amount
            {
                var order = Enumerable.Range(0, whole.Count).Where(i => whole[i].HasValue)
                                      .OrderByDescending(i => whole[i].Value).ToList();
                b.Ranks = Enumerable.Repeat("-", whole.Count).ToList();
                for (int pos = 0; pos < order.Count; pos++) b.Ranks[order[pos]] = (pos + 1).ToString();
            }

            long total = whole.Where(x => x.HasValue).Sum(x => x.Value);
            int[] share = Shares(whole, total);
            for (int i = 0; i < whole.Count; i++)
            {
                b.Amounts.Add(whole[i].HasValue ? Amount.FormatM((double)whole[i].Value) : "-");
                b.Ms.Add(whole[i].HasValue && total > 0 ? share[i] + "%" : "-");
            }
            b.Total = Amount.FormatM((double)total);

            if (rows.ContainsKey("store total"))
            {
                int tr = rows["store total"];
                foreach (int cc in cols) b.Extra.Add(g.T(tr, cc));
                foreach (var m in g.MergedOnRow(tr))
                {
                    var idx = new List<int>();
                    for (int x = m[1]; x <= m[3]; x++) { int i = cols.IndexOf(x); if (i >= 0) idx.Add(i); }
                    if (idx.Count > 1) b.Merges.Add(new[] { idx.Min(), idx.Max() });
                }
            }
            return b;
        }

        /// Persen per brand dibulatkan dengan metode "largest remainder",
        /// sehingga jumlah seluruh M/S selalu tepat 100%.
        private static int[] Shares(List<long?> w, long total)
        {
            var res = new int[w.Count];
            if (total <= 0) return res;
            var rem = new List<KeyValuePair<int, double>>();
            int sum = 0;
            for (int i = 0; i < w.Count; i++)
            {
                if (!w[i].HasValue) continue;
                double exact = w[i].Value * 100.0 / total;
                int fl = (int)Math.Floor(exact + 1e-9);
                res[i] = fl;
                sum += fl;
                rem.Add(new KeyValuePair<int, double>(i, exact - fl));
            }
            int left = 100 - sum;
            foreach (var r in rem.OrderByDescending(x => x.Value).ThenBy(x => x.Key).Take(Math.Max(0, left)))
                res[r.Key]++;
            return res;
        }

        private static ProdBlock ReadProd(Grid g, int hr, int cc)
        {
            var p = new ProdBlock();
            int remarkCol = 0;
            var brandCols = new List<int>();
            for (int c = cc + 1; c <= g.MaxC; c++)
            {
                string t = g.T(hr, c);
                if (t == "") continue;
                if (Grid.Norm(t) == "remark") remarkCol = c;
                else { p.Brands.Add(t); brandCols.Add(c); }
            }

            int start = hr + 1;
            while (start <= g.MaxR && g.T(start, cc) == "") start++;

            foreach (int c in brandCols)
                foreach (int cc2 in new[] { c, c + 1 })
                {
                    var parts = new List<string>();
                    for (int r = hr + 1; r < start; r++) { string s = g.T(r, cc2); if (s != "") parts.Add(s); }
                    p.Subs.Add(string.Join("\n", parts));
                }

            int gid = 0; string group = "";
            for (int r = start; r <= g.MaxR; r++)
            {
                string gname = g.T(r, cc - 1);
                if (gname != "") { group = gname; gid++; }
                string cat = g.T(r, cc);
                if (cat == "") continue;
                var row = new ProdRow { Gid = gid, Group = group, Cat = cat };
                foreach (int c in brandCols) { row.Cells.Add(g.T(r, c)); row.Cells.Add(g.T(r, c + 1)); }
                row.Remark = remarkCol > 0 ? g.T(r, remarkCol) : "";
                p.Rows.Add(row);
            }
            return p;
        }
    }
}
