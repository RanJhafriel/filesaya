using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ExcelToPpt
{
    public class ExcelConverterForm : Form
    {
        // ---- warna tema ----
        private static readonly Color Accent = Color.FromArgb(165, 0, 52);
        private static readonly Color Back = Color.FromArgb(243, 244, 246);

        // ---- kontrol ----
        private ListView lvFiles;
        private TextBox txtTemplate, txtOutput, txtSellIn, txtSellOut;
        private NumericUpDown nudSlide;
        private Label lblSlideInfo;
        private int templateSlides;
        private CheckBox[] chkSource;
        private CheckBox chkHeader, chkOpen;
        private RadioButton rbTruncate, rbRound;
        private DataGridView grid;
        private RichTextBox log;
        private ProgressBar bar;
        private Button btnConvert;
        private Label lblPreviewInfo;

        private readonly Dictionary<string, StoreData> cache = new Dictionary<string, StoreData>(StringComparer.OrdinalIgnoreCase);

        public ExcelConverterForm()
        {
            BuildUi();
        }

        // =====================================================================
        //  UI
        // =====================================================================
        private void BuildUi()
        {
            Text = "Convert Excel to PPT - Store Profile";
            Font = new Font("Segoe UI", 9f);
            ClientSize = new Size(1120, 740);
            MinimumSize = new Size(1000, 660);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Back;
            AllowDrop = true;
            DragEnter += OnDragEnter;
            DragDrop += OnDragDrop;

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = Padding.Empty };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 66));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
            Controls.Add(root);

            // ---------- header ----------
            var header = new Panel { Dock = DockStyle.Fill, BackColor = Accent };
            header.Controls.Add(new Label
            {
                Text = "Excel  \u2192  PowerPoint", ForeColor = Color.White, AutoSize = true,
                Font = new Font("Segoe UI Semibold", 16f), Location = new Point(18, 8)
            });
            header.Controls.Add(new Label
            {
                Text = "Convert store Excel files into the \"1. SALES & SKU - Store Profile\" slide  (amounts auto-converted to M)",
                ForeColor = Color.FromArgb(255, 220, 230), AutoSize = true, Location = new Point(20, 40)
            });
            root.Controls.Add(header, 0, 0);

            // ---------- body ----------
            var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(10) };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 470));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.Controls.Add(body, 0, 1);

            body.Controls.Add(BuildLeft(), 0, 0);
            body.Controls.Add(BuildRight(), 1, 0);

            // ---------- footer ----------
            var footer = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12, 10, 12, 10) };
            btnConvert = new Button
            {
                Text = "CONVERT TO PPT", Dock = DockStyle.Right, Width = 220, FlatStyle = FlatStyle.Flat,
                BackColor = Accent, ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 11f), Cursor = Cursors.Hand
            };
            btnConvert.FlatAppearance.BorderSize = 0;
            btnConvert.Click += BtnConvert_Click;

            chkOpen = new CheckBox { Text = "Open result when done", Checked = true, Dock = DockStyle.Right, Width = 170, TextAlign = ContentAlignment.MiddleLeft };
            bar = new ProgressBar { Dock = DockStyle.Fill, Style = ProgressBarStyle.Continuous };

            footer.Controls.Add(bar);
            footer.Controls.Add(chkOpen);
            footer.Controls.Add(new Panel { Dock = DockStyle.Right, Width = 12 });
            footer.Controls.Add(btnConvert);
            // urutan add: kontrol Fill (bar) paling awal, lalu Right dari dalam ke luar
            bar.BringToFront();
            root.Controls.Add(footer, 0, 2);
        }

        private Control BuildLeft()
        {
            var left = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4 };
            left.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            left.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            // --- 1. files ---
            var gFiles = new GroupBox { Text = "1.  Excel files  (drag & drop here)", Dock = DockStyle.Fill, Padding = new Padding(8) };
            lvFiles = new ListView
            {
                Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, HideSelection = false,
                MultiSelect = true, GridLines = true, BorderStyle = BorderStyle.FixedSingle
            };
            lvFiles.Columns.Add("File", 240);
            lvFiles.Columns.Add("Status", 170);
            lvFiles.SelectedIndexChanged += (s, e) => ShowPreview();
            lvFiles.KeyDown += (s, e) => { if (e.KeyCode == Keys.Delete) RemoveSelected(); };

            var btnBar = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 36, FlowDirection = FlowDirection.LeftToRight };
            btnBar.Controls.Add(MakeButton("Add Excel...", (s, e) => AddFilesDialog()));
            btnBar.Controls.Add(MakeButton("Remove", (s, e) => RemoveSelected()));
            btnBar.Controls.Add(MakeButton("Clear", (s, e) => { lvFiles.Items.Clear(); cache.Clear(); ClearPreview(); }));

            gFiles.Controls.Add(lvFiles);
            gFiles.Controls.Add(btnBar);
            btnBar.BringToFront();
            lvFiles.BringToFront();
            left.Controls.Add(gFiles, 0, 0);

            // --- 2. PowerPoint (opsional) ---
            var gPpt = new GroupBox { Text = "2.  PowerPoint  (optional)", Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(8) };
            var tPpt = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 3, RowCount = 4 };
            tPpt.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            tPpt.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            tPpt.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            txtTemplate = new TextBox { Dock = DockStyle.Fill, ReadOnly = true, BackColor = Color.White };
            tPpt.Controls.Add(new Label { Text = "Existing PPT", AutoSize = true, Margin = new Padding(0, 8, 0, 0) }, 0, 0);
            tPpt.Controls.Add(txtTemplate, 1, 0);
            var fBtn = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Margin = Padding.Empty };
            fBtn.Controls.Add(MakeButton("Browse...", (s, e) =>
            {
                using (var d = new OpenFileDialog { Filter = "PowerPoint (*.pptx)|*.pptx" })
                    if (d.ShowDialog() == DialogResult.OK) SetTemplate(d.FileName);
            }));
            fBtn.Controls.Add(MakeButton("Clear", (s, e) => SetTemplate("")));
            tPpt.Controls.Add(fBtn, 2, 0);

            var lblHelp = new Label
            {
                Text = "Leave empty to create a new PPT (1 slide per Excel). Or pick an existing PPT and choose which slide receives the result. Several Excel files fill the next slides in order.",
                AutoSize = true, MaximumSize = new Size(420, 0), ForeColor = Color.DimGray, Margin = new Padding(0, 4, 0, 6)
            };
            tPpt.Controls.Add(lblHelp, 0, 1);
            tPpt.SetColumnSpan(lblHelp, 3);

            nudSlide = new NumericUpDown { Minimum = 1, Maximum = 1, Value = 1, Width = 60, Enabled = false };
            nudSlide.ValueChanged += (s, e) => UpdateSlideInfo();
            lblSlideInfo = new Label { AutoSize = true, Margin = new Padding(8, 5, 0, 0) };
            var fSlide = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Margin = Padding.Empty };
            fSlide.Controls.Add(nudSlide);
            fSlide.Controls.Add(lblSlideInfo);
            tPpt.Controls.Add(new Label { Text = "Put on slide #", AutoSize = true, Margin = new Padding(0, 8, 0, 0) }, 0, 2);
            tPpt.Controls.Add(fSlide, 1, 2);
            tPpt.SetColumnSpan(fSlide, 2);

            txtOutput = new TextBox { Dock = DockStyle.Fill };
            tPpt.Controls.Add(new Label { Text = "Save as", AutoSize = true, Margin = new Padding(0, 8, 0, 0) }, 0, 3);
            tPpt.Controls.Add(txtOutput, 1, 3);
            tPpt.Controls.Add(MakeButton("Browse...", (s, e) =>
            {
                using (var d = new SaveFileDialog { Filter = "PowerPoint (*.pptx)|*.pptx", FileName = "Store_Profile.pptx" })
                    if (d.ShowDialog() == DialogResult.OK) txtOutput.Text = d.FileName;
            }), 2, 3);
            gPpt.Controls.Add(tPpt);
            left.Controls.Add(gPpt, 0, 1);
            UpdateSlideInfo();

            // --- 3. amount options ---
            var gAmt = new GroupBox { Text = "3.  Amount conversion", Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(8) };
            var fAmt = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
            rbTruncate = new RadioButton { Text = "Cut digits   (131.485.000 \u2192 131M,  1.314.850.000 \u2192 1.314M)", Checked = true, AutoSize = true };
            rbRound = new RadioButton { Text = "Round to nearest M", AutoSize = true };
            rbTruncate.CheckedChanged += (s, e) => { Amount.Truncate = rbTruncate.Checked; cache.Clear(); ShowPreview(); };
            fAmt.Controls.Add(rbTruncate);
            fAmt.Controls.Add(rbRound);
            gAmt.Controls.Add(fAmt);
            left.Controls.Add(gAmt, 0, 2);

            // --- 4. slide options ---
            var gOpt = new GroupBox { Text = "4.  Slide options", Dock = DockStyle.Fill, AutoSize = true, Padding = new Padding(8) };
            var tOpt = new TableLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, ColumnCount = 4, RowCount = 5 };
            tOpt.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tOpt.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            tOpt.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            tOpt.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            txtSellIn = new TextBox { Dock = DockStyle.Fill };
            txtSellOut = new TextBox { Dock = DockStyle.Fill };
            tOpt.Controls.Add(new Label { Text = "Sell-in till today", AutoSize = true, Margin = new Padding(0, 6, 6, 0) }, 0, 0);
            tOpt.Controls.Add(txtSellIn, 1, 0);
            tOpt.Controls.Add(new Label { Text = "Sell-out till today", AutoSize = true, Margin = new Padding(8, 6, 6, 0) }, 2, 0);
            tOpt.Controls.Add(txtSellOut, 3, 0);

            var src = new Label { Text = "Source Data:", AutoSize = true, Margin = new Padding(0, 10, 0, 0) };
            tOpt.Controls.Add(src, 0, 1);
            tOpt.SetColumnSpan(src, 4);
            string[] names = { "Info Toko", "Promoter Lain", "Estimasi Sendiri", "Catatan penjualan/system" };
            bool[] def = { true, true, false, false };
            chkSource = new CheckBox[4];
            for (int i = 0; i < 4; i++)
            {
                chkSource[i] = new CheckBox { Text = names[i], Checked = def[i], AutoSize = true };
                tOpt.Controls.Add(chkSource[i], (i % 2) * 2, 2 + i / 2);
                tOpt.SetColumnSpan(chkSource[i], 2);
            }
            chkHeader = new CheckBox { Text = "Write \"LGE Internal Use Only\" in slide header", Checked = true, AutoSize = true, Margin = new Padding(3, 8, 3, 0) };
            tOpt.Controls.Add(chkHeader, 0, 4);
            tOpt.SetColumnSpan(chkHeader, 4);
            gOpt.Controls.Add(tOpt);
            left.Controls.Add(gOpt, 0, 3);

            return left;
        }

        private Control BuildRight()
        {
            var tabs = new TabControl { Dock = DockStyle.Fill, Margin = new Padding(8, 0, 0, 0) };

            var tabPrev = new TabPage("Conversion preview");
            grid = new DataGridView
            {
                Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                RowHeadersVisible = false, BackgroundColor = Color.White, BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                EnableHeadersVisualStyles = false, ColumnHeadersHeight = 28
            };
            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(217, 217, 217);
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 9f);
            grid.Columns.Add("Section", "Section");
            grid.Columns.Add("Item", "Item");
            grid.Columns.Add("Input", "Input in Excel");
            grid.Columns.Add("Result", "Result");
            grid.Columns.Add("MS", "M/S");
            grid.Columns["Result"].DefaultCellStyle.Font = new Font("Segoe UI Semibold", 9f);
            grid.Columns["Result"].DefaultCellStyle.ForeColor = Accent;

            lblPreviewInfo = new Label
            {
                Dock = DockStyle.Top, Height = 28, TextAlign = ContentAlignment.MiddleLeft,
                Text = "Select a file on the left to see how its amounts will be converted.", ForeColor = Color.DimGray
            };
            tabPrev.Controls.Add(grid);
            tabPrev.Controls.Add(lblPreviewInfo);
            lblPreviewInfo.BringToFront();
            grid.BringToFront();
            tabs.TabPages.Add(tabPrev);

            var tabLog = new TabPage("Log");
            log = new RichTextBox { Dock = DockStyle.Fill, ReadOnly = true, BackColor = Color.White, BorderStyle = BorderStyle.None, Font = new Font("Consolas", 9f) };
            tabLog.Controls.Add(log);
            tabs.TabPages.Add(tabLog);
            return tabs;
        }

        private static Button MakeButton(string text, EventHandler click)
        {
            var b = new Button { Text = text, AutoSize = true, Padding = new Padding(6, 1, 6, 1), FlatStyle = FlatStyle.System };
            b.Click += click;
            return b;
        }

        private void SetTemplate(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                txtTemplate.Text = "";
                templateSlides = 0;
                nudSlide.Minimum = 1; nudSlide.Maximum = 1; nudSlide.Value = 1; nudSlide.Enabled = false;
                UpdateSlideInfo();
                return;
            }
            try { templateSlides = PptBuilder.CountSlides(path); }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Cannot open this PowerPoint:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            txtTemplate.Text = path;
            nudSlide.Enabled = true;
            nudSlide.Minimum = 1;
            nudSlide.Maximum = templateSlides + 1;
            nudSlide.Value = 1;
            txtOutput.Text = Path.Combine(Path.GetDirectoryName(path), Path.GetFileNameWithoutExtension(path) + "_Store_Profile.pptx");
            UpdateSlideInfo();
        }

        private void UpdateSlideInfo()
        {
            if (lblSlideInfo == null) return;
            if (txtTemplate.Text == "") { lblSlideInfo.Text = "(new PPT will be created)"; return; }
            int n = (int)nudSlide.Value;
            lblSlideInfo.Text = n <= templateSlides
                ? "of " + templateSlides + " slides  -  slide " + n + " will be REPLACED"
                : "of " + templateSlides + " slides  -  added as new slide " + n;
        }

        // =====================================================================
        //  FILES
        // =====================================================================
        private void OnDragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void OnDragDrop(object sender, DragEventArgs e)
        {
            var files = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (files != null) AddFiles(files);
        }

        private void AddFilesDialog()
        {
            using (var d = new OpenFileDialog { Filter = "Excel (*.xlsx;*.xlsm)|*.xlsx;*.xlsm", Multiselect = true })
                if (d.ShowDialog() == DialogResult.OK) AddFiles(d.FileNames);
        }

        private void AddFiles(IEnumerable<string> files)
        {
            foreach (string f in files)
            {
                string ext = Path.GetExtension(f).ToLowerInvariant();
                if (ext != ".xlsx" && ext != ".xlsm") { Log("Skipped (not Excel): " + f); continue; }
                if (lvFiles.Items.Cast<ListViewItem>().Any(i => string.Equals((string)i.Tag, f, StringComparison.OrdinalIgnoreCase))) continue;
                var it = new ListViewItem(Path.GetFileName(f)) { Tag = f };
                it.SubItems.Add("Ready");
                lvFiles.Items.Add(it);
            }
            if (string.IsNullOrWhiteSpace(txtOutput.Text) && lvFiles.Items.Count > 0)
                txtOutput.Text = Path.Combine(Path.GetDirectoryName((string)lvFiles.Items[0].Tag), "Store_Profile.pptx");
            if (lvFiles.Items.Count > 0 && lvFiles.SelectedItems.Count == 0) lvFiles.Items[lvFiles.Items.Count - 1].Selected = true;
        }

        private void RemoveSelected()
        {
            foreach (ListViewItem it in lvFiles.SelectedItems.Cast<ListViewItem>().ToList()) lvFiles.Items.Remove(it);
            ClearPreview();
        }

        // =====================================================================
        //  PREVIEW
        // =====================================================================
        private StoreData LoadStore(string path)
        {
            StoreData sd;
            if (!cache.TryGetValue(path, out sd))
            {
                sd = ExcelReader.Read(path);
                cache[path] = sd;
            }
            return sd;
        }

        private void ClearPreview()
        {
            grid.Rows.Clear();
            lblPreviewInfo.Text = "Select a file on the left to see how its amounts will be converted.";
        }

        private void ShowPreview()
        {
            if (lvFiles.SelectedItems.Count == 0) { ClearPreview(); return; }
            var it = lvFiles.SelectedItems[0];
            try
            {
                var d = LoadStore((string)it.Tag);
                grid.Rows.Clear();

                if (d.Brand != null)
                {
                    for (int i = 0; i < d.Brand.Names.Count; i++)
                        grid.Rows.Add("Sell-out by brand", d.Brand.Names[i] + "  (rank " + d.Brand.Ranks[i] + ")",
                                      d.Brand.RawAmounts[i], d.Brand.Amounts[i], d.Brand.Ms[i]);
                    int totalRow = grid.Rows.Add("Sell-out by brand", "STORE TOTAL (all brands)", "", d.Brand.Total, "100%");
                    grid.Rows[totalRow].DefaultCellStyle.BackColor = Color.FromArgb(255, 240, 245);
                }
                AddPeriodRows("LG Sell-in 3 months", d.SellIn);
                AddPeriodRows("LG Sell-out 3 months", d.SellOut3);

                if (d.Prod != null)
                    grid.Rows.Add("Product table", d.Prod.Rows.Count + " category rows", "", d.Prod.Brands.Count + " brands: " + string.Join(", ", d.Prod.Brands), "");

                lblPreviewInfo.Text = d.Warnings.Count == 0
                    ? Path.GetFileName((string)it.Tag) + "  -  parsed OK"
                    : "Warning: " + string.Join(" ", d.Warnings);
            }
            catch (Exception ex)
            {
                grid.Rows.Clear();
                lblPreviewInfo.Text = "Cannot read file: " + ex.Message;
            }
        }

        private void AddPeriodRows(string section, PeriodBlock p)
        {
            for (int i = 0; i < 3; i++)
                if (p.Heads[i] != "" || p.Raw[i] != "")
                    grid.Rows.Add(section, p.Heads[i], p.Raw[i], p.Vals[i], "");
        }

        // =====================================================================
        //  CONVERT
        // =====================================================================
        private void Log(string msg)
        {
            log.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + msg + Environment.NewLine);
        }

        private async void BtnConvert_Click(object sender, EventArgs e)
        {
            if (lvFiles.Items.Count == 0)
            {
                MessageBox.Show(this, "Add at least one Excel file first.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string outPath = txtOutput.Text.Trim();
            if (outPath == "") outPath = Path.Combine(Path.GetDirectoryName((string)lvFiles.Items[0].Tag), "Store_Profile.pptx");
            string tpl = txtTemplate.Text.Trim();
            if (tpl != "" && !File.Exists(tpl))
            {
                MessageBox.Show(this, "Template file not found:\n" + tpl, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int startSlide = tpl == "" ? 1 : (int)nudSlide.Value;
            if (tpl != "")
            {
                int replaced = Math.Max(0, Math.Min(lvFiles.Items.Count, templateSlides - startSlide + 1));
                if (replaced > 0 && MessageBox.Show(this,
                        replaced + " existing slide(s) starting at slide " + startSlide + " will have their content REPLACED in:\n" + outPath + "\n\nContinue?",
                        Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;
            }

            Amount.Truncate = rbTruncate.Checked;
            cache.Clear();
            btnConvert.Enabled = false;
            bar.Value = 0;

            var stores = new List<StoreData>();
            foreach (ListViewItem it in lvFiles.Items)
            {
                try
                {
                    var sd = LoadStore((string)it.Tag);
                    stores.Add(sd);
                    it.SubItems[1].Text = sd.Warnings.Count == 0 ? "Parsed" : "Parsed (warnings)";
                    foreach (string w in sd.Warnings) Log(it.Text + ": " + w);
                }
                catch (Exception ex)
                {
                    it.SubItems[1].Text = "Error";
                    Log("ERROR reading " + it.Text + ": " + ex.Message);
                }
            }

            if (stores.Count == 0)
            {
                btnConvert.Enabled = true;
                MessageBox.Show(this, "None of the files could be read. See the Log tab.", Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var opt = new BuildOptions
            {
                Sources = chkSource.Select(c => c.Checked).ToArray(),
                HeaderText = chkHeader.Checked,
                SellInToday = txtSellIn.Text.Trim(),
                SellOutToday = txtSellOut.Text.Trim()
            };
            var progress = new Progress<int>(v => bar.Value = Math.Max(0, Math.Min(100, v)));

            try
            {
                await System.Threading.Tasks.Task.Run(() => PptBuilder.Build(tpl, outPath, stores, opt, progress, startSlide));
                bar.Value = 100;
                foreach (ListViewItem it in lvFiles.Items) if (it.SubItems[1].Text.StartsWith("Parsed")) it.SubItems[1].Text = "Done";
                Log("Saved " + stores.Count + " slide(s) -> " + outPath);
                if (chkOpen.Checked)
                    Process.Start(new ProcessStartInfo(outPath) { UseShellExecute = true });
                else
                    MessageBox.Show(this, "Saved:\n" + outPath, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (IOException ex)
            {
                Log("ERROR: " + ex.Message);
                MessageBox.Show(this, "Cannot write the output file. Is it open in PowerPoint?\n\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                Log("ERROR: " + ex);
                MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnConvert.Enabled = true;
            }
        }
    }
}
