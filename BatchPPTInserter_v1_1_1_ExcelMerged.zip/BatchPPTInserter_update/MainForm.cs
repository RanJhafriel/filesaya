using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using DocumentFormat.OpenXml.Packaging;
// Aliases avoid name clashes with System.Windows.Forms
using D = DocumentFormat.OpenXml.Drawing;
using P = DocumentFormat.OpenXml.Presentation;

namespace BatchPPTInserter
{
    // =====================================================================
    //  DATA: one item (text / image) placed on a given slide.
    //  Position is stored as FRACTIONS of the slide size (0..1), so it still
    //  fits when slide sizes differ between PPT files.
    // =====================================================================
    public class ContentItem
    {
        public int Slide = 1;
        public bool IsImage;
        public string Text = "New text";
        public string ImagePath = "";
        public double FX = 0.1, FY = 0.1, FW = 0.5, FH = 0.15;
        public int FontSize = 24;
        public string FontName = null;          // null = follow PPT theme
        public bool Bold;
        public int ColorArgb = Color.Black.ToArgb();
        public int Align;                       // 0 left, 1 center, 2 right
        public Bitmap Preview;                  // canvas display only
        public double ImgRatio = 1.0;           // image height / width

        public override string ToString()
        {
            string s = IsImage
                ? "Image: " + Path.GetFileName(ImagePath)
                : "Text: " + (Text ?? "").Replace("\r", " ").Replace("\n", " ");
            if (s.Length > 45) s = s.Substring(0, 45) + "...";
            return "Slide " + Slide + " | " + s;
        }
    }

    // =====================================================================
    //  One PowerPoint file in the list
    // =====================================================================
    public class PptFile
    {
        public string FilePath;
        public double WPt, HPt;
        public long Cx;
        public int Count;
        public Bitmap[] Images;      // slide previews (null until loaded)
        public bool Loading;
        public bool Checked = true;  // apply content to this file?
    }

    // =====================================================================
    //  SLIDE CANVAS: looks like the real slide; items can be dragged/resized
    // =====================================================================
    public class SlideCanvas : Control
    {
        public Bitmap SlideImage;
        public double SlideWPt = 960, SlideHPt = 540;
        public double FontBaseWPt = 0;   // slide width (pt) that font sizes refer to
        public List<ContentItem> Items = new List<ContentItem>();
        public string EmptyMessage = "";

        private ContentItem selected;
        public ContentItem Selected
        {
            get { return selected; }
            set { selected = value; Invalidate(); }
        }

        public event Action SelectionChanged;
        public event Action ItemEdited;
        public event Action EditFinished;
        public event Action DeleteRequested;
        public event Action ItemDoubleClicked;

        private enum Mode { None, Move, Resize }
        private Mode mode = Mode.None;
        private int handle = -1;
        private PointF grab;
        private RectangleF origRect;

        public SlideCanvas()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable, true);
            TabStop = true;
            BackColor = Color.FromArgb(64, 64, 64);
        }

        public RectangleF SlideRect()
        {
            const float m = 24f;
            float aw = Width - 2 * m, ah = Height - 2 * m;
            if (aw < 20 || ah < 20) return RectangleF.Empty;
            double aspect = SlideWPt / SlideHPt;
            float w = aw, h = (float)(aw / aspect);
            if (h > ah) { h = ah; w = (float)(ah * aspect); }
            return new RectangleF((Width - w) / 2f, (Height - h) / 2f, w, h);
        }

        // Images always keep their own aspect ratio
        private static RectangleF ItemRect(ContentItem it, RectangleF s)
        {
            float w = (float)it.FW * s.Width;
            float h = it.IsImage ? w * (float)it.ImgRatio : (float)it.FH * s.Height;
            return new RectangleF(s.X + (float)it.FX * s.Width, s.Y + (float)it.FY * s.Height, w, h);
        }

        private static PointF[] HandlePoints(RectangleF r)
        {
            float cx = r.Left + r.Width / 2f, cy = r.Top + r.Height / 2f;
            return new[]
            {
                new PointF(r.Left, r.Top), new PointF(cx, r.Top), new PointF(r.Right, r.Top),
                new PointF(r.Right, cy), new PointF(r.Right, r.Bottom), new PointF(cx, r.Bottom),
                new PointF(r.Left, r.Bottom), new PointF(r.Left, cy)
            };
        }

        private static int HitHandle(RectangleF r, Point p)
        {
            var pts = HandlePoints(r);
            for (int i = 0; i < pts.Length; i++)
                if (Math.Abs(p.X - pts[i].X) <= 6 && Math.Abs(p.Y - pts[i].Y) <= 6) return i;
            return -1;
        }

        private static Cursor CursorForHandle(int h)
        {
            switch (h)
            {
                case 0: case 4: return Cursors.SizeNWSE;
                case 2: case 6: return Cursors.SizeNESW;
                case 1: case 5: return Cursors.SizeNS;
                default: return Cursors.SizeWE;
            }
        }

        private static Font MakeFont(string name, float px, FontStyle st)
        {
            string n = string.IsNullOrEmpty(name) ? "Calibri" : name;
            try { return new Font(n, px, st, GraphicsUnit.Pixel); }
            catch { return new Font("Segoe UI", px, FontStyle.Regular, GraphicsUnit.Pixel); }
        }

        // Shared by the main canvas and the small thumbnails in the file list
        public static void DrawItems(Graphics g, RectangleF s, double slideWPt, double fontBaseWPt, IEnumerable<ContentItem> items)
        {
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            float insetScale = s.Width / (float)slideWPt;                                   // px per pt (this slide)
            float fontScale = s.Width / (float)(fontBaseWPt > 0 ? fontBaseWPt : slideWPt);  // px per font-pt

            foreach (var it in items)
            {
                var r = ItemRect(it, s);
                if (it.IsImage)
                {
                    if (it.Preview != null) g.DrawImage(it.Preview, r);
                    else g.FillRectangle(Brushes.LightGray, r);
                    continue;
                }

                float px = it.FontSize * fontScale;
                if (px >= 1f && !string.IsNullOrEmpty(it.Text))
                {
                    FontStyle st = it.Bold ? FontStyle.Bold : FontStyle.Regular;
                    using (var font = MakeFont(it.FontName, px, st))
                    using (var br = new SolidBrush(Color.FromArgb(it.ColorArgb)))
                    using (var sf = new StringFormat(StringFormat.GenericTypographic))
                    {
                        sf.Alignment = it.Align == 1 ? StringAlignment.Center :
                                       it.Align == 2 ? StringAlignment.Far : StringAlignment.Near;
                        sf.Trimming = StringTrimming.None;
                        sf.FormatFlags = StringFormatFlags.NoClip;
                        float padX = 7.2f * insetScale, padY = 3.6f * insetScale;   // PowerPoint default insets
                        var tr = new RectangleF(r.X + padX, r.Y + padY,
                                                Math.Max(1f, r.Width - 2 * padX), Math.Max(1f, r.Height - 2 * padY));
                        g.DrawString(it.Text, font, br, tr, sf);
                    }
                }
                using (var pen = new Pen(Color.FromArgb(130, 130, 130), 1f) { DashStyle = DashStyle.Dash })
                    g.DrawRectangle(pen, r.X, r.Y, r.Width, r.Height);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.Clear(BackColor);
            var s = SlideRect();
            if (s.IsEmpty) return;

            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

            g.FillRectangle(Brushes.White, s);
            if (SlideImage != null)
                g.DrawImage(SlideImage, s);
            else if (!string.IsNullOrEmpty(EmptyMessage))
                using (var f = new Font("Segoe UI", 10f))
                    g.DrawString(EmptyMessage, f, Brushes.Gray, new RectangleF(s.X + 10, s.Y + 10, s.Width - 20, 60));
            g.DrawRectangle(Pens.Black, s.X, s.Y, s.Width, s.Height);

            DrawItems(g, s, SlideWPt, FontBaseWPt, Items);

            if (selected != null && Items.Contains(selected))
            {
                var r = ItemRect(selected, s);
                using (var pen = new Pen(Color.DodgerBlue, 2f))
                    g.DrawRectangle(pen, r.X, r.Y, r.Width, r.Height);
                foreach (var p in HandlePoints(r))
                {
                    var hr = new RectangleF(p.X - 4, p.Y - 4, 8, 8);
                    g.FillRectangle(Brushes.White, hr);
                    g.DrawRectangle(Pens.DodgerBlue, hr.X, hr.Y, hr.Width, hr.Height);
                }
            }
        }

        // ---------------- Mouse ----------------
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Focus();
            if (e.Button != MouseButtons.Left) return;
            var s = SlideRect();
            if (s.IsEmpty) return;

            if (selected != null && Items.Contains(selected))
            {
                var r = ItemRect(selected, s);
                int h = HitHandle(r, e.Location);
                if (h >= 0) { mode = Mode.Resize; handle = h; origRect = r; return; }
            }

            for (int i = Items.Count - 1; i >= 0; i--)
            {
                var r = ItemRect(Items[i], s);
                if (r.Contains(e.Location))
                {
                    if (selected != Items[i]) { selected = Items[i]; if (SelectionChanged != null) SelectionChanged(); }
                    mode = Mode.Move;
                    grab = new PointF(e.X - r.X, e.Y - r.Y);
                    Invalidate();
                    return;
                }
            }

            if (selected != null)
            {
                selected = null;
                if (SelectionChanged != null) SelectionChanged();
                Invalidate();
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            var s = SlideRect();
            if (s.IsEmpty) return;

            if (mode == Mode.Move && selected != null)
            {
                selected.FX = (e.X - grab.X - s.X) / s.Width;
                selected.FY = (e.Y - grab.Y - s.Y) / s.Height;
                if (ItemEdited != null) ItemEdited();
                Invalidate();
                return;
            }

            if (mode == Mode.Resize && selected != null)
            {
                float l = origRect.Left, t = origRect.Top, r = origRect.Right, b = origRect.Bottom;
                float mx = e.X, my = e.Y;
                switch (handle)
                {
                    case 0: l = mx; t = my; break;
                    case 1: t = my; break;
                    case 2: r = mx; t = my; break;
                    case 3: r = mx; break;
                    case 4: r = mx; b = my; break;
                    case 5: b = my; break;
                    case 6: l = mx; b = my; break;
                    case 7: l = mx; break;
                }

                if (selected.IsImage)
                {
                    float ratio = origRect.Height / origRect.Width;
                    if (handle == 1 || handle == 5)
                    {
                        float nh = Math.Max(10f, b - t);
                        r = l + nh / ratio;
                    }
                    else
                    {
                        float nw = Math.Max(10f, r - l);
                        if (handle == 0 || handle == 6 || handle == 7) l = r - nw; else r = l + nw;
                        float nh = nw * ratio;
                        if (handle == 0 || handle == 2) t = b - nh; else b = t + nh;
                    }
                }
                else
                {
                    if (r - l < 10f) { if (handle == 0 || handle == 6 || handle == 7) l = r - 10f; else r = l + 10f; }
                    if (b - t < 10f) { if (handle == 0 || handle == 1 || handle == 2) t = b - 10f; else b = t + 10f; }
                }

                selected.FX = (l - s.X) / s.Width;
                selected.FY = (t - s.Y) / s.Height;
                selected.FW = (r - l) / s.Width;
                selected.FH = (b - t) / s.Height;
                if (ItemEdited != null) ItemEdited();
                Invalidate();
                return;
            }

            Cursor = Cursors.Default;
            if (selected != null && Items.Contains(selected))
            {
                int h = HitHandle(ItemRect(selected, s), e.Location);
                if (h >= 0) { Cursor = CursorForHandle(h); return; }
            }
            foreach (var it in Items)
                if (ItemRect(it, s).Contains(e.Location)) { Cursor = Cursors.SizeAll; break; }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (mode != Mode.None)
            {
                mode = Mode.None;
                if (EditFinished != null) EditFinished();
            }
        }

        protected override void OnMouseDoubleClick(MouseEventArgs e)
        {
            base.OnMouseDoubleClick(e);
            if (selected != null && ItemDoubleClicked != null) ItemDoubleClicked();
        }

        // ---------------- Keyboard ----------------
        protected override bool IsInputKey(Keys keyData)
        {
            switch (keyData & Keys.KeyCode)
            {
                case Keys.Left: case Keys.Right: case Keys.Up: case Keys.Down: return true;
            }
            return base.IsInputKey(keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (selected == null) return;
            var s = SlideRect();
            if (s.IsEmpty) return;

            if (e.KeyCode == Keys.Delete) { if (DeleteRequested != null) DeleteRequested(); e.Handled = true; return; }

            float step = e.Shift ? 10f : 1f;
            bool moved = true;
            switch (e.KeyCode)
            {
                case Keys.Left: selected.FX -= step / s.Width; break;
                case Keys.Right: selected.FX += step / s.Width; break;
                case Keys.Up: selected.FY -= step / s.Height; break;
                case Keys.Down: selected.FY += step / s.Height; break;
                default: moved = false; break;
            }
            if (moved)
            {
                e.Handled = true;
                if (ItemEdited != null) ItemEdited();
                if (EditFinished != null) EditFinished();
                Invalidate();
            }
        }
    }

    // =====================================================================
    //  MAIN FORM
    // =====================================================================
    public class MainForm : Form
    {
        private const int ThumbW = 240, ThumbH = 135;

        // --- Excel converter window (opened from the "Convert Excel" button) ---
        private ExcelToPpt.ExcelConverterForm excelForm;

        private void OpenExcelConverter()
        {
            if (excelForm == null || excelForm.IsDisposed)
            {
                excelForm = new ExcelToPpt.ExcelConverterForm();
                excelForm.Icon = this.Icon;
                excelForm.Show(this);
            }
            else
            {
                if (excelForm.WindowState == FormWindowState.Minimized) excelForm.WindowState = FormWindowState.Normal;
                excelForm.Activate();
            }
        }

        // --- controls ---
        private ListView lv;
        private ImageList imgList;
        private ListBox lstItems;
        private SlideCanvas canvas;
        private NumericUpDown numSlide, numFont, numX, numY, numW, numH;
        private Label lblTotal, lblStatus, lblCount, lblEditing;
        private TextBox txtText, txtImage, txtOutput, txtLog;
        private ComboBox cmbFont, cmbAlign;
        private CheckBox chkBold, chkOverwrite, chkBackup;
        private Button btnColor, btnChangeImage, btnProcess, btnOut, btnOpenPpt;
        private Panel pnlColor;
        private ProgressBar progress;
        private ToolTip toolTip;
        private LinkLabel lnkWebsite;
        private Label lblVersion;

        // --- data ---
        private readonly List<PptFile> files = new List<PptFile>();
        private readonly Queue<PptFile> previewQueue = new Queue<PptFile>();
        private readonly List<ContentItem> items = new List<ContentItem>();
        private readonly List<ContentItem> listMap = new List<ContentItem>();
        private PptFile active;
        private double slideWPt = 960, slideHPt = 540;
        private bool updatingUI, rebuilding, previewRunning;

        private double BaseWPt { get { return files.Count > 0 ? files[0].WPt : 960; } }
        private long BaseCx { get { return files.Count > 0 ? files[0].Cx : 12192000; } }

        public MainForm()
        {
            Text = "Batch PPT Inserter  v1.0.0";
            Size = new Size(1420, 920);
            MinimumSize = new Size(1150, 760);
            StartPosition = FormStartPosition.CenterScreen;

            // Load high-quality app icon
            try
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string icoPath = Path.Combine(baseDir, "app.ico");
                string pngPath = Path.Combine(baseDir, "appicon.png");
                if (File.Exists(icoPath))
                    Icon = new Icon(icoPath);
                else if (File.Exists(pngPath))
                {
                    using (var bmp = new Bitmap(pngPath))
                    {
                        IntPtr hIcon = bmp.GetHicon();
                        Icon = Icon.FromHandle(hIcon);
                    }
                }
            }
            catch { }


            BuildUI();
            SetActive(null);
            LoadProps();
        }

        // ================= UI =================
        private void BuildUI()
        {
            toolTip = new ToolTip
            {
                AutoPopDelay = 6000,
                InitialDelay = 400,
                ReshowDelay = 200,
                ShowAlways = true
            };

            // ---------- LEFT: PPT list with live thumbnails ----------
            var pnlLeft = new Panel { Dock = DockStyle.Left, Width = 300, Padding = new Padding(8) };
            var gbFiles = new GroupBox { Text = "1. PowerPoint files (.pptx)", Dock = DockStyle.Fill };

            imgList = new ImageList { ColorDepth = ColorDepth.Depth32Bit, ImageSize = new Size(ThumbW, ThumbH) };
            lv = new ListView
            {
                Dock = DockStyle.Fill, View = View.LargeIcon, LargeImageList = imgList,
                CheckBoxes = true, MultiSelect = false, HideSelection = false, AllowDrop = true,
                ShowItemToolTips = true
            };
            lv.DragEnter += (s, e) => { if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy; };
            lv.DragDrop += (s, e) => AddFiles((string[])e.Data.GetData(DataFormats.FileDrop));
            lv.SelectedIndexChanged += (s, e) =>
            {
                if (rebuilding || lv.SelectedIndices.Count != 1) return;
                int i = lv.SelectedIndices[0];
                if (i >= 0 && i < files.Count && files[i] != active) SetActive(files[i]);
            };
            lv.ItemChecked += (s, e) =>
            {
                if (rebuilding) return;
                int i = e.Item.Index;
                if (i < 0 || i >= files.Count) return;
                files[i].Checked = e.Item.Checked;
                UpdateCount();
                RefreshThumb(i, (int)numSlide.Value);
            };

            var pnlFileBtns = new Panel { Dock = DockStyle.Bottom, Height = 165 };
            var btnAdd = new Button { Text = "Add PPT...", Location = new Point(3, 5), Size = new Size(88, 28) };
            var btnRemove = new Button { Text = "Remove", Location = new Point(95, 5), Size = new Size(88, 28) };
            var btnClear = new Button { Text = "Clear all", Location = new Point(187, 5), Size = new Size(88, 28) };
            var btnCheckAll = new Button { Text = "Check all", Location = new Point(3, 38), Size = new Size(134, 28) };
            var btnUncheckAll = new Button { Text = "Uncheck all", Location = new Point(141, 38), Size = new Size(134, 28) };
            btnOpenPpt = new Button { Text = "Open in PowerPoint", Location = new Point(3, 70), Size = new Size(272, 28) };
            lblCount = new Label { Location = new Point(3, 104), Size = new Size(272, 20), Text = "Applies to 0 of 0 files", Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            lblEditing = new Label { Location = new Point(3, 124), Size = new Size(272, 38), ForeColor = Color.DimGray, Text = "Checked files receive the content. Click a file to preview and edit it." };

            btnAdd.Click += (s, e) =>
            {
                using (var ofd = new OpenFileDialog { Filter = "PowerPoint (*.pptx)|*.pptx", Multiselect = true })
                    if (ofd.ShowDialog() == DialogResult.OK) AddFiles(ofd.FileNames);
            };
            btnRemove.Click += (s, e) => RemoveSelectedFile();
            btnClear.Click += (s, e) => ClearFiles();
            btnCheckAll.Click += (s, e) => SetAllChecked(true);
            btnUncheckAll.Click += (s, e) => SetAllChecked(false);
            btnOpenPpt.Click += (s, e) => OpenSelectedInPowerPoint();

            toolTip.SetToolTip(btnAdd, "Add one or more PowerPoint (.pptx) files to the list");
            toolTip.SetToolTip(btnRemove, "Remove the currently selected file from the list");
            toolTip.SetToolTip(btnClear, "Remove all PowerPoint files from the list");
            toolTip.SetToolTip(btnCheckAll, "Check every file so content will be applied to all of them");
            toolTip.SetToolTip(btnUncheckAll, "Uncheck every file so none will be processed");
            toolTip.SetToolTip(btnOpenPpt, "Open the selected PowerPoint file in the default application (PowerPoint)");

            pnlFileBtns.Controls.AddRange(new Control[] { btnAdd, btnRemove, btnClear, btnCheckAll, btnUncheckAll, btnOpenPpt, lblCount, lblEditing });
            gbFiles.Controls.Add(lv);
            gbFiles.Controls.Add(pnlFileBtns);
            pnlLeft.Controls.Add(gbFiles);

            // ---------- RIGHT: properties + item list ----------
            var pnlRight = new Panel { Dock = DockStyle.Right, Width = 340, Padding = new Padding(8) };

            var gbProps = new GroupBox { Text = "Selected item properties", Dock = DockStyle.Top, Height = 385 };
            gbProps.Controls.Add(new Label { Text = "Text:", Location = new Point(10, 22), AutoSize = true });
            txtText = new TextBox { Location = new Point(10, 40), Size = new Size(305, 80), Multiline = true, ScrollBars = ScrollBars.Vertical, AcceptsReturn = true };
            txtText.TextChanged += (s, e) =>
            {
                if (updatingUI || canvas.Selected == null || canvas.Selected.IsImage) return;
                canvas.Selected.Text = txtText.Text;
                canvas.Invalidate();
                RefreshItemList();
                RefreshThumbs();
            };

            gbProps.Controls.Add(new Label { Text = "Font", Location = new Point(10, 133), AutoSize = true });
            cmbFont = new ComboBox { Location = new Point(50, 130), Width = 170, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbFont.Items.Add("(Follow PPT theme)");
            foreach (var ff in FontFamily.Families) cmbFont.Items.Add(ff.Name);
            cmbFont.SelectedIndex = 0;
            cmbFont.SelectedIndexChanged += (s, e) =>
            {
                if (updatingUI || canvas.Selected == null) return;
                canvas.Selected.FontName = cmbFont.SelectedIndex <= 0 ? null : (string)cmbFont.SelectedItem;
                canvas.Invalidate();
                RefreshThumbs();
            };
            gbProps.Controls.Add(new Label { Text = "Size", Location = new Point(228, 133), AutoSize = true });
            numFont = new NumericUpDown { Location = new Point(262, 130), Width = 55, Minimum = 6, Maximum = 200, Value = 24 };
            numFont.ValueChanged += (s, e) =>
            {
                if (updatingUI || canvas.Selected == null) return;
                canvas.Selected.FontSize = (int)numFont.Value;
                canvas.Invalidate();
                RefreshThumbs();
            };

            chkBold = new CheckBox { Text = "Bold", Location = new Point(10, 168), AutoSize = true };
            chkBold.CheckedChanged += (s, e) =>
            {
                if (updatingUI || canvas.Selected == null) return;
                canvas.Selected.Bold = chkBold.Checked;
                canvas.Invalidate();
                RefreshThumbs();
            };
            gbProps.Controls.Add(new Label { Text = "Align", Location = new Point(70, 170), AutoSize = true });
            cmbAlign = new ComboBox { Location = new Point(110, 166), Width = 75, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbAlign.Items.AddRange(new object[] { "Left", "Center", "Right" });
            cmbAlign.SelectedIndex = 0;
            cmbAlign.SelectedIndexChanged += (s, e) =>
            {
                if (updatingUI || canvas.Selected == null) return;
                canvas.Selected.Align = cmbAlign.SelectedIndex;
                canvas.Invalidate();
                RefreshThumbs();
            };
            btnColor = new Button { Text = "Color", Location = new Point(192, 164), Size = new Size(62, 27) };
            pnlColor = new Panel { Location = new Point(262, 166), Size = new Size(52, 23), BorderStyle = BorderStyle.FixedSingle, BackColor = Color.Black };
            toolTip.SetToolTip(btnColor, "Choose text color for the selected text item");
            btnColor.Click += (s, e) =>
            {
                if (canvas.Selected == null || canvas.Selected.IsImage) return;
                using (var cd = new ColorDialog { Color = Color.FromArgb(canvas.Selected.ColorArgb), FullOpen = true })
                    if (cd.ShowDialog() == DialogResult.OK)
                    {
                        canvas.Selected.ColorArgb = cd.Color.ToArgb();
                        pnlColor.BackColor = cd.Color;
                        canvas.Invalidate();
                        RefreshThumbs();
                    }
            };

            gbProps.Controls.Add(new Label { Text = "Image", Location = new Point(10, 210), AutoSize = true });
            txtImage = new TextBox { Location = new Point(55, 207), Width = 185, ReadOnly = true };
            btnChangeImage = new Button { Text = "Change...", Location = new Point(245, 205), Size = new Size(70, 27) };
            toolTip.SetToolTip(btnChangeImage, "Replace the image of the selected image item");
            btnChangeImage.Click += (s, e) =>
            {
                var it = canvas.Selected;
                if (it == null || !it.IsImage) return;
                using (var ofd = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.gif;*.bmp" })
                    if (ofd.ShowDialog() == DialogResult.OK && LoadImageInto(it, ofd.FileName))
                    {
                        it.FH = it.FW * slideWPt * it.ImgRatio / slideHPt;
                        LoadProps();
                        canvas.Invalidate();
                        RefreshItemList();
                        RefreshThumbs();
                    }
            };

            gbProps.Controls.Add(new Label { Text = "Position && size (cm):", Location = new Point(10, 248), AutoSize = true });
            gbProps.Controls.Add(new Label { Text = "X", Location = new Point(10, 276), AutoSize = true });
            numX = MakeCm(gbProps, 30, 272);
            gbProps.Controls.Add(new Label { Text = "Y", Location = new Point(170, 276), AutoSize = true });
            numY = MakeCm(gbProps, 190, 272);
            gbProps.Controls.Add(new Label { Text = "W", Location = new Point(10, 310), AutoSize = true });
            numW = MakeCm(gbProps, 30, 306);
            gbProps.Controls.Add(new Label { Text = "H", Location = new Point(170, 310), AutoSize = true });
            numH = MakeCm(gbProps, 190, 306);

            gbProps.Controls.Add(new Label
            {
                Text = "Drag the box on the canvas to move / resize. Arrow keys nudge 1 px (Shift = 10 px). Delete removes the item.",
                Location = new Point(10, 340), Size = new Size(305, 40), ForeColor = Color.DimGray
            });
            gbProps.Controls.AddRange(new Control[] { txtText, cmbFont, numFont, chkBold, cmbAlign, btnColor, pnlColor, txtImage, btnChangeImage });

            var gbItems = new GroupBox { Text = "All items (click to jump to its slide)", Dock = DockStyle.Fill };
            lstItems = new ListBox { Dock = DockStyle.Fill, HorizontalScrollbar = true };
            lstItems.SelectedIndexChanged += (s, e) =>
            {
                if (updatingUI) return;
                int idx = lstItems.SelectedIndex;
                if (idx < 0 || idx >= listMap.Count) return;
                var it = listMap[idx];
                if (it.Slide != (int)numSlide.Value) numSlide.Value = Math.Min(numSlide.Maximum, it.Slide);
                canvas.Selected = it;
                LoadProps();
            };
            gbItems.Controls.Add(lstItems);

            pnlRight.Controls.Add(gbItems);
            pnlRight.Controls.Add(gbProps);

            // ---------- BOTTOM: output & process ----------
            var pnlBottom = new Panel { Dock = DockStyle.Bottom, Height = 175, Padding = new Padding(8) };
            pnlBottom.Controls.Add(new Label { Text = "Output folder:", Location = new Point(10, 14), AutoSize = true });
            txtOutput = new TextBox { Location = new Point(100, 10), Width = 900, ReadOnly = true, Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            btnOut = new Button { Text = "Browse...", Location = new Point(1010, 8), Size = new Size(85, 27), Anchor = AnchorStyles.Top | AnchorStyles.Right };
            btnOut.Click += (s, e) =>
            {
                using (var fbd = new FolderBrowserDialog())
                    if (fbd.ShowDialog() == DialogResult.OK) txtOutput.Text = fbd.SelectedPath;
            };
            chkOverwrite = new CheckBox { Text = "Overwrite original files (close them in PowerPoint first)", Location = new Point(10, 40), AutoSize = true };
            chkBackup = new CheckBox { Text = "Create .bak backup", Location = new Point(430, 40), AutoSize = true, Checked = false, Enabled = false };
            chkOverwrite.CheckedChanged += (s, e) =>
            {
                txtOutput.Enabled = !chkOverwrite.Checked;
                btnOut.Enabled = !chkOverwrite.Checked;
                chkBackup.Enabled = chkOverwrite.Checked;
            };
            btnProcess = new Button { Text = "PROCESS CHECKED FILES", Location = new Point(10, 68), Size = new Size(220, 36), Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            btnProcess.Click += async (s, e) => await RunProcess();
            progress = new ProgressBar { Location = new Point(240, 74), Size = new Size(855, 22), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right };
            txtLog = new TextBox { Location = new Point(10, 110), Size = new Size(1085, 58), Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right };

            toolTip.SetToolTip(btnOut, "Choose the folder where processed PPT files will be saved");
            toolTip.SetToolTip(chkOverwrite, "Overwrite the original files instead of writing to an output folder (close files in PowerPoint first)");
            toolTip.SetToolTip(chkBackup, "When overwriting, also create a .bak backup of the original file");
            toolTip.SetToolTip(btnProcess, "Apply the current text & image items to all checked PowerPoint files.\nExisting content on those slides will be cleared first.");

            pnlBottom.Controls.AddRange(new Control[] { txtOutput, btnOut, chkOverwrite, chkBackup, btnProcess, progress, txtLog });

            // ---------- CENTER: toolbar + canvas ----------
            var pnlCenter = new Panel { Dock = DockStyle.Fill };
            var pnlTool = new Panel { Dock = DockStyle.Top, Height = 46 };

            var btnPrev = new Button { Text = "<", Location = new Point(8, 8), Size = new Size(36, 28) };
            var btnNext = new Button { Text = ">", Location = new Point(196, 8), Size = new Size(36, 28) };
            pnlTool.Controls.Add(new Label { Text = "Slide", Location = new Point(52, 14), AutoSize = true });
            numSlide = new NumericUpDown { Location = new Point(92, 10), Width = 55, Minimum = 1, Maximum = 1, Value = 1 };
            lblTotal = new Label { Text = "/ 1", Location = new Point(152, 14), AutoSize = true };
            btnPrev.Click += (s, e) => { if (numSlide.Value > numSlide.Minimum) numSlide.Value--; };
            btnNext.Click += (s, e) => { if (numSlide.Value < numSlide.Maximum) numSlide.Value++; };
            numSlide.ValueChanged += (s, e) => ShowSlide();

            var btnAddText = new Button { Text = "+ Text", Location = new Point(250, 8), Size = new Size(95, 28) };
            var btnAddImg = new Button { Text = "+ Image", Location = new Point(350, 8), Size = new Size(95, 28) };
            var btnDelItem = new Button { Text = "Delete item", Location = new Point(450, 8), Size = new Size(95, 28) };
            btnAddText.Click += (s, e) => AddItem(false);
            btnAddImg.Click += (s, e) => AddItem(true);
            btnDelItem.Click += (s, e) => DeleteSelected();
            var btnExcel = new Button { Text = "Convert Excel", Location = new Point(900, 8), Size = new Size(110, 28) };
            btnExcel.Click += (s, e) => OpenExcelConverter();
            pnlTool.Resize += (s, e) => btnExcel.Left = Math.Max(560, pnlTool.ClientSize.Width - btnExcel.Width - 10);
            lblStatus = new Label { Text = "Add PPT files on the left to get started.", Location = new Point(560, 15), AutoSize = true, ForeColor = Color.DimGray };

            toolTip.SetToolTip(btnPrev, "Go to previous slide");
            toolTip.SetToolTip(btnNext, "Go to next slide");
            toolTip.SetToolTip(numSlide, "Current slide number");
            toolTip.SetToolTip(btnAddText, "Add a new text box on the current slide");
            toolTip.SetToolTip(btnAddImg, "Add a new image on the current slide");
            toolTip.SetToolTip(btnDelItem, "Delete the currently selected item from the canvas");
            toolTip.SetToolTip(btnExcel, "Open the Excel to PPT (Store Profile) converter");

            pnlTool.Controls.AddRange(new Control[] { btnPrev, numSlide, lblTotal, btnNext, btnAddText, btnAddImg, btnDelItem, btnExcel, lblStatus });

            canvas = new SlideCanvas { Dock = DockStyle.Fill };
            canvas.SelectionChanged += () => LoadProps();
            canvas.ItemEdited += () => UpdatePosFields();
            canvas.EditFinished += () => { RefreshItemList(); RefreshThumbs(); };
            canvas.DeleteRequested += () => DeleteSelected();
            canvas.ItemDoubleClicked += () =>
            {
                if (canvas.Selected != null && !canvas.Selected.IsImage) { txtText.Focus(); txtText.SelectAll(); }
            };

            pnlCenter.Controls.Add(canvas);
            pnlCenter.Controls.Add(pnlTool);

            // ---------- FOOTER: version + website ----------
            var pnlFooter = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 28,
                BackColor = Color.FromArgb(245, 247, 250),
                Padding = new Padding(8, 4, 8, 4)
            };
            lblVersion = new Label
            {
                Text = "Model version : 1.0.0",
                AutoSize = true,
                Location = new Point(10, 6),
                ForeColor = Color.FromArgb(80, 80, 90),
                Font = new Font("Segoe UI", 8.5f)
            };
            lnkWebsite = new LinkLabel
            {
                Text = "https://ranjhafriel.web.app/",
                AutoSize = true,
                Location = new Point(160, 6),
                LinkColor = Color.FromArgb(0, 102, 204),
                ActiveLinkColor = Color.FromArgb(0, 70, 160),
                Font = new Font("Segoe UI", 8.5f)
            };
            lnkWebsite.LinkClicked += (s, e) =>
            {
                try
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "https://ranjhafriel.web.app/",
                        UseShellExecute = true
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Could not open website:\n" + ex.Message);
                }
            };
            toolTip.SetToolTip(lnkWebsite, "Open Ran JS website in your browser");

            var lblBrand = new Label
            {
                Text = "Ran JS  •  Simple • Fast • Reliable",
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                ForeColor = Color.FromArgb(100, 110, 130),
                Font = new Font("Segoe UI", 8.5f)
            };
            // Position brand on the right after layout
            pnlFooter.Resize += (s, e) =>
            {
                lblBrand.Location = new Point(pnlFooter.ClientSize.Width - lblBrand.Width - 12, 6);
            };
            pnlFooter.Controls.Add(lblVersion);
            pnlFooter.Controls.Add(lnkWebsite);
            pnlFooter.Controls.Add(lblBrand);

            // Docking order: Fill first, then sides, then bottom panels (footer last so it stays at very bottom)
            Controls.Add(pnlCenter);
            Controls.Add(pnlRight);
            Controls.Add(pnlLeft);
            Controls.Add(pnlBottom);
            Controls.Add(pnlFooter);

            FormClosed += (s, e) => { foreach (var f in files) DisposeImages(f); };
        }

        private NumericUpDown MakeCm(GroupBox parent, int x, int y)
        {
            var n = new NumericUpDown { Location = new Point(x, y), Width = 110, DecimalPlaces = 2, Increment = 0.1M, Minimum = -200, Maximum = 600 };
            n.ValueChanged += PosChanged;
            parent.Controls.Add(n);
            return n;
        }

        // ================= FILE LIST =================
        private PptFile ReadInfo(string path)
        {
            try
            {
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var doc = PresentationDocument.Open(fs, false))
                {
                    var pres = doc.PresentationPart.Presentation;
                    long cx = pres.SlideSize.Cx.Value, cy = pres.SlideSize.Cy.Value;
                    return new PptFile
                    {
                        FilePath = path, Cx = cx, WPt = cx / 12700.0, HPt = cy / 12700.0,
                        Count = pres.SlideIdList.ChildElements.Count
                    };
                }
            }
            catch (Exception ex)
            {
                Log("Cannot read " + Path.GetFileName(path) + ": " + ex.Message);
                return null;
            }
        }

        private void AddFiles(IEnumerable<string> paths)
        {
            bool added = false;
            foreach (var p in paths)
            {
                if (!p.EndsWith(".pptx", StringComparison.OrdinalIgnoreCase)) continue;
                if (files.Any(x => string.Equals(x.FilePath, p, StringComparison.OrdinalIgnoreCase))) continue;
                var f = ReadInfo(p);
                if (f == null) continue;
                files.Add(f);
                previewQueue.Enqueue(f);
                added = true;
            }
            if (!added) return;

            if (active == null) active = files[0];
            RebuildList();
            SetActive(active);
            UpdateCount();
            PumpPreviews();
        }

        private void RemoveSelectedFile()
        {
            if (lv.SelectedIndices.Count != 1) return;
            int i = lv.SelectedIndices[0];
            if (i < 0 || i >= files.Count) return;
            var f = files[i];
            files.RemoveAt(i);
            DisposeImages(f);
            if (active == f) active = files.FirstOrDefault();
            RebuildList();
            SetActive(active);
            UpdateCount();
        }

        private void OpenSelectedInPowerPoint()
        {
            if (active == null || string.IsNullOrEmpty(active.FilePath) || !File.Exists(active.FilePath))
            {
                MessageBox.Show("Please select a PowerPoint file first.", "Open in PowerPoint",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = active.FilePath,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not open the file:\n" + ex.Message, "Open in PowerPoint",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ClearFiles()
        {
            foreach (var f in files) DisposeImages(f);
            files.Clear();
            previewQueue.Clear();
            active = null;
            RebuildList();
            SetActive(null);
            UpdateCount();
        }

        private void SetAllChecked(bool value)
        {
            rebuilding = true;
            for (int i = 0; i < files.Count; i++)
            {
                files[i].Checked = value;
                if (i < lv.Items.Count) lv.Items[i].Checked = value;
            }
            rebuilding = false;
            UpdateCount();
            RefreshThumbs();
        }

        private void UpdateCount()
        {
            int c = files.Count(x => x.Checked);
            lblCount.Text = "Applies to " + c + " of " + files.Count + " file(s)";
        }

        private void RebuildList()
        {
            rebuilding = true;
            lv.BeginUpdate();
            lv.Items.Clear();
            imgList.Images.Clear();
            int cur = (int)numSlide.Value;
            for (int i = 0; i < files.Count; i++)
            {
                using (var b = MakeThumb(files[i], cur)) imgList.Images.Add(b);
                var lvi = new ListViewItem(Path.GetFileName(files[i].FilePath), i)
                {
                    Checked = files[i].Checked,
                    ToolTipText = files[i].FilePath
                };
                lv.Items.Add(lvi);
                if (files[i] == active) lvi.Selected = true;
            }
            lv.EndUpdate();
            rebuilding = false;
            canvas.FontBaseWPt = BaseWPt;
        }

        // ---------- live thumbnails ----------
        private Bitmap MakeThumb(PptFile f, int slide)
        {
            var bmp = new Bitmap(ThumbW, ThumbH);
            using (var g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.FromArgb(64, 64, 64));
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;

                double aspect = f.WPt / f.HPt;
                float aw = ThumbW - 8, ah = ThumbH - 8;
                float w = aw, h = (float)(aw / aspect);
                if (h > ah) { h = ah; w = (float)(ah * aspect); }
                var r = new RectangleF((ThumbW - w) / 2f, (ThumbH - h) / 2f, w, h);
                g.FillRectangle(Brushes.White, r);

                bool hasSlide = slide >= 1 && slide <= f.Count;
                string msg = null;
                if (!hasSlide) msg = "No slide " + slide + " - skipped";
                else if (f.Images != null && slide - 1 < f.Images.Length && f.Images[slide - 1] != null)
                    g.DrawImage(f.Images[slide - 1], r);
                else if (f.Loading || f.Images == null) msg = "Loading preview...";

                if (msg != null)
                    using (var font = new Font("Segoe UI", 8f))
                        g.DrawString(msg, font, Brushes.Gray, r.X + 4, r.Y + 4);

                if (hasSlide && f.Checked)
                    SlideCanvas.DrawItems(g, r, f.WPt, BaseWPt, items.Where(i => i.Slide == slide));

                g.DrawRectangle(Pens.Black, r.X, r.Y, r.Width, r.Height);

                if (!f.Checked)
                    using (var br = new SolidBrush(Color.FromArgb(150, 90, 90, 90)))
                        g.FillRectangle(br, r);
            }
            return bmp;
        }

        private void RefreshThumb(int i, int slide)
        {
            if (rebuilding || i < 0 || i >= files.Count || i >= imgList.Images.Count) return;
            using (var b = MakeThumb(files[i], slide)) imgList.Images[i] = b;
            if (i < lv.Items.Count) lv.RedrawItems(i, i, false);
        }

        private void RefreshThumbs()
        {
            if (rebuilding) return;
            int cur = (int)numSlide.Value;
            for (int i = 0; i < files.Count; i++) RefreshThumb(i, cur);
            lv.Invalidate();
        }

        // ================= PREVIEW via PowerPoint (COM, late binding) =================
        private async void PumpPreviews()
        {
            if (previewRunning) return;
            previewRunning = true;

            while (previewQueue.Count > 0 && !IsDisposed)
            {
                var f = previewQueue.Dequeue();
                if (!files.Contains(f)) continue;

                f.Loading = true;
                lblStatus.Text = "Loading slide previews from PowerPoint... (" + (previewQueue.Count + 1) + " file(s) left)";
                RefreshThumb(files.IndexOf(f), (int)numSlide.Value);

                int pxW = f.Count <= 30 ? 1280 : 960;
                int pxH = (int)Math.Round(pxW * f.HPt / f.WPt);
                Bitmap[] res = null;
                try { res = await RunSta(() => ExportAllSlides(f.FilePath, f.Count, pxW, pxH)); }
                catch { res = null; }

                f.Loading = false;
                if (IsDisposed) return;
                if (!files.Contains(f))
                {
                    if (res != null) foreach (var b in res) if (b != null) b.Dispose();
                    continue;
                }

                f.Images = res;
                RefreshThumb(files.IndexOf(f), (int)numSlide.Value);
                if (f == active) ApplySlideImage();
            }

            previewRunning = false;
            if (IsDisposed) return;
            bool anyMissing = files.Any(x => x.Images == null);
            lblStatus.Text = anyMissing
                ? "Preview unavailable (PowerPoint not detected). You can still position items on the blank canvas."
                : "Previews ready. Drag items on the canvas to position them.";
        }

        private static Task<T> RunSta<T>(Func<T> f)
        {
            var tcs = new TaskCompletionSource<T>();
            var th = new Thread(() =>
            {
                try { tcs.SetResult(f()); }
                catch (Exception ex) { tcs.SetException(ex); }
            });
            th.SetApartmentState(ApartmentState.STA);
            th.IsBackground = true;
            th.Start();
            return tcs.Task;
        }

        private static Bitmap[] ExportAllSlides(string path, int count, int pxW, int pxH)
        {
            Type t = Type.GetTypeFromProgID("PowerPoint.Application");
            if (t == null) return null;

            dynamic app = null, pres = null;
            bool weOpened = false;
            string tmpDir = Path.Combine(Path.GetTempPath(), "bpi_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(tmpDir);
            try
            {
                app = Activator.CreateInstance(t);

                // If the user already has this file open in PowerPoint, reuse it (and never close it)
                int open = (int)app.Presentations.Count;
                for (int i = 1; i <= open; i++)
                {
                    dynamic p = app.Presentations[i];
                    if (string.Equals((string)p.FullName, path, StringComparison.OrdinalIgnoreCase)) { pres = p; break; }
                }
                if (pres == null)
                {
                    pres = app.Presentations.Open(path, -1, 0, 0);   // read-only, no window
                    weOpened = true;
                }

                int n = Math.Min(count, (int)pres.Slides.Count);
                var res = new Bitmap[count];
                for (int i = 1; i <= n; i++)
                {
                    string f = Path.Combine(tmpDir, i + ".png");
                    pres.Slides[i].Export(f, "PNG", pxW, pxH);
                    using (var fs = new FileStream(f, FileMode.Open, FileAccess.Read, FileShare.Read))
                    using (var img = Image.FromStream(fs))
                        res[i - 1] = new Bitmap(img);
                }
                return res;
            }
            finally
            {
                try { if (weOpened && pres != null) pres.Close(); } catch { }
                try { if (app != null && (int)app.Presentations.Count == 0) app.Quit(); } catch { }
                try { Directory.Delete(tmpDir, true); } catch { }
            }
        }

        private static void DisposeImages(PptFile f)
        {
            if (f.Images == null) return;
            foreach (var b in f.Images) if (b != null) b.Dispose();
            f.Images = null;
        }

        // ================= ACTIVE FILE / SLIDE =================
        private void SetActive(PptFile f)
        {
            active = f;
            slideWPt = f != null ? f.WPt : 960;
            slideHPt = f != null ? f.HPt : 540;
            canvas.SlideWPt = slideWPt;
            canvas.SlideHPt = slideHPt;
            canvas.FontBaseWPt = BaseWPt;

            lblEditing.Text = f != null
                ? "Editing: " + Path.GetFileName(f.FilePath) + "\nClick another file to switch."
                : "Checked files receive the content. Click a file to preview and edit it.";

            int max = Math.Max(1, files.Count == 0 ? 1 : files.Max(x => x.Count));
            numSlide.Maximum = max;
            lblTotal.Text = "/ " + max;

            if (f != null && !rebuilding)
            {
                int i = files.IndexOf(f);
                if (i >= 0 && i < lv.Items.Count && !lv.Items[i].Selected)
                {
                    rebuilding = true;
                    lv.Items[i].Selected = true;
                    rebuilding = false;
                }
            }
            ShowSlide();
        }

        private void ApplySlideImage()
        {
            int cur = (int)numSlide.Value;
            Bitmap img = null;
            string msg;
            if (active == null) msg = "Add PPT files on the left to get started.";
            else if (cur > active.Count) msg = "This file has no slide " + cur + " - it will be skipped.";
            else if (active.Images != null && cur - 1 < active.Images.Length && active.Images[cur - 1] != null)
            { img = active.Images[cur - 1]; msg = ""; }
            else if (active.Loading || (active.Images == null && previewQueue.Contains(active)))
                msg = "Loading slide preview from PowerPoint...";
            else msg = "Slide preview not available (PowerPoint not detected).\nPosition items on this blank canvas.";

            canvas.SlideImage = img;
            canvas.EmptyMessage = msg;
            canvas.Invalidate();
        }

        private void ShowSlide()
        {
            int cur = (int)numSlide.Value;
            canvas.Items = items.Where(i => i.Slide == cur).ToList();
            canvas.Selected = null;
            ApplySlideImage();
            LoadProps();
            RefreshItemList();
            RefreshThumbs();
        }

        // ================= ITEMS =================
        private bool LoadImageInto(ContentItem it, string path)
        {
            try
            {
                byte[] data = File.ReadAllBytes(path);
                using (var ms = new MemoryStream(data))
                using (var img = Image.FromStream(ms))
                {
                    if (it.Preview != null) it.Preview.Dispose();
                    it.Preview = new Bitmap(img);
                    it.ImgRatio = (double)img.Height / img.Width;
                }
                it.ImagePath = path;
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not open image: " + ex.Message);
                return false;
            }
        }

        private void AddItem(bool image)
        {
            var it = new ContentItem { Slide = (int)numSlide.Value, IsImage = image };
            if (image)
            {
                using (var ofd = new OpenFileDialog { Filter = "Images|*.png;*.jpg;*.jpeg;*.gif;*.bmp" })
                {
                    if (ofd.ShowDialog() != DialogResult.OK) return;
                    if (!LoadImageInto(it, ofd.FileName)) return;
                }
                it.FW = 0.3;
                it.FH = it.FW * slideWPt * it.ImgRatio / slideHPt;
                if (it.FH > 0.8) { it.FH = 0.8; it.FW = it.FH * slideHPt / (slideWPt * it.ImgRatio); }
                it.FX = (1 - it.FW) / 2;
                it.FY = (1 - it.FH) / 2;
            }
            else
            {
                it.FX = 0.1; it.FY = 0.1; it.FW = 0.5; it.FH = 0.15;
            }

            items.Add(it);
            ShowSlide();
            canvas.Selected = it;
            LoadProps();
            RefreshItemList();
            if (!image) { txtText.Focus(); txtText.SelectAll(); }
        }

        private void DeleteSelected()
        {
            var it = canvas.Selected;
            if (it == null) return;
            items.Remove(it);
            if (it.Preview != null) it.Preview.Dispose();
            ShowSlide();
        }

        private void RefreshItemList()
        {
            updatingUI = true;
            lstItems.Items.Clear();
            listMap.Clear();
            foreach (var it in items.OrderBy(i => i.Slide))
            {
                listMap.Add(it);
                lstItems.Items.Add(it.ToString());
            }
            if (canvas.Selected != null)
            {
                int idx = listMap.IndexOf(canvas.Selected);
                if (idx >= 0) lstItems.SelectedIndex = idx;
            }
            updatingUI = false;
        }

        // ================= PROPERTIES =================
        private static void SetNum(NumericUpDown n, double v)
        {
            decimal d = (decimal)Math.Round(v, 2);
            n.Value = Math.Min(n.Maximum, Math.Max(n.Minimum, d));
        }

        private void LoadProps()
        {
            updatingUI = true;
            var it = canvas.Selected;
            bool has = it != null;
            bool isText = has && !it.IsImage;
            bool isImg = has && it.IsImage;

            txtText.Enabled = cmbFont.Enabled = numFont.Enabled = chkBold.Enabled =
                cmbAlign.Enabled = btnColor.Enabled = isText;
            txtImage.Enabled = btnChangeImage.Enabled = isImg;
            numX.Enabled = numY.Enabled = numW.Enabled = numH.Enabled = has;

            if (has)
            {
                txtText.Text = isText ? it.Text : "";
                if (isText)
                {
                    int fi = it.FontName == null ? 0 : cmbFont.Items.IndexOf(it.FontName);
                    cmbFont.SelectedIndex = fi < 0 ? 0 : fi;
                    numFont.Value = Math.Min(numFont.Maximum, Math.Max(numFont.Minimum, it.FontSize));
                    chkBold.Checked = it.Bold;
                    cmbAlign.SelectedIndex = it.Align;
                    pnlColor.BackColor = Color.FromArgb(it.ColorArgb);
                }
                txtImage.Text = isImg ? it.ImagePath : "";
                UpdatePosFieldsCore();
            }
            else
            {
                txtText.Text = "";
                txtImage.Text = "";
            }

            int idx = has ? listMap.IndexOf(it) : -1;
            if (idx >= 0) lstItems.SelectedIndex = idx; else lstItems.ClearSelected();
            updatingUI = false;
        }

        private void UpdatePosFields()
        {
            bool prev = updatingUI;
            updatingUI = true;
            UpdatePosFieldsCore();
            updatingUI = prev;
        }

        private void UpdatePosFieldsCore()
        {
            var it = canvas.Selected;
            if (it == null) return;
            double wcm = slideWPt / 72.0 * 2.54, hcm = slideHPt / 72.0 * 2.54;
            SetNum(numX, it.FX * wcm);
            SetNum(numY, it.FY * hcm);
            SetNum(numW, it.FW * wcm);
            SetNum(numH, it.IsImage ? it.FW * wcm * it.ImgRatio : it.FH * hcm);
        }

        private void PosChanged(object sender, EventArgs e)
        {
            if (updatingUI || canvas.Selected == null) return;
            var it = canvas.Selected;
            double wcm = slideWPt / 72.0 * 2.54, hcm = slideHPt / 72.0 * 2.54;

            it.FX = (double)numX.Value / wcm;
            it.FY = (double)numY.Value / hcm;
            it.FW = (double)numW.Value / wcm;
            it.FH = (double)numH.Value / hcm;

            if (it.IsImage)
            {
                if (sender == numH) it.FW = ((double)numH.Value / it.ImgRatio) / wcm;
                it.FH = it.FW * wcm * it.ImgRatio / hcm;
                UpdatePosFields();
            }
            canvas.Invalidate();
            RefreshThumbs();
        }

        // ================= PROCESS =================
        private async Task RunProcess()
        {
            var targets = files.Where(f => f.Checked).Select(f => f.FilePath).ToList();
            if (files.Count == 0) { MessageBox.Show("Add at least one PPT file."); return; }
            if (targets.Count == 0) { MessageBox.Show("No file is checked. Check the files that should receive the content."); return; }
            if (items.Count == 0) { MessageBox.Show("There is nothing to insert yet. Click '+ Text' or '+ Image'."); return; }

            bool inPlace = chkOverwrite.Checked;
            bool makeBackup = chkBackup.Checked;
            if (!inPlace && (string.IsNullOrEmpty(txtOutput.Text) || !Directory.Exists(txtOutput.Text)))
            {
                MessageBox.Show("Choose an output folder, or tick 'Overwrite original files'.");
                return;
            }

            var snapshot = items.ToList();
            string outDir = txtOutput.Text;
            long baseCx = BaseCx;

            btnProcess.Enabled = false;
            progress.Maximum = targets.Count;
            progress.Value = 0;
            txtLog.Clear();

            await Task.Run(() =>
            {
                foreach (var src in targets)
                {
                    try
                    {
                        string dest = inPlace ? src : Path.Combine(outDir, Path.GetFileName(src));
                        if (!inPlace && string.Equals(Path.GetFullPath(src), Path.GetFullPath(dest), StringComparison.OrdinalIgnoreCase))
                            throw new Exception("The output folder is the same as the original folder. Choose another folder, or tick 'Overwrite original files'.");

                        ProcessFile(src, dest, inPlace, makeBackup, snapshot, baseCx, Log);
                        Log("[OK]    " + Path.GetFileName(src));
                    }
                    catch (Exception ex)
                    {
                        Log("[ERROR] " + Path.GetFileName(src) + " -> " + ex.Message);
                    }
                    Invoke((Action)(() => progress.Value++));
                }
            });

            Log("Done. Processed " + targets.Count + " file(s).");
            btnProcess.Enabled = true;
        }

        private void Log(string msg)
        {
            if (InvokeRequired) { Invoke((Action)(() => Log(msg))); return; }
            txtLog.AppendText(msg + Environment.NewLine);
        }

        private static void ProcessFile(string src, string dest, bool inPlace, bool makeBackup, List<ContentItem> list, long baseCx, Action<string> log)
        {
            if (inPlace)
            {
                if (makeBackup)
                {
                    string bak = src + ".bak";
                    if (!File.Exists(bak)) File.Copy(src, bak, false);
                }
            }
            else File.Copy(src, dest, true);

            using (var doc = PresentationDocument.Open(dest, true))
            {
                var pp = doc.PresentationPart;
                long cx = pp.Presentation.SlideSize.Cx.Value;
                long cy = pp.Presentation.SlideSize.Cy.Value;
                double fontScale = (double)cx / baseCx;

                foreach (var group in list.GroupBy(i => i.Slide))
                {
                    var slidePart = GetSlidePart(pp, group.Key);
                    if (slidePart == null)
                    {
                        log("   - " + Path.GetFileName(src) + ": slide " + group.Key + " not found, skipped.");
                        continue;
                    }

                    var tree = slidePart.Slide.CommonSlideData.ShapeTree;

                    // Clear existing content on the slide (keep only structural group properties)
                    // so that any previous shapes/pictures/text are removed before inserting the new items.
                    var toRemove = new List<DocumentFormat.OpenXml.OpenXmlElement>();
                    foreach (var child in tree.ChildElements)
                    {
                        if (!(child is P.NonVisualGroupShapeProperties) &&
                            !(child is P.GroupShapeProperties))
                        {
                            toRemove.Add(child);
                        }
                    }
                    foreach (var el in toRemove)
                        el.Remove();

                    foreach (var it in group)
                    {
                        long x = (long)(it.FX * cx);
                        long y = (long)(it.FY * cy);
                        long w = (long)(it.FW * cx);
                        long h = (long)(it.FH * cy);

                        if (it.IsImage)
                        {
                            if (!File.Exists(it.ImagePath)) { log("   - image not found: " + it.ImagePath); continue; }
                            h = (long)(w * it.ImgRatio);   // keep the image's original aspect ratio
                            tree.Append(CreatePicture(slidePart, it.ImagePath, NextId(tree), x, y, w, h));
                        }
                        else
                        {
                            tree.Append(CreateTextBox(NextId(tree), it, fontScale, x, y, w, h));
                        }
                    }
                    slidePart.Slide.Save();
                }
            }
        }

        private static SlidePart GetSlidePart(PresentationPart pp, int index1Based)
        {
            var ids = pp.Presentation.SlideIdList.ChildElements.OfType<P.SlideId>().ToList();
            if (index1Based < 1 || index1Based > ids.Count) return null;
            return (SlidePart)pp.GetPartById(ids[index1Based - 1].RelationshipId);
        }

        private static uint NextId(P.ShapeTree tree)
        {
            uint max = 1;
            foreach (var p in tree.Descendants<P.NonVisualDrawingProperties>())
                if (p.Id != null && p.Id.Value > max) max = p.Id.Value;
            return max + 1;
        }

        private static P.Shape CreateTextBox(uint id, ContentItem it, double fontScale, long x, long y, long w, long h)
        {
            var body = new P.TextBody(
                new D.BodyProperties { Wrap = D.TextWrappingValues.Square, RightToLeftColumns = false },
                new D.ListStyle());

            var c = Color.FromArgb(it.ColorArgb);
            string hex = string.Format("{0:X2}{1:X2}{2:X2}", c.R, c.G, c.B);
            int sz = (int)Math.Round(it.FontSize * fontScale * 100);

            D.TextAlignmentTypeValues align =
                it.Align == 1 ? D.TextAlignmentTypeValues.Center :
                it.Align == 2 ? D.TextAlignmentTypeValues.Right : D.TextAlignmentTypeValues.Left;

            foreach (var line in (it.Text ?? "").Replace("\r\n", "\n").Split('\n'))
            {
                var rp = new D.RunProperties { Language = "en-US", FontSize = sz, Dirty = false };
                if (it.Bold) rp.Bold = true;
                rp.Append(new D.SolidFill(new D.RgbColorModelHex { Val = hex }));
                if (!string.IsNullOrEmpty(it.FontName)) rp.Append(new D.LatinFont { Typeface = it.FontName });

                body.Append(new D.Paragraph(
                    new D.ParagraphProperties { Alignment = align },
                    new D.Run(rp, new D.Text(line))));
            }

            return new P.Shape(
                new P.NonVisualShapeProperties(
                    new P.NonVisualDrawingProperties { Id = id, Name = "TextBox " + id },
                    new P.NonVisualShapeDrawingProperties { TextBox = true },
                    new P.ApplicationNonVisualDrawingProperties()),
                new P.ShapeProperties(
                    new D.Transform2D(new D.Offset { X = x, Y = y }, new D.Extents { Cx = w, Cy = h }),
                    new D.PresetGeometry(new D.AdjustValueList()) { Preset = D.ShapeTypeValues.Rectangle },
                    new D.NoFill()),
                body);
        }

        private static P.Picture CreatePicture(SlidePart slidePart, string imagePath, uint id, long x, long y, long w, long h)
        {
            PartTypeInfo type;
            switch (Path.GetExtension(imagePath).ToLowerInvariant())
            {
                case ".jpg":
                case ".jpeg": type = ImagePartType.Jpeg; break;
                case ".gif": type = ImagePartType.Gif; break;
                case ".bmp": type = ImagePartType.Bmp; break;
                default: type = ImagePartType.Png; break;
            }

            var imagePart = slidePart.AddImagePart(type);
            using (var fs = File.OpenRead(imagePath))
                imagePart.FeedData(fs);
            string relId = slidePart.GetIdOfPart(imagePart);

            return new P.Picture(
                new P.NonVisualPictureProperties(
                    new P.NonVisualDrawingProperties { Id = id, Name = "Picture " + id },
                    new P.NonVisualPictureDrawingProperties(new D.PictureLocks { NoChangeAspect = true }),
                    new P.ApplicationNonVisualDrawingProperties()),
                new P.BlipFill(
                    new D.Blip { Embed = relId },
                    new D.Stretch(new D.FillRectangle())),
                new P.ShapeProperties(
                    new D.Transform2D(new D.Offset { X = x, Y = y }, new D.Extents { Cx = w, Cy = h }),
                    new D.PresetGeometry(new D.AdjustValueList()) { Preset = D.ShapeTypeValues.Rectangle }));
        }
    }
}
